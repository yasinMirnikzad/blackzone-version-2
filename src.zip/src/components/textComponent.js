import React from 'react';
import { Platform, Text, StyleSheet } from 'react-native';

//---------------------------------components


//---------------------------------colors
import { text } from '../config/colors.json';

const platform = Platform.OS;

const TextComponent = (props) => {
    let { fontWeight, style } = props
    style = style
    let fontWeightNum = fontWeight === 'Bold' ? '700' : fontWeight === 'Medium' ? '500' : fontWeight === 'Light' ? '300' : fontWeight === 'Thin' ? '100' : 'Regular'
    return (


        <Text
            {...props}
            style={{
                fontFamily: 'ShabnamMedium',
                fontFamily: platform === 'ios' ? 'Shabnam' : 'Shabnam' + `${fontWeight ? fontWeight : 'Medium'}`,
                fontWeight: platform === 'ios' ? fontWeightNum : 'normal',
                textAlign: 'right',
                color: text,
                ...style,
            }}
        >{props.children}</Text>
    )
}

export default TextComponent;


