import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Picker } from 'react-native-wheel-pick';
import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/Feather';

import Text from './textComponent';

import { Background, Primary } from '../config/colors.json';


const secconds = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17',
    '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35',
    '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53',
    '54', '55', '56', '57', '58', '59'];

const hours = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17',
    '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35',
    '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53',
    '54', '55', '56', '57', '58', '59', '60',
    '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75',
    '76', '77', '78', '79', '80', '81', '82', '83',
    '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96',
    '97', '98', '99', '100', '101', '102', '103', '104', '105', '106',
    '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117',
    '118', '119', '120', '121', '122', '123', '124', '125',
    '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136',
    '137', '138', '139', '140', '141', '142', '143', '144',
    '145', '146', '147', '148', '149', '150', '151', '152', '153', '154', '155',
    '156', '157', '158', '159', '160', '161', '162', '163',
    '164', '165', '166', '167', '168', '169', '170', '171', '172', '173', '174',
    '175', '176', '177', '178', '179', '180', '181', '182',
    '183', '184', '185', '186', '187', '188', '189', '190', '191', '192', '193',
    '194', '195', '196', '197', '198', '199', '200', '201',
    '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212',
    '213', '214', '215', '216', '217', '218', '219', '220',
    '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231',
    '232', '233', '234', '235', '236', '237', '238', '239'];


const TimePicker = (props) => {
    const [step, changeStep] = useState(0);
    const [start_time, changeStart_time] = useState({
        minute: 0,
        hour: 0
    });
    const [end_time, changeEnd_Time] = useState({
        minute: 0,
        hour: 0
    });

    const changeModalshow = async () => {
        await changeStep(0);
        await props.setModalVisible({
            ...props.modalVisible,
            show: false,
            selected_index: -1
        });
        await changeStart_time({
            minute: '00',
            hour: '00'
        })
        await changeEnd_Time({
            minute: '00',
            hour: '00'
        })
    }
    const addVal = async () => {
        await changeStart_time({
            ...start_time,
            hour: props.modalVisible.selected_first_item.hour,
            minute: props.modalVisible.selected_first_item.minute,
        });

        await changeEnd_Time({
            ...end_time,
            hour: props.modalVisible.selected_end_item.hour,
            minute: props.modalVisible.selected_end_item.minute,
        });

    }

    useEffect(() => {
        addVal();
    }, [props.modalVisible.show])


    const ButtonSubmit = async () => {

        // add an if else with step
        // inja update nmikone vaqty state taqir mikone havaset bashe badan test bgir :D
        if (step === 0) {
            console.log('start_time', start_time)
            await changeStep(1);
        } else {
            console.log('end_time', end_time);

            props.modalVisible.changeSelected_item({
                startH: start_time.hour,
                startM: start_time.minute,
                endH: end_time.hour,
                endM: end_time.minute
            })
            
            await changeModalshow();
        }
        // console.log('time', time)
        // await props.modalVisible.changeSelected_item({
        //     seccond: time.seccond,
        //     minute: time.minute,
        //     hour: time.hour,
        // });
        // await changeModalshow()
    }

    return (
        <Modal
            backButtonClose
            style={styles.modalContent}
            isOpen={props.modalVisible.show}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
            coverScreen={false}
        >

            <View style={styles.modal}>
                {/* header of the modal  */}
                <View style={styles.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={changeModalshow}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>


                    <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                        {
                            (step === 0 ?
                                'شروع تنظیمات'

                                : 'پایان تنظیمات'
                            )
                            +
                            props.modalVisible.title
                        }
                    </Text>

                </View>

                <View >
                    <View style={{
                        flexDirection: 'row', marginTop: 15,
                        width: '100%', justifyContent: 'space-around'
                    }}>
                        <Text fontWeight='Bold' style={{ fontSize: 16 }}>{'ساعت'}</Text>
                        <Text fontWeight='Bold' style={{ fontSize: 16 }}>{'دقیقه'}</Text>

                    </View>
                    {step === 0 ?
                        <View style={styles.timePickerContainer}>
                            <Picker
                                textColor={'white'}
                                style={{ flex: 1, height: 170, backgroundColor: 'transparent' }}
                                selectedValue={start_time.hour}
                                pickerData={hours}
                                onValueChange={value => {
                                    changeStart_time({ ...start_time, hour: value })
                                }}
                            />
                            <Picker
                                textColor={'white'}
                                // itemTextFontFamily={'ShabnamMedium'}
                                fontFamily={"ShabnamMedium"}
                                itemStyle={{ fontFamily: 'ShabnamMedium' }}
                                style={{
                                    fontFamily: 'ShabnamMedium', flex: 1,
                                    backgroundColor: 'transparent', height: 170
                                }}

                                selectedValue={start_time.minute}
                                pickerData={secconds}
                                onValueChange={value => {
                                    changeStart_time({ ...start_time, minute: value })
                                }}
                            />

                        </View>

                        :

                        <View style={styles.timePickerContainer}>
                            <Picker
                                textColor={'white'}
                                style={{ flex: 1, height: 170, backgroundColor: 'transparent' }}
                                selectedValue={end_time.hour}
                                pickerData={hours}
                                onValueChange={value => {
                                    changeEnd_Time({ ...end_time, hour: value })
                                }}
                            />
                            <Picker
                                textColor={'white'}
                                // itemTextFontFamily={'ShabnamMedium'}
                                fontFamily={"ShabnamMedium"}
                                itemStyle={{ fontFamily: 'ShabnamMedium' }}
                                style={{
                                    fontFamily: 'ShabnamMedium', flex: 1,
                                    backgroundColor: 'transparent', height: 170
                                }}

                                selectedValue={end_time.minute}
                                pickerData={secconds}
                                onValueChange={value => {
                                    changeEnd_Time({ ...end_time, minute: value })
                                }}
                            />

                        </View>

                    }


                    <View>
                        <TouchableOpacity
                            onPress={() => ButtonSubmit()}
                            style={styles.submitBtn}>
                            <Text fontWeight='Bold' style={{ color: Background, fontSize: 17 }}>{
                                step === 0 ?
                                    'بعدی'
                                    :
                                    'ثبت'
                            }</Text>
                        </TouchableOpacity>

                    </View>
                </View>
            </View>
        </Modal>
    );
};



export default TimePicker;

const styles = StyleSheet.create({
    modalContent: {
        width: '100%',
        backgroundColor: Background,
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
        height: 'auto',
        paddingVertical: 20,
        paddingHorizontal: 15,
        minHeight: 150
    },
    modal: {
        backgroundColor: Background,
        flexDirection: 'column',
    },
    timePickerContainer: {
        flexDirection: 'row',
        width: '100%'
    },
    timePickerContainerItem: {
        fontFamily: 'ShabnamRegular',
        color: 'white'
    },
    submitBtn: {
        borderRadius: 10,
        backgroundColor: Primary,
        width: '90%',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        height: 45,
        marginTop: 20
    },
});