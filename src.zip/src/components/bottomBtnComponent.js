import React from 'react';
import { Button } from 'native-base';

import { Text } from '../components';

import { Primary, Seccondary } from '../config/colors.json';







const BottomBtn = (props) => {
    return (
        <Button
            {...props}
            style={{
                position: 'absolute', bottom: 15,
                alignSelf: 'center', width: '80%',
                borderRadius: 10,
                backgroundColor: Primary,
                height: 50
            }}>
            <Text fontWeight='Bold' style={{ color: Seccondary }}>{props.children}</Text>
        </Button>
    )
}

export default BottomBtn;




