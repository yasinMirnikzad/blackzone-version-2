import React, { useEffect, useState } from 'react';
import {
    StyleSheet, View,
    TouchableOpacity, FlatList
} from 'react-native';
import BouncyCheckbox from "react-native-bouncy-checkbox";
import BouncyCheckboxGroup, {
    ICheckboxButton,
} from "react-native-bouncy-checkbox-group";

import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/Feather';
import { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';
import { Formik } from 'formik';

import SendSMS from 'react-native-sms-multi-sim';
import SmsAndroid from 'react-native-get-sms-android';
import * as Yup from 'yup';

import { useSelector, useDispatch } from 'react-redux';
import { setLoaderInVisible, setLoaderVisible } from '../redux/actions/loadingAction';

// ------------ components
import Text from './textComponent';
import Input from './inputComponent';
import { Header } from './headerComponent';
import { timestamp, requestSmsPermission } from '../utilities';

// ------------

import { Background, Primary, gray } from '../config/colors.json';

import { Button } from 'native-base';


// import { Close } from '../../images';

// let windows = Dimensions.get('window');


const ModalComponent = (props) => {
    const [selectedVal, changeSelectedVal] = useState();

    const ButtonSubmit = async () => {
        await props.modalVisible.changeSelected_item(selectedVal);
        await changeModalshow()
    }

    useEffect(() => {
        if (props.modalVisible.selected_item)
            changeSelectedVal(props.modalVisible.selected_item)
    }, [props.modalVisible.show]);

    const changeModalshow = () => {
        props.setModalVisible({
            ...props.modalVisible,
            show: false,
            selected_index: -1
        })
    }

    if (props.coverScreen)
        return (
            <Modal
                backButtonClose
                style={coverScreenStyles.modalContent}
                isOpen={props.modalVisible.show}
                swipeToClose={false}
                onClosed={changeModalshow}
                position='bottom'
                coverScreen={true}
            >

                <View style={coverScreenStyles.modal}>
                    {/* header of the modal  */}

                    <Header
                        title={props.modalVisible.title}
                        backBehavior={changeModalshow}
                    />

                    <View style={coverScreenStyles.content}>
                        {/* content of the modal  */}

                        <FlatList
                            data={props.data}
                            showsHorizontalScrollIndicator={false}
                            keyExtractor={(item, index) => String('key' + item.id + '' + index)}
                            renderItem={({ item, index }) =>
                                <RadioButton
                                    isSelected={true}
                                    obj={item}
                                    index={index}
                                    style={{
                                        flexDirection: 'row-reverse',
                                        height: 48,
                                        alignItems: 'center',
                                    }}
                                >
                                    <RadioButtonInput
                                        obj={item}
                                        index={index}
                                        isSelected={selectedVal === index ? true : false}
                                        onPress={() => changeSelectedVal(index)}
                                        buttonInnerColor={'#fff'}
                                        // buttonOuterColor={this.state.value3Index === i ? '#2196f3' : '#000'}
                                        buttonSize={8}
                                        buttonStyle={{
                                            borderWidth: 2, borderColor: 'white',

                                        }}
                                        buttonWrapStyle={{ marginLeft: 10 }}
                                    />
                                    <RadioButtonLabel
                                        obj={item}
                                        index={index}
                                        isSelected={selectedVal === index ? true : false}
                                        onPress={() => changeSelectedVal(index)}
                                        labelStyle={{
                                            fontFamily: 'ShabnamMedium',
                                            color: '#fff',
                                            height: 48,
                                            width: '100%',
                                            flex: 1,
                                            textAlignVertical: 'center'
                                        }}
                                        labelWrapStyle={{}}
                                    />
                                </RadioButton>

                            }
                        />

                    </View>




                    <Button
                        onPress={ButtonSubmit}
                        style={coverScreenStyles.submitBtn}>
                        <Text>ثبت</Text>
                    </Button>

                </View>

            </Modal >
        )
    else
        return (
            <Modal
                backdropPressToClose
                backButtonClose
                style={styles.modalContent}
                isOpen={props.modalVisible.show}
                swipeToClose={false}
                onClosed={changeModalshow}
                position='bottom'
                coverScreen={props.coverScreen}
            >

                <View style={styles.modal}>
                    {/* header of the modal  */}
                    <View style={styles.modalHeader}>
                        <TouchableOpacity
                            style={styles.closeBtn}
                            onPress={changeModalshow}
                        >
                            <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                        </TouchableOpacity>


                        <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                            {props.modalVisible.title}
                        </Text>

                    </View>


                    {/* content of the modal  */}
                    {props.data.length > 0 ?
                        <FlatList
                            data={props.data}
                            keyExtractor={(item, index) => String('key' + item.id + '' + index)}
                            renderItem={({ item, index }) =>


                                <RadioButton
                                    obj={item}
                                    index={index}
                                    style={{
                                        flexDirection: 'row-reverse',
                                        height: 48,
                                        alignItems: 'center',
                                    }}
                                >
                                    <RadioButtonInput
                                        obj={item}
                                        index={index}
                                        isSelected={props.modalVisible.selected_item === index ? true : false}
                                        onPress={() => {
                                            props.modalVisible.changeSelected_item(index);
                                            changeModalshow()
                                        }}
                                        buttonInnerColor={'#fff'}
                                        // buttonOuterColor={this.state.value3Index === i ? '#2196f3' : '#000'}
                                        buttonSize={8}
                                        buttonStyle={{
                                            borderWidth: 2, borderColor: 'white',

                                        }}
                                        buttonWrapStyle={{ marginLeft: 10 }}
                                    />
                                    <RadioButtonLabel
                                        obj={item}
                                        index={index}
                                        isSelected={props.modalVisible.selected_item === index ? true : false}

                                        onPress={() => {
                                            props.modalVisible.changeSelected_item(index);
                                            changeModalshow()
                                        }} labelStyle={{
                                            fontFamily: 'ShabnamMedium',
                                            color: '#fff',
                                            height: 48,
                                            width: '100%',
                                            flex: 1,
                                            textAlignVertical: 'center'
                                        }}
                                        labelWrapStyle={{}}
                                    />
                                </RadioButton>


                            }
                        />
                        :
                        <Formik
                            initialValues={{
                                name: props.modalVisible.selected_item
                            }}
                            enableReinitialize
                            validationSchema={props.validator}

                            onSubmit={values => {
                                props.modalVisible.changeSelected_item(values.name);
                                changeModalshow()
                            }}
                        >

                            {({
                                handleChange,
                                handleBlur,
                                handleSubmit,
                                values,
                                touched,
                                errors, }) => (
                                <View>
                                    <Input
                                        style={{ marginTop: 10 }}
                                        onChangeText={handleChange('name')}
                                        value={values.name}
                                        placeholder='نام زون'
                                    />

                                    <Text style={styles.formErr}>
                                        {errors.name && touched.name && errors.name}
                                    </Text>

                                    <TouchableOpacity
                                        onPress={handleSubmit}
                                        style={styles.submitBtn}>
                                        <Text>ثبت</Text>
                                    </TouchableOpacity>
                                </View>
                            )}
                        </Formik>
                    }


                </View>


            </Modal >

        );
}


// ------ modals that have radio buttons and active/deactive
const FunctionalModal = (props) => {


    const changeModalshow = (value) => {
        props.setModalVisible({
            ...props.modalVisible,
            show: false,
            selected_index: -1
        })
    }
    return (
        <Modal
            backdropPressToClose
            backButtonClose
            style={styles.modalContent}
            isOpen={props.modalVisible.show}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
            coverScreen={props.coverScreen}
        >

            <View style={styles.modal}>
                {/* header of the modal  */}
                <View style={styles.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={changeModalshow}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>


                    <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                        {props.modalVisible.item.title}
                    </Text>

                </View>


                {/* content of the modal  */}
                <FlatList
                    data={props.data}
                    keyExtractor={(item, index) => String('key' + item.id + '' + index)}
                    renderItem={({ item, index }) =>
                        item.func ?
                            <TouchableOpacity
                                onPress={() => item.function(props.modalVisible.selected_index)}
                                style={functionamModalStyles.functionBtn}>
                                <Text>{item.label}</Text>
                            </TouchableOpacity>
                            :
                            <RadioButton
                                obj={item}
                                index={index}
                                style={{
                                    flexDirection: 'row-reverse',
                                    height: 48,
                                    alignItems: 'center',
                                }}
                            >
                                <RadioButtonInput
                                    obj={item}
                                    index={index}
                                    isSelected={props.modalVisible.item.status === item.value ? true : false}
                                    onPress={item.function}
                                    buttonInnerColor={'#fff'}
                                    // buttonOuterColor={this.state.value3Index === i ? '#2196f3' : '#000'}
                                    buttonSize={8}
                                    buttonStyle={{
                                        borderWidth: 2, borderColor: 'white',

                                    }}
                                    buttonWrapStyle={{ marginLeft: 10 }}
                                />
                                <RadioButtonLabel
                                    obj={item}
                                    index={index}
                                    onPress={item.function}
                                    labelStyle={{
                                        fontFamily: 'ShabnamMedium',
                                        color: '#fff',
                                        height: 48,
                                        width: '100%',
                                        flex: 1,
                                        textAlignVertical: 'center'
                                    }}
                                    labelWrapStyle={{}}
                                />
                            </RadioButton>
                    }


                />


            </View>


        </Modal >
    )
}


const ZonesModal = (props) => {



    const changeModalshow = () => {
        props.setModalVisible({
            ...props.modalVisible,
            show: false,
            selected_index: -1
        })
    }

    return (
        <Modal
            backdropPressToClose={changeModalshow}
            backButtonClose
            style={styles.modalContent}
            isOpen={props.modalVisible.show}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
            coverScreen={props.coverScreen}
        >

            <View style={styles.modal}>
                {/* header of the modal  */}
                <View style={styles.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={changeModalshow}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>


                    <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                        {props.modalVisible.title}
                    </Text>

                </View>

                <FlatList
                    data={props.data}
                    keyExtractor={(item, index) => String('key' + item.id + '' + index)}
                    renderItem={({ item, index }) =>


                        <RadioButton
                            obj={item}
                            index={index}
                            style={{
                                flexDirection: 'row-reverse',
                                height: 48,
                                alignItems: 'center',
                            }}
                        >
                            <RadioButtonInput
                                obj={item}
                                index={index}
                                isSelected={props.modalVisible.selected_item === item.id ? true : false}
                                onPress={() => {
                                    props.modalVisible.changeSelected_item(item.id, props.modalVisible.index, props.modalVisible.type);
                                    changeModalshow()
                                }}
                                buttonInnerColor={'#fff'}
                                // buttonOuterColor={this.state.value3Index === i ? '#2196f3' : '#000'}
                                buttonSize={8}
                                buttonStyle={{
                                    borderWidth: 2, borderColor: 'white',

                                }}
                                buttonWrapStyle={{ marginLeft: 10 }}
                            />
                            <RadioButtonLabel
                                obj={item}
                                index={index}
                                isSelected={props.modalVisible.selected_item === item.id ? true : false}

                                onPress={() => {
                                    props.modalVisible.changeSelected_item(item.id, props.modalVisible.index, props.modalVisible.type);
                                    changeModalshow()
                                }}
                                labelStyle={{
                                    fontFamily: 'ShabnamMedium',
                                    color: '#fff',
                                    height: 48,
                                    width: '100%',
                                    flex: 1,
                                    textAlignVertical: 'center'
                                }}

                            />
                        </RadioButton>


                    }
                />
            </View>
        </Modal>
    )
}


const AddUserModal = (props) => {

    const changeModalshow = () => {
        props.setModalVisible({
            ...props.modalVisible,
            show: false,
            selected_index: -1
        })
    }


    return (
        <Modal
            backdropPressToClose
            backButtonClose
            style={styles.modalContent}
            isOpen={props.modalVisible.show}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
            coverScreen={props.coverScreen}
        >

            <View style={styles.modal}>
                {/* header of the modal  */}
                <View style={styles.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={changeModalshow}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>


                    <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                        {props.modalVisible.title}
                    </Text>

                </View>


                {/* content of the modal  */}
                <Formik
                    initialValues={{
                        phonenumber: '',
                        role: 'C'
                    }}
                    // enableReinitialize
                    // validationSchema={props.validator}

                    onSubmit={values => {
                        props.changeUser(values)
                    }}
                >

                    {({
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        setFieldValue,
                        values,
                        touched,
                        errors,
                    }) => (
                        <View>
                            <Input
                                style={{ marginTop: 10 }}
                                onChangeText={handleChange('phonenumber')}
                                value={values.phonenumber}
                                placeholder='شماره تماس'
                            />

                            <Text style={styles.formErr}>
                                {errors.phonenumber && touched.phonenumber && errors.phonenumber}
                            </Text>
                            <View style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                marginTop: 10,
                                width: '90%',
                                alignSelf: 'center'
                            }}>
                                {props.usertypes.map((item, index) =>
                                    <RadioButton
                                        isSelected={true}
                                        obj={item}
                                        index={index}
                                        key={String('item' + index)}
                                        style={{
                                            flexDirection: 'row-reverse',
                                            height: 48,
                                            alignItems: 'center',
                                        }}
                                    >
                                        <RadioButtonInput
                                            obj={item}
                                            index={index}
                                            isSelected={values.role === item.id ? true : false}
                                            onPress={() => setFieldValue('role', item.id)}
                                            buttonInnerColor={'#fff'}
                                            // buttonOuterColor={this.state.value3Index === i ? '#2196f3' : '#000'}
                                            buttonSize={8}
                                            buttonStyle={{
                                                borderWidth: 2, borderColor: 'white',

                                            }}
                                            buttonWrapStyle={{ marginLeft: 10 }}
                                        />
                                        <RadioButtonLabel
                                            obj={item}
                                            index={index}
                                            isSelected={values.role === item.id ? true : false}
                                            onPress={() => setFieldValue('role', item.id)}
                                            labelStyle={{
                                                fontFamily: 'ShabnamMedium',
                                                color: '#fff',
                                                height: 48,
                                                textAlignVertical: 'center'
                                            }}
                                            labelWrapStyle={{}}
                                        />
                                    </RadioButton>
                                )
                                }
                            </View>
                            <TouchableOpacity
                                onPress={handleSubmit}
                                style={styles.submitBtn}>
                                <Text>ثبت</Text>
                            </TouchableOpacity>
                        </View>
                    )}
                </Formik>



            </View>


        </Modal >

    );
}

// sms modal
const SelectSimModal = (props) => {
    const [selectedSim, changeSelectedSim] = useState(0);
    const dispatch = useDispatch();
    const select_device = useSelector((store) => store.selected_device.device);
    const showLoadingModal = useSelector((store) => store.loader_visibility.show_loader);

    const handleShowLoader = () => {
        dispatch(setLoaderVisible());
    };

    const handleHideLoader = () => {
        dispatch(setLoaderInVisible());
    };

    const sendWithSim = (value) => {
        changeSelectedSim(value)
    }

    const SendSms = async () => {
        let time2 = timestamp();
        let time = (Date.now());
        if (!props.homePage)
            handleShowLoader();

        requestSmsPermission();
        await changeModalshow();
        // console.log('props.message', select_device.device_phonenumber)
        console.log('object', select_device.device_phonenumber)
        console.log('props.SelectedSimModal.message', props.SelectedSimModal.message)

        await SendSMS.send(1, select_device.device_phonenumber,
            props.SelectedSimModal.message,
            async (msg) => {
                if (msg === 'Sent') {
                    if (props.homePage) {
                        await props.return_func(props.key_val);
                        await handleHideLoader();
                    } else
                        await GetMessagge(time, time2);
                } else
                    console.log('msg', msg)
            }
        );




        // in bayad ye jayi ham sim ro to async zakhire kone 
        // ke darvaqe to redux bere
        // ham sms ro send kone
        // redux thunk
    }
    // let timer = 0;

    const GetMessagge = async (time, time2) => {
        let time3 = (Date.now());
        var filter = {
            address: "+98" + '9053971710',
            minDate: time3,
            // bodyRegex: "(.*)" + time2 + "(.*)"
        }
        console.log('time3', time3)

        var timesRun = 0;
        var interval = setInterval(function () {
            timesRun += 1;
            if (timesRun === 60) {
                clearInterval(interval);
            }

            SmsAndroid.list(
                JSON.stringify(filter),
                (fail) => {
                    console.log('error read message : ', fail);
                },
                async (count, smsList) => {
                    var arr = JSON.parse(smsList);
                    if (count !== 0) {
                        clearInterval(interval);
                        await props.return_func(arr[0].body);
                        // momkene majbur bashim ino badan ja be ja konim 
                        // ke masaln bade sabte taqirat biad hide kone  
                        await handleHideLoader();
                    }
                },
            )

        }, 1000);
    }





    const changeModalshow = () => {
        props.changeModalShow({
            ...props.SelectedSimModal,
            show: false,
            messaage: ''
        })
    }




    return (
        <Modal
            backdropPressToClose
            backButtonClose
            style={smsModalStyle.modalContent}
            isOpen={props.SelectedSimModal.show}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='center'
        >
            <View style={smsModalStyle.container}>
                {/* header of the modal  */}
                <View style={smsModalStyle.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={() => changeModalshow()}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>

                    <Text>سیم‌کارت خودرا انتخاب کنید</Text>
                </View>

                <View style={smsModalStyle.selectSimContainer}>
                    <TouchableOpacity
                        onPress={() => sendWithSim(0)}
                        activeOpacity={.5}
                        style={{
                            ...smsModalStyle.selectSimBtn,
                            borderColor: selectedSim === 0 ? Primary : gray
                        }}>
                        <Text>sim1</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => sendWithSim(1)}
                        activeOpacity={.5}
                        style={{
                            ...smsModalStyle.selectSimBtn,
                            borderColor: selectedSim === 1 ? Primary : gray
                        }}>
                        <Text>sim2</Text>
                    </TouchableOpacity>
                </View>

                <TouchableOpacity
                    onPress={() => SendSms()}
                    activeOpacity={.4}
                    style={smsModalStyle.cancelLoadingBtn}>
                    <Text fontWeight='Bold' style={{ color: Primary }}>ارسال</Text>
                </TouchableOpacity>

            </View>
        </Modal>
    )
}

const LoadingModal = (props) => {
    return (
        <Modal
            backdropPressToClose={false}
            // backButtonClose
            style={loadermodalStyle.modalContent}
            isOpen={props.show}
            swipeToClose={false}
            onClosed={props.changeshow}
            position='center'
        >
            <View style={loadermodalStyle.container}>
                <Text>در حال پردازش اطلاعات...</Text>

                <TouchableOpacity
                    onPress={() => props.changeshow()}
                    activeOpacity={.4}
                    style={loadermodalStyle.cancelLoadingBtn}>
                    <Text style={{ color: Primary }}>لغو درخواست</Text>
                </TouchableOpacity>
            </View>
        </Modal>
    )
}

const MultiSelectModalComponent = (props) => {
    const [selectedVal, changeSelectedVal] = useState([]);

    useEffect(() => {
        if (props.modalVisible.selected_item) {
            let buffer = props.modalVisible.selected_item;
            changeSelectedVal([...buffer])
        }
    }, [props.modalVisible.show])



    const ButtonSubmit = async () => {
        await props.modalVisible.changeSelected_item(selectedVal);
        await changeModalshow()
    }

    const changeModalshow = async () => {
        await props.setModalVisible({
            ...props.modalVisible,
            show: false,
            title: '',
            selected_item: null,
            changeSelected_item: null,
            coverScreen: false
        })
    }

    const AddValue = async (value) => {
        let selects = selectedVal;
        let index = await selectedVal.findIndex(item => item === value);
        if (index === -1)
            await selects.push(value)
        else
            await selects.splice(index, 1)

        await changeSelectedVal(selects)

    }

    const AddAll = async () => {
        let selects = [];
        let a = await props.data.map((item, index) => index);
        selects = [...selects, ...a]
        console.log('selects', selects)
        await changeSelectedVal(selects)
        console.log('selectedVal', selectedVal)

    }

    return (
        <Modal
            backButtonClose
            style={coverScreenStyles.modalContent}
            isOpen={props.modalVisible.show}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
            coverScreen={true}
        >

            <View style={coverScreenStyles.modal}>
                {/* header of the modal  */}

                <Header
                    title={props.modalVisible.title}
                    backBehavior={changeModalshow}
                />

                <View style={coverScreenStyles.content}>
                    {/* content of the modal  */}

                    {/* {props.selectAll &&
                        <BouncyCheckbox
                            isChecked={selectedVal.length === props.data.length ? true : false}
                            size={20}
                            iconComponent={<Icon name='check' size={14} color={'#232323'} />}
                            fillColor="white"
                            unfillColor="#232323"
                            text={'همه روز‌ها'}
                            iconStyle={{ color: 'black', borderRadius: 5, borderColor: 'red' }}
                            innerIconStyle={{ borderColor: "white", borderWidth: 2, borderRadius: 5 }}
                            textStyle={{
                                fontFamily: "ShabnamMedium",
                                marginRight: 20, color: 'white',
                                textDecorationLine: "none",
                            }}
                            style={{
                                flexDirection: 'row-reverse',
                                height: 48,
                                alignItems: 'center',
                            }}
                            onPress={() => AddAll()}
                        />
                    } */}
                    {/* make somthing to force update list 
                        afer select all
                    */}
                    <FlatList
                        data={props.data}
                        // extraData={refreshFlatlist}
                        showsVerticalScrollIndicator={false}
                        ListFooterComponent={() => <View style={{ height: 100 }}></View>}
                        keyExtractor={(item, index) => String('key' + item.id + '' + index)}
                        renderItem={({ item, index }) =>
                            <BouncyCheckbox
                                isChecked={selectedVal.includes(index) ? true : false}
                                size={20}
                                iconComponent={<Icon name='check' size={14} color={'#232323'} />}
                                fillColor="white"
                                unfillColor="#232323"
                                text={item.label}
                                iconStyle={{ color: 'black', borderRadius: 5, borderColor: 'red' }}
                                innerIconStyle={{ borderColor: "white", borderWidth: 2, borderRadius: 5 }}
                                textStyle={{
                                    fontFamily: "ShabnamMedium",
                                    marginRight: 20, color: 'white',
                                    textDecorationLine: "none",
                                }}
                                style={{
                                    flexDirection: 'row-reverse',
                                    height: 48,
                                    alignItems: 'center',
                                }}
                                onPress={() => AddValue(index)}
                            />



                        }
                    />

                </View>




                <Button
                    onPress={ButtonSubmit}
                    style={coverScreenStyles.submitBtn}>
                    <Text>ثبت</Text>
                </Button>

            </View>

        </Modal >
    )
}

const TypeOfReportModalComponent = (props) => {
    const [receiveReportbyCall, changeReceiveReportbyCall] = useState(false);
    const [receiveReportbySms, changeReceiveReportbySms] = useState(false);
    const [receiveSathiSms, changeReceiveSathiSms] = useState(false);
    const [receiveReportDetail, changeReceiveReportDetail] = useState(false);

    const changeModalshow = () => {
        props.setModalVisible(false)
    }

    const submitModal = async () => {
        // await changeReceiveReportbyCall();
        await props.changeReceiveReportbyCall(receiveReportbyCall)
        await props.changeReceiveReportbySms(receiveReportbySms)
        await props.changeReceiveSathiSms(receiveSathiSms)
        await props.changeReceiveReportDetail(receiveReportDetail)
        props.setModalVisible(false)

    }

    const getInfo = async () => {
        console.log('props', props)
        await changeReceiveReportbyCall(props.receiveReportbyCall);
        await changeReceiveReportbySms(props.receiveReportbySms);
        await changeReceiveSathiSms(props.receiveSathiSms);
        await changeReceiveReportDetail(props.receiveReportDetail);
    }



    useEffect(() => {
        getInfo();
    }, [props.modalVisible]);

    return (
        <Modal
            backdropPressToClose
            backButtonClose
            style={styles.modalContent}
            isOpen={props.modalVisible}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
            coverScreen={false}
        >

            <View style={styles.modal}>
                {/* header of the modal  */}
                <View style={styles.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={changeModalshow}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>


                    <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                        نحوه ارسال گزارش
                    </Text>

                </View>
                <View style={styles.modalContent}>


                    <BouncyCheckbox
                        isChecked={receiveReportbyCall}
                        size={20}
                        iconComponent={<Icon name='check' size={14} color={'#232323'} />}
                        fillColor="white"
                        unfillColor="#232323"
                        text={'دریافت گزارش از طریق تماس'}
                        iconStyle={{ color: 'black', borderRadius: 5, borderColor: 'red' }}
                        innerIconStyle={{ borderColor: "white", borderWidth: 2, borderRadius: 5 }}
                        textStyle={{
                            fontFamily: "ShabnamMedium",
                            marginRight: 20, color: 'white',
                            textDecorationLine: "none",
                        }}
                        style={{
                            flexDirection: 'row-reverse',
                            height: 48,
                            alignItems: 'center',
                        }}
                        onPress={() => changeReceiveReportbyCall(!receiveReportbyCall)}
                    />

                    <BouncyCheckbox
                        isChecked={receiveReportbySms}
                        size={20}
                        iconComponent={<Icon name='check' size={14} color={'#232323'} />}
                        fillColor="white"
                        unfillColor="#232323"
                        text={'دریافت گزارش از طریق پیامک'}
                        iconStyle={{ color: 'black', borderRadius: 5, borderColor: 'red' }}
                        innerIconStyle={{ borderColor: "white", borderWidth: 2, borderRadius: 5 }}
                        textStyle={{
                            fontFamily: "ShabnamMedium",
                            marginRight: 20, color: 'white',
                            textDecorationLine: "none",
                        }}
                        style={{
                            flexDirection: 'row-reverse',
                            height: 48,
                            alignItems: 'center',
                        }}
                        onPress={() => {
                            if (!receiveReportbySms) {
                                changeReceiveSathiSms(0)
                            } else {
                                changeReceiveSathiSms(2)
                            }
                            changeReceiveReportbySms(!receiveReportbySms);
                        }}
                    />

                    <View style={{ paddingRight: 20 }}>
                        <BouncyCheckboxGroup
                            data={[{
                                isChecked: receiveSathiSms === 0 ? true : false,
                                disabled: !receiveReportbySms,
                                size: 20,
                                id: 0,
                                text: 'پیامک سطحی',
                                disableBuiltInState: true,
                                fillColor: "white",
                                iconComponent: () => <View
                                    style={{
                                        height: 12,
                                        width: 12,
                                        borderWidth: 2,
                                        borderRadius: 100,
                                        borderColor: Background,

                                    }}></View>,

                                unfillColor: "#232323",
                                iconStyle: { color: 'black', borderColor: Background, borderWidth: 6 },
                                innerIconStyle: { borderColor: "white", borderWidth: 1, },
                                textStyle: {
                                    fontFamily: "ShabnamMedium",
                                    marginRight: 20, color: 'white',
                                    textDecorationLine: "none",
                                    fontSize: 14
                                },
                                style: {
                                    flexDirection: 'row-reverse',
                                    height: 48,
                                    alignItems: 'center',
                                }
                            },
                            {
                                id: 1,
                                isChecked: receiveSathiSms === 1 ? true : false,
                                disabled: !receiveReportbySms,
                                text: 'پیامک لبه‌ای',
                                fillColor: "white",
                                disableBuiltInState: true,
                                size: 20,
                                unfillColor: "#232323",
                                iconStyle: { color: 'black', borderColor: 'red' },
                                innerIconStyle: { borderColor: "white", borderWidth: 1, },
                                iconComponent: () => <View
                                    style={{
                                        height: 12,
                                        width: 12,
                                        borderWidth: 2,
                                        borderRadius: 100,
                                        borderColor: Background,

                                    }}></View>,

                                unfillColor: "#232323",
                                iconStyle: { color: 'black', borderColor: Background, borderWidth: 6 },
                                innerIconStyle: { borderColor: "white", borderWidth: 1, },
                                textStyle: {
                                    fontFamily: "ShabnamMedium",
                                    marginRight: 20, color: 'white',
                                    textDecorationLine: "none",
                                    fontSize: 14
                                },
                                style: {
                                    flexDirection: 'row-reverse',
                                    height: 48,
                                    alignItems: 'center',
                                }
                            },
                            ]}
                            style={{ flexDirection: 'column' }}

                            onChange={(selectedItem: ICheckboxButton) => {
                                console.log("SelectedItem: ", JSON.stringify(selectedItem));
                            }}

                        />

                    </View>
                    <BouncyCheckbox

                        isChecked={receiveReportDetail}
                        size={20}
                        iconComponent={<Icon name='check' size={14} color={'#232323'} />}
                        fillColor="white"
                        unfillColor="#232323"
                        text={'دریافت جزئیات گزارش'}
                        iconStyle={{ color: 'black', borderRadius: 5, borderColor: 'red' }}
                        innerIconStyle={{ borderColor: "white", borderWidth: 2, borderRadius: 5 }}
                        textStyle={{
                            fontFamily: "ShabnamMedium",
                            marginRight: 20, color: 'white',
                            textDecorationLine: "none",
                        }}
                        style={{
                            flexDirection: 'row-reverse',
                            height: 48,
                            alignItems: 'center',
                        }}
                        onPress={() => changeReceiveReportDetail(!receiveReportDetail)}
                    />


                </View>
                <TouchableOpacity
                    onPress={submitModal}
                    activeOpacity={.4}
                    style={typeOfreportsModalStyle.submitBtn}>
                    <Text fontWeight='Bold' style={{ color: Background }}>ثبت</Text>
                </TouchableOpacity>
            </View>
        </Modal>
    )
}



export {
    ModalComponent,
    FunctionalModal,
    ZonesModal,
    AddUserModal,
    LoadingModal,
    MultiSelectModalComponent,
    SelectSimModal,
    TypeOfReportModalComponent
};


const styles = StyleSheet.create({
    modalContent: {
        width: '100%',
        backgroundColor: Background,
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
        height: 'auto',
        paddingVertical: 20,
        paddingHorizontal: 15,
        minHeight: 150
    },
    modal: {
        backgroundColor: Background,
        flexDirection: 'column',
    },
    modalHeader: {
        flexDirection: 'row',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 12
    },
    closeBtn: {
        marginLeft: 10
        // paddingRight: 10,
        // paddingBottom: 10
    },
    submitBtn: {
        borderRadius: 10,
        backgroundColor: Primary,
        width: '90%',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        height: 45,
        marginTop: 20
    },
    formErr: {
        color: 'red',
        fontSize: 12,
        marginRight: 5,
        marginTop: 7
    }
})

const coverScreenStyles = StyleSheet.create({
    modalContent: {
        width: '100%',
        backgroundColor: Background,
        height: '100%'
    },
    modal: {
        flexDirection: 'column',
        flex: 1,
    },
    content: {
        padding: 17,
        flex: 1,
    },
    submitBtn: {
        borderRadius: 10,
        backgroundColor: Primary,
        position: 'absolute',
        width: '90%',
        alignSelf: 'center',
        bottom: 20
    }
})

const functionamModalStyles = StyleSheet.create({
    functionBtn: {
        height: 48,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'flex-end'
    }
})

const loadermodalStyle = StyleSheet.create({
    modalContent: {
        width: '90%',
        backgroundColor: Background,
        borderRadius: 16,
        paddingVertical: 20,
        paddingHorizontal: 15,
        height: 'auto',
        minHeight: 150,
        justifyContent: 'center',
        alignItems: 'center'
    },
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Background,
        width: '80%'
    },
    cancelLoadingBtn: {
        marginTop: 20,
        height: 40,
        borderWidth: 1,
        width: '90%',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12,
        borderColor: Primary
    }
})

const smsModalStyle = StyleSheet.create({
    modalContent: {
        width: '90%',
        backgroundColor: Background,
        borderRadius: 16,
        paddingVertical: 20,
        paddingHorizontal: 15,
        height: 'auto',
        minHeight: 150,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column'
    },
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Background,
        width: '90%'
    },
    modalHeader: {
        flexDirection: 'row',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 12

    },
    cancelLoadingBtn: {
        marginTop: 20,
        height: 40,
        borderWidth: 1,
        width: '90%',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 12,
        borderColor: Primary
    },
    selectSimContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        width: '90%',
        marginBottom: 10,
        marginTop: 25,
    },
    selectSimBtn: {
        height: 70,
        width: 70,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: gray,
        justifyContent: 'center',
        alignItems: 'center'
    }
})

const typeOfreportsModalStyle = StyleSheet.create({
    submitBtn: {
        borderRadius: 12,
        backgroundColor: Primary,
        height: 55,
        width: '90%',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center'
    }
})