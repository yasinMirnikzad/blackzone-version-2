

import React from 'react';
import { Platform, Text, StyleSheet, TextInput } from 'react-native';

//---------------------------------components


//---------------------------------colors
import { text } from '../config/colors.json';

const platform = Platform.OS;

const InputComponent = (props) => {
    let { fontWeight, style } = props
    style = style
    let fontWeightNum = fontWeight === 'Bold' ? '700' : fontWeight === 'Medium' ? '500' : fontWeight === 'Light' ? '300' : fontWeight === 'Thin' ? '100' : 'Regular'
    return (


        <TextInput
            {...props}
            style={{
                ...styles.inputStyle,
                fontFamily: 'ShabnamMedium',
                fontFamily: platform === 'ios' ? 'Shabnam' : 'Shabnam' + `${fontWeight ? fontWeight : 'Medium'}`,
                fontWeight: platform === 'ios' ? fontWeightNum : 'normal',
                textAlign: 'right',
                color: 'white',
                ...style,

            }}
            placeholderTextColor={'#696969'}
            placeholder={props.placeholder}
            value={props.value}
        />
    )
}

export default InputComponent;


const styles = StyleSheet.create({
    inputStyle: {
        height: 50,
        width: '100%',
        borderRadius: 10,
        backgroundColor: '#000',
        paddingRight: 10,
        fontSize: 14
    }
})


