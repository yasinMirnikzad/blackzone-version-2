import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Modal from 'react-native-modalbox';
import Icon from 'react-native-vector-icons/Feather';
import { Formik } from 'formik';

import Text from './textComponent';
import Input from './inputComponent';

import { Background, Primary } from '../config/colors.json';




const AddUserModal = (props) => {
    // step->0 = name , step->1 = phonenumber
    const [step, changeStep] = useState(0);

    const changeModalshow = () => {
        props.setModalVisible(false)
    }

    const OnSubmitClick = (values) => {
        if (step === 0)
            changeStep(1)
        else
            console.log('values', values)
    }


    return (
        <Modal
            backdropPressToClose
            backButtonClose
            style={styles.modalContent}
            isOpen={props.modalVisible}
            swipeToClose={false}
            onClosed={changeModalshow}
            position='bottom'
        >

            <View style={styles.modal}>
                {/* header of the modal  */}
                <View style={styles.modalHeader}>
                    <TouchableOpacity
                        style={styles.closeBtn}
                        onPress={changeModalshow}
                    >
                        <Icon name='x' style={{ color: 'white', fontSize: 22 }} />
                    </TouchableOpacity>


                    <Text fontWeight='Bold' style={{ color: '#797979', fontSize: 16 }}>
                        {step === 0 ?
                            'نام'
                            :
                            'شماره تلفن'
                        }
                    </Text>

                </View>


                {/* content of the modal  */}
                <Formik
                    initialValues={{
                        name: '',
                        phonenumber: ''
                    }}
                    enableReinitialize
                    // validationSchema={props.validator}

                    onSubmit={values => {
                        // console.log('values', values)
                        OnSubmitClick(values)
                    }}
                >

                    {({
                        handleChange,
                        handleSubmit,
                        setFieldValue,
                        values,
                        touched,
                        errors,
                    }) => (
                        <View>

                            <Input
                                style={{ marginTop: 10 }}
                                onChangeText={step === 0 ? handleChange('name') : handleChange('phonenumber')}
                                value={step === 0 ? values.name : values.phonenumber}
                                placeholder={step === 0 ? 'نام' : 'شماره تلفن'}
                            />

                            <Text style={styles.formErr}>
                                {errors.phonenumber && touched.phonenumber && errors.phonenumber}
                            </Text>

                            <Text style={styles.formErr}>
                                {errors.name && touched.name && errors.name}
                            </Text>

                            <TouchableOpacity
                                onPress={handleSubmit}
                                style={styles.submitBtn}>
                                <Text>ثبت</Text>
                            </TouchableOpacity>


                        </View>
                    )}
                </Formik>



            </View>


        </Modal >

    );
}

export default AddUserModal;


const styles = StyleSheet.create({
    modalContent: {
        width: '100%',
        backgroundColor: Background,
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
        height: 'auto',
        paddingVertical: 20,
        paddingHorizontal: 15,
        minHeight: 150
    },
    modal: {
        backgroundColor: Background,
        flexDirection: 'column',
    },
    modalHeader: {
        flexDirection: 'row',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 12
    },
    closeBtn: {
        marginLeft: 10
        // paddingRight: 10,
        // paddingBottom: 10
    },
    submitBtn: {
        borderRadius: 10,
        backgroundColor: Primary,
        width: '90%',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        height: 45,
        marginTop: 20
    },
    formErr: {
        color: 'red',
        fontSize: 12,
        marginRight: 5,
        marginTop: 7
    }
})