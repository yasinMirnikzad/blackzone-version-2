import React from 'react';
import {
    StyleSheet,
    View,
    TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { useNavigation } from '@react-navigation/native';

// ----------- color
import Text from './textComponent';
// ----------- images
import { Bug, Setting, Moderates } from '../images/home/drawer'

// ----------- color
import { Background, Primary, Seccondary } from '../config/colors.json';





const TopDrawerList = [
    { id: 0, route: 'Moderates', name: 'مدیران', icon: Moderates },
    { id: 1, route: 'ZonesPage', name: 'زون‌ها', icon: Bug },
    { id: 2, route: 'SettingPage', name: 'تنظیمات', icon: Setting },
]


const BottomDrawerList = [
    { id: 0, route: 'ContactsPage', name: 'دریافت کنندگان پیامک هشدار' },
    { id: 1, route: 'RemotesPage', name: 'ریموت‌های فیزیکی' }
]



const CustomDrawer = (props) => {
    const navigation = useNavigation();
    return (
        <View style={drawerStyle.drawerContainer}>

            <View style={drawerStyle.topContent}>
                <TouchableOpacity
                    onPress={() => navigation.navigate('DevicesPage')}
                >

                    <Text fontWeight='Medium' style={{ color: Seccondary, fontSize: 18 }} >دزدگیر مغازه</Text>
                    <Text style={{ color: Seccondary, fontSize: 12 }}>تغییر یا اضافه کردن دستگاه</Text>
                    <Icon name='chevron-left'
                        style={{
                            position: 'absolute',
                            top: 8,
                            left: 0,
                            fontSize: 22,

                        }} />
                </TouchableOpacity>
            </View>



            {TopDrawerList.map((item) =>
                <TopDrawerItems
                    key={String('drawer' + item.id)}
                    {...{ ...item }}
                />
            )
            }

            <View style={{ position: 'absolute', bottom: 20, width: '100%' }}>
                {BottomDrawerList.map((item) =>
                    <BottomDrawerItems
                        key={String('bottomdrawer' + item.id)}
                        {...{ ...item }}
                    />
                )

                }
            </View>

        </View>
    )
}

const drawerStyle = StyleSheet.create({
    drawerContainer: {
        backgroundColor: Background,
        flex: 1,
        flexDirection: 'column',
    },
    topContent: {
        backgroundColor: Primary,
        height: 100,
        justifyContent: 'center',
        justifyContent: 'center',
        padding: 24
    },
    drawerTopItem: {
        alignItems: 'center',
        height: 55,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        paddingHorizontal: 20,
        marginTop: 2
    }
})



export default CustomDrawer;




const TopDrawerItems = (props) => {
    const navigation = useNavigation();
    return (
        <TouchableOpacity
            onPress={() => navigation.navigate(props.route)}
            style={drawerStyle.drawerTopItem}>
            <Icon name='chevron-left' style={{
                color: 'white',
                position: 'absolute',
                left: 24, fontSize: 20
            }} />
            <Text fontWeight='Bold' style={{ fontSize: 16, marginRight: 17 }}>{props.name}</Text>
            <props.icon />
        </TouchableOpacity>
    )
}


const BottomDrawerItems = (props) => {
    const navigation = useNavigation();

    return (
        <TouchableOpacity
            onPress={() => navigation.navigate(props.route)}
            style={drawerStyle.drawerTopItem}>
            <Icon name='chevron-left' style={{
                color: 'white',
                position: 'absolute',
                left: 24, fontSize: 20
            }} />
            <Text fontWeight='Medium' style={{ fontSize: 13, marginRight: 17 }}>{props.name}</Text>
        </TouchableOpacity>
    )
}
