

import Text from './textComponent';
import Input from './inputComponent';
import CustomDrawer from './drawerComponent';
import { Header, EditHeader } from './headerComponent';
import {
    ModalComponent as Modal,
    FunctionalModal,
    ZonesModal,
    AddUserModal,
    LoadingModal,
    MultiSelectModalComponent,
    SelectSimModal,
    TypeOfReportModalComponent
} from './modalComponent';

import BottomBtn from './bottomBtnComponent';
import TimePicker from './timePickerComponent';


export {
    Text,
    Input,

    CustomDrawer,

    Header,
    EditHeader,

    Modal,
    FunctionalModal,
    ZonesModal,
    AddUserModal,
    LoadingModal,
    MultiSelectModalComponent,
    SelectSimModal,
    TypeOfReportModalComponent,

    TimePicker,

    BottomBtn
}