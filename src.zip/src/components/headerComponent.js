import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { useNavigation } from '@react-navigation/native';

import { Text } from '../components';

import { gray, Primary, Seccondary } from '../config/colors.json';



//  header bayd fix beshe :D
const Header = (props) => {
    const navigation = useNavigation();

    return (
        <View style={styles.container}>
            <Text fontWeight='Bold'
                style={styles.title}>{props.title}</Text>

            <TouchableOpacity
                onPress={() => {
                    props.backBehavior ?
                        props.backBehavior()
                        :
                        navigation.goBack()
                }}
                style={styles.headerBtn}>
                <Icon style={styles.Icon} name='arrow-right' />
            </TouchableOpacity>

        </View>
    )
}


const styles = StyleSheet.create({
    container: {
        height: 64,
        width: '100%',
        backgroundColor: '#313131',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingHorizontal: 5
    },
    title: {
        fontSize: 18,
        color: '#b6b6b6',
        flex: 1,
    },
    Icon: {
        fontSize: 24,
        color: 'white',
    },
    headerBtn: {
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 15
    }
})



const EditHeader = (props) => {
    const navigation = useNavigation();

    return (
        <View style={editHedaerstyles.container}>
            <View style={editHedaerstyles.topContainer}>
                <TouchableOpacity
                    activeOpacity={.5}
                    onPress={props.syncFunc}
                    style={editHedaerstyles.headerleftBtn}>
                    <Text fontWeight='Bold' style={{ color: Seccondary }}>همگام‌سازی تنظیمات</Text>
                    <Icon style={editHedaerstyles.IconRefresh} name='refresh-cw' />
                </TouchableOpacity>


                <TouchableOpacity
                    onPress={() => navigation.goBack()}
                    style={editHedaerstyles.headerBtn}>
                    <Icon style={styles.Icon} name='arrow-right' />
                </TouchableOpacity>


            </View>

            <Text fontWeight='Bold'
                style={editHedaerstyles.title}>{props.title}</Text>

        </View>
    )
}


const editHedaerstyles = StyleSheet.create({
    container: {
        width: '100%',
        backgroundColor: '#313131',
        flexDirection: 'column',
        padding: 16
    },
    title: {
        fontSize: 20,
        color: '#b6b6b6',
        marginTop: 12
    },
    topContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    Icon: {
        fontSize: 24,
        color: 'white'
    },
    IconRefresh: {
        fontSize: 15,
        color: Seccondary,
        marginLeft: 7
    },
    headerBtn: {
        // height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 15,

    },
    headerleftBtn: {
        flexDirection: 'row',
        backgroundColor: Primary,
        paddingVertical: 8,
        paddingHorizontal: 14,
        borderRadius: 10,
        alignItems: 'center'
    }
})


export {
    EditHeader,
    Header
};