

import { combineReducers } from 'redux';
import { configureStore } from '@reduxjs/toolkit';

import DeviceReducer from './reducers/deviceReducer';
import LoaderReducer from './reducers/loaderReducer';

const rootReducer = combineReducers({
    selected_device: DeviceReducer,
    loader_visibility: LoaderReducer
});

export const store = configureStore({ reducer: rootReducer });