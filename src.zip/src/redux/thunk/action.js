// Action Creator
const addLastNameActionCreator = () => (dispatch) => {
    console.log("[*** 2. inside addLastNameActionCreator]");
    // Case1: Think returns Loading until receives response
    dispatch({ type: "LOADING" });
    // Calling the server
    setTimeout(() => {
        console.log('wait')
    }, 3000)

    dispatch({
        type: "RECEIVED",
        payload: 'responseJson'
    });
    // fetch("http://localhost:5555/articles")
    //     // Case2 Thunk received response
    //     .then(response => response.json())
    //     .then(responseJson => {
    //         console.log("3. received ", responseJson);
    //         dispatch({
    //             type: "RECEIVED",
    //             payload: responseJson
    //         });
    //     });



}