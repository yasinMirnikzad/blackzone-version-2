
const initialState = {
    show_loader: false
};

export default (state = initialState, action) => {

    switch (action.type) {
        case 'SET_LOADER_VISIBLE':
            return {
                ...state,
                show_loader: true
            };
        case 'SET_LOADER_INVISIBLE':
            return {
                ...state,
                show_loader: false
            };
        default:
            return state;
    }
}