
const initialState = {
    device: {}
};

// each device has this item
// name , phonenumber , password , securitynumber , 
// lastmessage , iconIndex , selected simcard


const changeSelectedDevice = (state, value) => {
    console.log('value',value)
    return state = value
}
export default (state = initialState, action) => {

    switch (action.type) {
        case 'SET_DEVICE':
            return {
                ...state,
                device: changeSelectedDevice(state.selectedDevice, action.payload)
            };
        default:
            return state;
    }
}