

// redux/actions/countAction.js
export const setDevice = (selectedDevice) => {
    return {
        type: 'SET_DEVICE',
        payload: selectedDevice
    };
};



// export const getDevice = () => {
//     return {
//         type: 'GET_DEVICE',
//     };
// };