

// redux/actions/countAction.js
export const setLoaderVisible = () => {
    return {
        type: 'SET_LOADER_VISIBLE',
    };
};

export const setLoaderInVisible = () => {
    return {
        type: 'SET_LOADER_INVISIBLE',
    };
};

// export const getDevice = () => {
//     return {
//         type: 'GET_DEVICE',
//     };
// };