

// import SmsAndroid from 'react-native-get-sms-android';


export const SendTheSms = async (message) => {

    // handleChange();
    console.log('hi send sms', message)
    // await SmsAndroid.autoSend(
    //     phonenumber,
    //     message,
    //     (fail) => {
    //         console.log('Failed with this error: ' + fail);
    //     },
    //     (success) => {
    //         console.log('SMS sent successfully');
    //     },
    // );
}


