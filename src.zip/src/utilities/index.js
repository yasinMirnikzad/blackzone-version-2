
import { PermissionsAndroid, I18nManager } from 'react-native';



// ------------ make timestamp 
function dec2Hex(dec) {
    return Math.abs(dec).toString(16);
}

function timestamp() {
    return dec2Hex(Math.floor(Date.now() / 1000));
}


I18nManager.allowRTL(false);

const requestSmsPermission = async () => {
    try {
        const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.SEND_SMS,
            // {
            //   title: 'مجوز پیامک',
            //   message:
            //     'اپلیکیشن بلک زون برای انجام تنظیمات نیاز به مجوز ارسال و دریافت پیامک دارد.',
            //   buttonNegative: 'غیرمجاز',
            //   buttonPositive: 'مجاز'
            // }
        );
        const granted2 = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.READ_SMS);
        const granted3 = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECEIVE_SMS);
        if (granted === PermissionsAndroid.RESULTS.GRANTED &&
            granted2 === PermissionsAndroid.RESULTS.GRANTED &&
            granted3 === PermissionsAndroid.RESULTS.GRANTED) {
        } else {
            console.log("Send sms permission denied");
        }
    } catch (err) {
        console.warn(err);
    }
}



export {
    timestamp,
    requestSmsPermission
}