


const SettingSItem = [
    // modat zaman azhir
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },
    {
        title: '',
        items: [{ label: '', id: '' }],
        value: '',
        changeFunction: '',
    },

]




export {
    SettingSItem
}