import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={33}
    height={27}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="M4.864 18.61V1.864h23.187V18.61m-9.017-5.152H13.88M30.627 25.05H2.288V18.61h28.34v6.44Z"
      stroke="#1EDBAD"
      strokeWidth={3}
      strokeLinecap="round"
    />
  </Svg>
)

export default SvgComponent
