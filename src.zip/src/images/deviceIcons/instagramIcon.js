import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={29}
    height={29}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="M20.898 1.576H8.017a6.44 6.44 0 0 0-6.44 6.44v12.882a6.44 6.44 0 0 0 6.44 6.44h12.881a6.44 6.44 0 0 0 6.441-6.44V8.017a6.44 6.44 0 0 0-6.44-6.44Z"
      stroke="#1EDBAD"
      strokeWidth={3}
      strokeLinecap="round"
    />
    <Path
      d="M20.829 13.513a6.44 6.44 0 1 1-12.742 1.89 6.44 6.44 0 0 1 12.742-1.89Z"
      stroke="#1EDBAD"
      strokeWidth={3}
      strokeLinecap="round"
    />
  </Svg>
)

export default SvgComponent
