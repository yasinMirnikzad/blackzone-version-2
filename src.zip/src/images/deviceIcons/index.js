


import Cubeicon from './cubeIcon';
import InstagramIcon from './instagramIcon';
import HomeIcon from './homeIcon';
import PrinterIcon from './printerIcon';


export {
    Cubeicon,
    InstagramIcon,
    HomeIcon,
    PrinterIcon
}