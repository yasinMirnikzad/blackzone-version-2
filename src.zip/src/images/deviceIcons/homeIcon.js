import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={30}
    height={32}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="M10.785 29.518V16.872h8.43v12.646M2.355 12.555 15 2.482l12.646 10.073V26.64c0 .763-.296 1.495-.823 2.035a2.777 2.777 0 0 1-1.987.843H5.164c-.745 0-1.46-.303-1.987-.843a2.913 2.913 0 0 1-.823-2.035V12.555Z"
      stroke="#1EDBAD"
      strokeWidth={3}
      strokeLinecap="round"
    />
  </Svg>
)

export default SvgComponent
