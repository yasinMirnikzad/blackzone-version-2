import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={29}
    height={32}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="m2.22 8.729 12.238 5.796L26.695 8.73M14.458 30.008V14.859m1.146-12.302L25.91 7.71a2.576 2.576 0 0 1 1.43 2.305v12.276a2.576 2.576 0 0 1-1.43 2.306L15.604 29.75a2.577 2.577 0 0 1-2.306 0L2.993 24.597a2.576 2.576 0 0 1-1.417-2.318V10.015a2.576 2.576 0 0 1 1.43-2.305l10.305-5.153a2.576 2.576 0 0 1 2.293 0Z"
      stroke="#1EDBAD"
      strokeWidth={3}
      strokeLinecap="round"
    />
  </Svg>
)

export default SvgComponent
