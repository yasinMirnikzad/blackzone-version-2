import * as React from "react"
import Svg, { Path, Circle } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={25}
    height={25}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="M13.207 6.42a3.657 3.657 0 1 1-7.315 0 3.657 3.657 0 0 1 7.315 0ZM16.342 17.391c.772 0 1.235-.831.734-1.418a9.871 9.871 0 0 0-7.526-3.458 9.871 9.871 0 0 0-7.525 3.458c-.502.587-.038 1.418.734 1.418h13.583Z"
      stroke="#fff"
      strokeWidth={1.5}
    />
    <Path
      d="M15.394 14.217c.249-.582.373-.873.515-1.09a3 3 0 0 1 3.544-1.183c.244.09.518.247 1.066.563.548.316.822.474 1.02.64a3 3 0 0 1 .756 3.66c-.118.23-.307.484-.685.99l-1.704 2.283a7.276 7.276 0 0 1-.268.349 3 3 0 0 1-3.604.743 7.301 7.301 0 0 1-.384-.214c-.197-.114-.296-.17-.378-.225a3 3 0 0 1-1.165-3.49 7.35 7.35 0 0 1 .168-.408l1.12-2.618Z"
      stroke="#fff"
      strokeWidth={1.5}
    />
    <Circle
      cx={18.084}
      cy={14.464}
      r={0.865}
      transform="rotate(29.95 18.084 14.464)"
      fill="#fff"
    />
    <Circle
      cx={18.084}
      cy={18.035}
      r={1.219}
      transform="rotate(29.95 18.084 18.035)"
      fill="#fff"
    />
  </Svg>
)

export default SvgComponent
