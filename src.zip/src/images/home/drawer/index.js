

import Moderates from './moderates';
import Bug from './bug';
import Setting from './setting';


export {
    Moderates,
    Bug,
    Setting
}