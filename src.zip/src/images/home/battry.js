import * as React from "react"
import Svg, { Rect, Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={16}
    height={26}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Rect
      x={1}
      y={3.592}
      width={14}
      height={21}
      rx={3.111}
      stroke="#fff"
      strokeWidth={1.556}
    />
    <Path
      d="M5.667 1.37c0-.43.348-.778.778-.778h3.11c.43 0 .779.348.779.778v1.555c0 .43-.349.778-.778.778H6.445a.778.778 0 0 1-.778-.778V1.37Z"
      fill="#fff"
    />
    <Path
      d="m9.018 7.592-3.333 5.714h5l-3.333 6.286"
      stroke="#fff"
      strokeWidth={1.556}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
)

export default SvgComponent
