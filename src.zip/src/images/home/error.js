import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={24}
    height={24}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="M6.83 9.07c1.995-3.455 2.993-5.183 4.432-5.437.36-.063.729-.063 1.089 0 1.44.254 2.437 1.982 4.432 5.438 1.995 3.456 2.993 5.184 2.493 6.557-.125.344-.31.663-.544.943-.94 1.12-2.935 1.12-6.926 1.12-3.99 0-5.985 0-6.925-1.12-.235-.28-.42-.6-.544-.943-.5-1.373.498-3.101 2.493-6.557Z"
      fill="#EB5757"
    />
    <Path
      d="M11.806 7.765v4.355m0 2.064v.83"
      stroke="#313131"
      strokeWidth={1.359}
      strokeLinecap="round"
    />
  </Svg>
)

export default SvgComponent
