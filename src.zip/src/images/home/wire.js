import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={17}
    height={31}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="m8.034 29.73 4.662-4.662c2.387-2.387.313-6.432-3.019-5.888l-4.237.692c-3.332.544-5.405-3.501-3.018-5.888l3.126-3.126m0 0-1.61-1.61a3.476 3.476 0 0 1 0-4.916l2.15-2.151 2.034 2.034m-2.574 6.643 1.61 1.61a3.476 3.476 0 0 0 4.916 0l2.15-2.15-2.034-2.035M8.122 4.215l3.072-3.072M8.122 4.215l4.068 4.068m0 0 3.073-3.072"
      stroke="#fff"
      strokeWidth={1.738}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
)

export default SvgComponent
