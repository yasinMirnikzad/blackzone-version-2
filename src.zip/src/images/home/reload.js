import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={24}
    height={25}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="m10.542 15.064-5.134.827.828 5.134"
      stroke="#fff"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Path
      d="M4.959 9.335a8 8 0 1 1 1.285 6.814"
      stroke="#fff"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
)

export default SvgComponent
