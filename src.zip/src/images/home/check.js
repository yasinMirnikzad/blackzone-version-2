import * as React from "react"
import Svg, { Rect, Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={15}
    height={16}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Rect
      x={0.002}
      y={0.256}
      width={14.811}
      height={14.811}
      rx={7.406}
      fill="#1EDAAD"
    />
    <Path
      d="m4.88 7.967 1.786 1.786 3.572-3.572"
      stroke="#313131"
      strokeWidth={1.191}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
)

export default SvgComponent
