import * as React from "react"
import Svg, { Rect, Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    width={35}
    height={35}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <Rect
      x={9.118}
      y={7.147}
      width={14.618}
      height={21.927}
      rx={3.248}
      stroke="#FFFFFF"
      strokeWidth={1.624}
    />
    <Path
      d="M13.99 4.827c0-.449.364-.812.812-.812h3.249c.448 0 .812.363.812.812V6.45a.812.812 0 0 1-.812.812h-3.249a.812.812 0 0 1-.812-.812V4.827Z"
      fill="#FFFFFF"
    />
    <Path
      d="m17.49 11.323-3.481 5.967h5.22l-3.48 6.563"
      stroke="#FFFFFF"
      strokeWidth={1.624}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <Rect
      x={18.515}
      y={18.632}
      width={15.465}
      height={15.465}
      rx={7.732}
      fill="#1EDAAD"
    />
    <Path
      d="m23.607 26.683 1.865 1.865 3.73-3.73"
      stroke="#fff"
      strokeWidth={1.243}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </Svg>
)

export default SvgComponent
