import * as React from "react"
import Svg, { Rect, Path } from "react-native-svg"

const SvgComponent = (props) => (
    <Svg
        width={34}
        height={35}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        {...props}
    >
        <Rect
            x={8.53}
            y={7.147}
            width={14.618}
            height={21.927}
            rx={3.248}
            stroke="#FFFFFF"
            strokeWidth={1.624}
        />
        <Path
            d="M13.402 4.827c0-.449.364-.812.812-.812h3.249c.448 0 .812.363.812.812V6.45a.812.812 0 0 1-.812.812h-3.249a.812.812 0 0 1-.812-.812V4.827Z"
            fill="#FFFFFF"
        />
        <Path
            d="m16.901 11.323-3.48 5.967h5.22l-3.48 6.563"
            stroke="#FFFFFF"
            strokeWidth={1.624}
            strokeLinecap="round"
            strokeLinejoin="round"
        />
        <Path
            d="M20.098 24.353c2.083-3.609 3.125-5.413 4.628-5.678.376-.066.76-.066 1.137 0 1.502.265 2.544 2.07 4.627 5.678 2.084 3.608 3.125 5.412 2.603 6.846-.13.36-.323.692-.568.985-.98 1.169-3.064 1.169-7.23 1.169-4.167 0-6.25 0-7.232-1.17a3.27 3.27 0 0 1-.568-.983c-.522-1.434.52-3.239 2.603-6.847Z"
            fill="#EB5757"
        />
        <Path
            d="M26.004 22.99a.71.71 0 0 0-1.42 0h1.42Zm-1.42 4.547a.71.71 0 0 0 1.42 0h-1.42Zm1.42 2.155a.71.71 0 0 0-1.42 0h1.42Zm-1.42.866a.71.71 0 0 0 1.42 0h-1.42Zm0-7.569v4.548h1.42V22.99h-1.42Zm0 6.703v.866h1.42v-.866h-1.42Z"
            fill="#fff"
        />
    </Svg>
)

export default SvgComponent
