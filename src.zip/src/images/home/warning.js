import * as React from "react"
import Svg, { Path } from "react-native-svg"

const SvgComponent = (props) => (
  <Svg
    {...props}
    width={25}
    height={25}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <Path
      d="M7.01 9.886c2.083-3.608 3.125-5.413 4.628-5.678.376-.066.76-.066 1.136 0 1.503.265 2.545 2.07 4.628 5.678s3.125 5.412 2.603 6.847a3.27 3.27 0 0 1-.568.984c-.981 1.169-3.065 1.169-7.231 1.169-4.167 0-6.25 0-7.23-1.17a3.273 3.273 0 0 1-.57-.983c-.521-1.435.52-3.239 2.604-6.847Z"
      fill="#FFC807"
    />
    <Path
      d="M12.206 8.522v4.548m0 2.155v.867"
      stroke="#313131"
      strokeWidth={1.419}
      strokeLinecap="round"
    />
  </Svg>
)

export default SvgComponent
