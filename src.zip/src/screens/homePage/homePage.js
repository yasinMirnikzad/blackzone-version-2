import React, { useState, useRef, useEffect } from 'react';

import {
  StatusBar,
  StyleSheet,
  View,
  ImageBackground,
  TouchableOpacity,
  Dimenssions,
  BackHandler,
  Animated
} from 'react-native';

import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Feather';
import { useSelector, useDispatch } from 'react-redux';
import { timestamp } from '../../utilities';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';
import moment from 'jalali-moment';
import Toast from 'react-native-toast-message'

// ----------- component
import { Text, SelectSimModal } from '../../components';

// ----------- color
import { Background, gray, Primary, Seccondary } from '../../config/colors.json';

// ----------- images
import {
  SimCard, Lock, Reload
} from '../../images/home';

import {
  ChargedSimCard, ConnectionFalse, ConnectionTrue,
  FullBattery, SimCardWithOutCharge,
  SimCardWithLowCharge, EmptyBattery
} from '../../images/home/collapse';








const App = () => {
  const dispatch = useDispatch();
  const select_device = useSelector((store) => store.selected_device.device);

  const [SelectedSimModal, changeSelectedSimModal] = useState({
    show: false,
    message: '',
    return_func: null,
    value: ''
  });
  const [dingDong, changeDingDong] = useState(0);
  const [power, chagnePower] = useState(0);
  const [rele, changeRele] = useState(0);
  const [AppControl, changeAppControl] = useState('');



  const ResponseData = async (val) => {
    // GD , R1, ARC- ARS -> in 4 halat bayd khodeshon biteshono taqir bedan

    // ARS , ARC -> bit ->message.slice(10, 11) - A=1 , S=2 ,D=0

    // R1  let relebtn = message.slice(23, 24); - 0,P,T -> false , 1->true

    // GD dingdong let dingdang = message.slice(16, 17); - D=true , 0=false

    const device = JSON.parse(await AsyncStorage.getItem('devices'));
    let newmsg = device[select_device.id].lastMessage.split('');

    if (AppControl === 'power') {
      let newStatus = val === 0 ? 'D' : val === 1 ? 'A' : 'S';
      chagnePower(val);
      newmsg[10] = newStatus;
    }

    // inja mitone 0,P,T bashe vali chon nashode ma hamon 0 mizarim :D
    if (AppControl === 'rele') {
      let newrele = val === true ? '1' : '0';
      changeRele(newrele);
      newmsg[23] = '1';
    }
    if (AppControl === 'dingdong') {
      let newdingdong = val === true ? 'D' : '0';
      newmsg[16] = newdingdong;
      changeDingDong(val)
    }

    device[select_device.id].lastMessage = newmsg.join('');
    await AsyncStorage.setItem('devices', JSON.stringify(device));
    await dispatch(setDevice(device[selectedDevice.id]));


    Toast.show('دستور ارسال شد.نتیجه ازطریق پیامک اطلاع‌رسانی می‌شود.', {
      type: "success",
    });
    console.log('response')
  }


  return (
    <View style={styles.container}>
      <StatusBar
        backgroundColor={'#3D3D3D'}
      />

      <Drawer />

      <ImageBackground
        source={require('../../images/home/background.png')}
        style={styles.backgroundImage} >


        <HomeBtn
          select_device={select_device}
          changeSelectedSimModal={changeSelectedSimModal}
          SelectedSimModal={SelectedSimModal}
          return_func={ResponseData}
          key_val='GD'
          style={{
            backgroundColor: 'red',
            right: '24%',
            position: 'absolute',
            height: 80,
            width: 80,
            top: '20%'
          }}
          title='dingdong'
          {...{ changeAppControl }}
          appControl='dingdong'
        />



        <HomeBtn
          select_device={select_device}
          changeSelectedSimModal={changeSelectedSimModal}
          SelectedSimModal={SelectedSimModal}
          return_func={ResponseData}
          key_val='R1'
          style={{
            backgroundColor: 'red',
            left: '20%',
            position: 'absolute',
            height: 95,
            width: 95,
            top: '25%'
          }}
          title='rele'
          appControl='rele'
          {...{ changeAppControl }}
        />


        <HomeBtn
          select_device={select_device}
          changeSelectedSimModal={changeSelectedSimModal}
          SelectedSimModal={SelectedSimModal}
          return_func={ResponseData}
          key_val='ST'
          style={{
            backgroundColor: 'red',
            left: '15%',
            position: 'absolute',
            height: 105,
            width: 105,
            top: '47%'
          }}
          {...{ changeAppControl }}
          title='minunlock'
          appControl='power'
        />


        <HomeBtn
          select_device={select_device}
          changeSelectedSimModal={changeSelectedSimModal}
          SelectedSimModal={SelectedSimModal}
          return_func={ResponseData}
          key_val='DI'
          style={{
            backgroundColor: 'black',
            right: '10%',
            position: 'absolute',
            height: 150,
            width: 150,
            top: '40%'
          }}
          {...{ changeAppControl }}
          appControl='power'
          title='unlock'
        />

        <HomeBtn
          select_device={select_device}
          changeSelectedSimModal={changeSelectedSimModal}
          SelectedSimModal={SelectedSimModal}
          return_func={ResponseData}
          key_val='AW'
          style={{
            backgroundColor: 'black',
            position: 'absolute',
            height: 150,
            width: 150,
            bottom: '15%',
            alignSelf: 'center'
          }}
          {...{ changeAppControl }}
          appControl='power'
          title='lock'
        />

        <Footer />

      </ImageBackground>



      <SelectSimModal
        SelectedSimModal={SelectedSimModal}
        key_val={SelectedSimModal.value}
        changeModalShow={changeSelectedSimModal}
        return_func={SelectedSimModal.return_func}
      />



    </View>
  )
}

export default App;




const Drawer = (props) => {
  const dispatch = useDispatch();
  const height = useRef(new Animated.Value(0)).current;

  const select_device = useSelector((store) => store.selected_device.device);
  const [collapsed, setCollapsed] = useState(true);
  const [SelectedSimModal, changeSelectedSimModal] = useState({
    show: false,
    message: ''
  });

  const [status, setStatus] = useState({
    lastSynce: '',
    devicestatus: '',
    //-------------------------------------------agar ding dang faal bashe button ha bayad dar halat feshorde bashad(gharare befresti buuton ha ro)
    dingDang: select_device.lastMessage.slice(16, 17) === 'D' ? true : false,
    mainElectricity: select_device.lastMessage.slice(18, 19) === 'P' ? true : false,
    batteryCharge: parseInt(select_device.lastMessage.slice(19, 21)) === 'DD' ? '-1' :
      parseInt(select_device.lastMessage.slice(19, 21)) === 'FF' ? '100'
        : parseInt(select_device.lastMessage.slice(19, 21)),

    //-------------------------------------------moshakhas mkone ke button rele feshorde shodast ya na
    releBtn: select_device.lastMessage.slice(23, 24) === '1' ? true : false,
    simCard: '',
    simCardCharge: Math.floor(parseInt(select_device.lastMessage.slice(113, 120)) / 10)
  });

  const toggleExpanded = () => {
    setCollapsed(!collapsed);
  };

  // -------------- height for collapse
  const maxHeight = height.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1300]
  });




  // -------------- useEffect
  useEffect(() => {
    GetData(select_device.lastMessage)
  }, [])
  useEffect(() => {
    Animated.timing(height, {
      toValue: collapsed ? 0 : 1,
      duration: 500,
      useNativeDriver: false
    }).start();
  }, [collapsed]);


  // -------------- response function for proccess
  const UpdateMessage = async (message) => {
    const device = JSON.parse(await AsyncStorage.getItem('devices'));
    device[select_device.id].lastMessage = message;
    await AsyncStorage.setItem('devices', JSON.stringify(device));
    await dispatch(setDevice(device[select_device.id]));
    await GetData(message);
  }

  const GetData = async (message) => {
    console.log('response is ', message)
    let theStatus = {};
    try {
      //----------------------------------update last synce 
      let timeStamp = message.slice(1, 9);

      // let options = { year: 'numeric', month: 'long', day: 'numeric' };
      // let today = new DateTimeFormat('fa-IR', { dateStyle: 'full', timeStyle: 'long' }).format(new Date(2022, 2, 1));
      // let today = new Intl.DateTimeFormat('fa-IR', { dateStyle: 'full', timeStyle: 'long' }).format(parseInt(timestamp(), 16) * 1000);
      // console.log(today);

      //----------------------------------ghablesh bayad formatesh az hegza be binary tabdil beshe


      let day = new Date(parseInt(timeStamp, 16) * 1000).getDate();
      let month = new Date(parseInt(timeStamp, 16) * 1000).getMonth() + 1;
      let year = new Date(parseInt(timeStamp, 16) * 1000).getFullYear();
      let theDate = moment(year + '/' + month + '/' + day, 'YYYY/M/D').locale('fa').format('YYYY/MM/DD');
      theStatus.lastSynce = theDate + ' ساعت ' +
        new Date(parseInt(timeStamp, 16) * 1000).getHours() + ':' + new Date(parseInt(timeStamp, 16) * 1000).getMinutes();
      ;

      //----------------------------------update devices status
      let devicestatus = message.slice(10, 11);
      switch (devicestatus) {
        case 'A':
          theStatus.devicestatus = 'فعال';
          // changeDeviceBtnStatus(1)
          break;
        case 'S':
          theStatus.devicestatus = 'نیمه‌فعال';
          // changeDeviceBtnStatus(2)
          break;
        case 'D':
          theStatus.devicestatus = 'غیر‌فعال';
          // changeDeviceBtnStatus(0)
          break;
        default:
          break;
      }

      //-----------------------------------update ding dang
      let dingdang = message.slice(16, 17);
      switch (dingdang) {
        case 'D':
          theStatus.dingDang = true;
          break;
        case '0':
          theStatus.dingDang = false;
          break;
        default:
          break;
      }

      //----------------------------------vasl bodan be bargh asli
      let electricity = message.slice(18, 19);
      switch (electricity) {
        case 'P':
          theStatus.mainElectricity = true;
          break;
        case 'B':
          theStatus.mainElectricity = false;
          break;
        default:
          break;
      }

      //-----------------------------------meghdar charge battery va vaziate etesal 
      let batterycharge = message.slice(19, 21);
      switch (batterycharge) {
        case 'DD':
          theStatus.batteryCharge = '-1';
          break;
        case 'FF':
          theStatus.batteryCharge = '100';
          break;
        default:
          theStatus.batteryCharge = parseInt(batterycharge);
          break;
      }

      //-----------------------------------update vaziat rele
      let relebtn = message.slice(23, 24);
      switch (relebtn) {
        case '0':
          //---------------------------gheyr faal
          theStatus.releBtn = false;
          break;
        case '1':
          //---------------------------faal dar halate switch
          theStatus.releBtn = true;
          break;
        case 'P':
          //---------------------------faal dar halate puls
          theStatus.releBtn = false;
          break;
        case 'T':
          //---------------------------faal dar halate timer
          theStatus.releBtn = false;
          break;
        default:
          break;
      }

      //---------------------------------------update operator simcart
      let simCard = message.slice(112, 113);

      switch (simCard) {
        case 'M':
          theStatus.simCard = 'همراه اول';
          break;
        case 'R':
          theStatus.simCard = 'رایتل';
          break;
        case 'I':
          theStatus.simCard = 'ایرانسل';
          break;
        case 'U':
          theStatus.simCard = 'شناسایی نشده';
          break;
        default:
          break;
      }

      //----------------------------------------update charge simcart
      let simcardcharge = message.slice(113, 120);

      theStatus.simCardCharge = Math.floor(parseInt(simcardcharge) / 10);


      //----------------------------------------vaziat bolandgo khareji
      let speaker = message.slice(120, 121);
      // if (speaker === 0)
      //   toast.show('بلندگوی خارجی قطع است', {
      //     type: "danger ",
      //   });

      //----------------------------------------vaziat sensor ha
      let sensor = message.slice(121, 122);
      // if (sensor === 0)
      //   toast.show('نقض در فیوز سنسورها', {
      //     type: "danger ",
      //   });

      // let moderates = await UpdateModerators(message);
      // let contacts = await UpdateContacts(message);



      await setStatus(theStatus);
    } catch (err) {
      console.log('change home screen data error : ', err);
    }

  }

  const HamgamSazi = async () => {
    let time2 = timestamp();

    const message = 'DSTT' + ';' + select_device.device_securitycode + ';' +
      time2 + ';' + select_device.device_phonenumber.split('').reverse().join('') + ';';


    await changeSelectedSimModal({
      ...SelectedSimModal,
      show: true,
      message
    })
  }


  const UpdateModerators = async (message) => {
    let moderatorsstatus = message.slice(26, 30);
    let Users = [];
    for (let i = 0; i < 4; i++) {
      let user = {
        id: i, title: `مدیر شماره${i + 1}`, status: moderatorsstatus[i]
      }
      await Users.push(user);
    }
    return Users;
  }

  const UpdateContacts = async () => {
    let contactsstatus = message.slice(30, 46);

    let Users = [];
    for (let i = 0; i < 4; i++) {
      let user = {
        id: i, title: `مخاطب شماره${i + 1}`, status: contactsstatus[i]
      }
      await Users.push(user);
    }
    return Users;
  }


  return (
    <View style={styles.headerContainer}>
      {/* start content */}
      <Animated.View
        style={{
          width: '100%',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 12
          },
          shadowOpacity: 0.58,
          shadowRadius: 16.00,
          elevation: 24,
          maxHeight: maxHeight
        }}
      >


        {!collapsed &&
          <View style={styles.headerMenuContent}>


            <TouchableOpacity style={styles.headerMenuFAQ}>
              <Text>راهنما</Text>
              <Icon name='alert-circle' style={styles.headerMenuFAQIcon} />
            </TouchableOpacity>

            <View style={styles.headerMenuTitleContainer}>
              <Text fontWeight='Bold' style={{ fontSize: 24 }}>{select_device.name}</Text>
              <Lock />
            </View>

            <TouchableOpacity
              activeOpacity={.5}
              style={styles.headerMenuPhoneNumber}>
              <Icon style={styles.headerMenuPhoneIcon} name='edit' />

              <View style={styles.headerMenuPhone}>
                <Text >{select_device.device_phonenumber}</Text>
                <Text>{status.simCard}</Text>
              </View>

              <SimCard

                color={status.simCard === 'همراه اول' ?
                  '#55C5D1'
                  : status.simCard === 'رایتل' ?
                    '#C13187' : '#FFC807'}
              />

            </TouchableOpacity>

            <View style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: 12,
              width: '100%'
            }}>

              <StatusBox
                icon={status.batteryCharge === '-1' ? <EmptyBattery /> : <FullBattery />}

                status={status.batteryCharge === '-1' ? 'باطری قطع'
                  : ' باطری ' + status.batteryCharge + '%'}

                color={status.batteryCharge === '-1' && "#EB5757"}

              />


              <StatusBox
                icon={status.simCardCharge < 2000 ? <SimCardWithLowCharge />
                  : status.simCardCharge < 1000 ? <SimCardWithOutCharge /> : <ChargedSimCard />}

                status={status.simCardCharge + ' تومان'}
                title='اعتبار سیم کارت'
                color={status.simCardCharge < 2000 ? '#FFC807'
                  : status.simCardCharge < 1000 && "#EB5757"}
              />

              <StatusBox
                icon={status.mainElectricity ? <ConnectionTrue /> : <ConnectionFalse />}
                status={status.mainElectricity ? 'برق متصل' : 'برق قطع'}
                title='برق اصلی'
                color={!status.mainElectricity && '#FF5D5D'}
              />
            </View>
            <View style={styles.HeaderMenueTime}>
              <Text fontWeight='Medium' style={{ marginRight: 5 }}>{status.lastSynce}</Text>
              <Text fontWeight='Medium' style={{ color: '#9E9E9E' }}>آخرین همگام‌سازی:</Text>
            </View>

          </View>
        }
      </Animated.View>
      {/*end content */}

      {/* start header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          {collapsed ?
            <View style={styles.statusIconContainer}>
              {status.simCardCharge < 1000 ? <SimCardWithLowCharge />
                : status.simCardCharge < 2000 ? <SimCardWithOutCharge /> : <ChargedSimCard />}
              {status.mainElectricity ? <ConnectionTrue /> : <ConnectionFalse />}
              {status.mainElectricity ? <EmptyBattery /> :
                status.batteryCharge === '-1' ? <EmptyBattery /> : <FullBattery />}
            </View>
            :

            <TouchableOpacity
              onPress={HamgamSazi}
              style={styles.syncBtn}>
              <Text fontWeight='Bold' style={{ fontSize: 17, marginRight: 7 }} >همگام سازی</Text>
              <Reload />


            </TouchableOpacity>
          }
        </View>


        {collapsed &&
          <TouchableOpacity
            onPress={toggleExpanded}
            style={styles.headerText}
          >
            <Text fontWeight='Medium' style={{ fontSize: 20 }}>{select_device.name}</Text></TouchableOpacity>
        }
        <TouchableOpacity
          onPress={toggleExpanded}
          style={styles.headerArrowBtn}>
          {collapsed ?
            <Icon name='chevron-down' allowFontScaling style={styles.headerArrowIcon} />
            :
            <Icon name='chevron-up' allowFontScaling style={styles.headerArrowIcon} />
          }

        </TouchableOpacity>

      </View>
      {/* end header */}

      <SelectSimModal
        SelectedSimModal={SelectedSimModal}
        changeModalShow={changeSelectedSimModal}
        return_func={UpdateMessage}
      />

    </View>
  )
}


const StatusBox = (props) => {
  return (
    <View
      style={{ ...styles.statusBox, borderColor: props.color ? props.color : '#313131' }}
    >
      {props.icon}
      {/* <HeaderIcon
        TIcon={props.TIcon}
        notif={props.notif}
      /> */}

      <Text fontWeight='Bold' style={{ fontSize: 16, marginTop: 15 }}>{props.status}</Text>
      <Text fontWeight='Medium' style={{ fontSize: 12 }}>{props.title}</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Background,
    flex: 1
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  // header and top menue
  headerContainer: {
    backgroundColor: Seccondary,
    paddingHorizontal: 12,
    paddingVertical: 28,
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'column',
    borderBottomLeftRadius: 18,
    borderBottomRightRadius: 18,
    position: 'absolute',
    top: 0,
    width: '100%',
    zIndex: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.00,
    elevation: 24,

  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  headerMenuFAQ: {
    borderWidth: 1,
    borderColor: gray,
    paddingHorizontal: 13,
    borderRadius: 20,
    alignSelf: 'flex-start',
    paddingVertical: 6,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center'
  },
  headerMenuFAQIcon: {
    marginLeft: 5,
    color: '#56CCF2',
    fontSize: 20
  },
  headerText: {
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '500',
    color: 'white',
    marginRight: 10
  },
  headerIconContainer: {
    marginHorizontal: 8
  },
  syncBtn: {
    borderColor: Primary,
    borderWidth: 2,
    borderRadius: 10,
    flexDirection: 'row',
    height: 53,
    width: '70%',
    justifyContent: 'center',
    alignItems: 'center'
  },
  headerNotifIcon: {
    position: 'absolute',
    right: -8,
    bottom: -8
  },
  headerArrowBtn: {
    height: 40,
    width: 40,
    borderRadius: 12,
    backgroundColor: Primary,
    justifyContent: 'center',
    alignItems: 'center'
  },
  headerArrowIcon: {
    fontWeight: 'bold',
    fontSize: 27,
    color: '#232323'
  },
  headerLeft: {
    flexDirection: 'row',
    flex: 1
  },
  headerMenuContent: {
    backgroundColor: Seccondary,
    width: '100%',
    alignItems: 'flex-end'
  },
  HeaderMenueTime: {
    flexDirection: 'row',
    marginBottom: 25,
    marginTop: 10
  },
  headerMenuTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  statusIconContainer: {
    flexDirection: 'row'
  },
  statusBox: {
    flexDirection: 'column',
    height: 125,
    width: '32%',
    // flex: 1,
    borderWidth: 2,
    // margin: 7,
    borderRadius: 12,
    paddingHorizontal: 11,
    paddingVertical: 16,
    backgroundColor: '#313131',
    // borderColor: '',
    alignItems: 'flex-end'
  },
  statusBoxItem: {
    height: 100,
    width: 50,
    margin: 10,
    borderWidth: 2,
    borderColor: 'red',
    borderRadius: 10
  },

  headerMenuPhoneNumber: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: '#313131',
    height: 65,
    borderRadius: 12,
    marginTop: 20,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingHorizontal: 8
  },
  headerMenuPhoneIcon: {
    position: 'absolute',
    left: 24,
    fontSize: 20,
    color: 'white'
  },
  headerMenuPhone: {
    marginRight: 20
  },
  statusbarReload: {
    color: 'white'
  },
  active: {
    backgroundColor: 'rgba(255,255,255,1)',
  },
  inactive: {
    backgroundColor: 'rgba(245,252,255,1)',
  },
  // footer
  footer: {
    height: 70,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'transparent',
    paddingBottom: 10,
    position: 'absolute',
    bottom: 0,
    width: '100%'
  }

});


const Footer = (props) => {
  const navigation = useNavigation();

  return (
    <View style={styles.footer} >

      <TouchableOpacity style={footerStyle.footerBtn} >
        <Icon style={footerStyle.footerBtnIcon} name='home' />
      </TouchableOpacity>

      <View style={footerStyle.centerContainer}>
        <Text fontWeight='Bold' style={footerStyle.centerTitle}>بلک زون</Text>
        <Text style={footerStyle.centerDescription}>دزدگیر هوشمند</Text>
      </View>

      <TouchableOpacity
        onPress={() => navigation.openDrawer()}
        style={footerStyle.footerBtn} >
        <Icon style={footerStyle.footerBtnIcon} name='menu' />
      </TouchableOpacity>


    </View >
  )
}

const footerStyle = StyleSheet.create({

  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%'
  },
  footerBtn: {
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    width: 70
  },
  footerBtnIcon: {
    color: Primary,
    fontSize: 33
  },
  centerTitle: {
    fontSize: 20
  }, centerDescription: {
    color: gray,
    fontSize: 14
  }

})


const HomeBtn = (props) => {
  const onClick = async () => {
    let time = timestamp();
    let mode = 'ARC'; // in bayad moshakhas she ARS ya ARC bashe

    await props.changeAppControl(props.appControl)

    let message = mode + ';' + props.select_device.device_securitycode + ';'
      + props.key_val + ';' + time + ';' +
      props.select_device.device_phonenumber.split('').reverse().join('') + ';';

    await props.changeSelectedSimModal({
      show: true,
      message: message,
      return_func: props.return_func,
      value: props.key_val
    })

  }

  return (
    <TouchableOpacity
      onPress={onClick}
      style={[homeBtnstyle.homeBtn,
      props.style
      ]}>
      <Text>{props.title}</Text>
    </TouchableOpacity>
  )
}



const homeBtnstyle = StyleSheet.create({
  homeBtn: {
    height: 100,
    width: 100,
    borderRadius: 100,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center'
  }
});



