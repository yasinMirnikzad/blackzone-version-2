import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

import { useSelector, useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';



import { EditHeader, Text, Modal, BottomBtn, TimePicker, SelectSimModal } from '../../components';
import ShiftPicker from '../../components/shiftModalComponent';
import { Background, gray, Primary, Seccondary } from '../../config/colors.json';


// ------- utilities
import { timestamp } from '../../utilities';



const SettingPage = (props) => {
    const select_device = useSelector((store) => store.selected_device.device);

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [modalTimeVisible, changeModalTimeVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null
    });
    const [modalTimeShiftVisible, changeModalTimeShiftVisible] = useState({
        show: false,
        title: '',
        step: 0,
        selected_first_item: null,
        changeSelected_first_item: null,
        selected_end_item: null,
        changeSelected_end_item: null,
    });
    const [SelectedSimModal, changeSelectedSimModal] = useState({
        show: false,
        message: '',
        return_func: null
    })

    const [modalData, changeModalData] = useState([]);
    //------- states
    const [name, changeName] = useState('');
    const [alarmDuration, changeAlarmDuration] = useState();
    const [hornDelay, changeHornDelay] = useState();
    const [chirpMode, changeChirpMode] = useState();
    const [relayMode, changeRelayMode] = useState();
    const [relayPulseWidth, changeRelayPulseWidth] = useState();
    const [releTime, changeReleTime] = useState({
        seccond: '&&',
        minute: '&&',
        hour: '&&',
    })
    const [synchronRelayStartDelay, changeSynchronRelayStartDelay] = useState();
    const [remoteDKey, changeRemoteDKey] = useState();
    const [entryTime, changeEntryTime] = useState();
    const [exitTime, changeExitTime] = useState();
    const [roaming, changeRoaming] = useState();
    const [summerTimeZone, changeSummerTimeZone] = useState();

    const [shift1, changeShift1] = useState({
        startH: '00',
        startM: '00',
        endH: '00',
        endM: '00',
    })
    const [shift2, changeShift2] = useState({
        startH: '00',
        startM: '00',
        endH: '00',
        endM: '00',
    })
    const [shift3, changeShift3] = useState({
        startH: '00',
        startM: '00',
        endH: '00',
        endM: '00',
    })

    // -------------------- start redux dispatch
    const dispatch = useDispatch();

    // ------ list of values
    const SettingItems = [
        // 0
        // {
        //     title: 'نام دستگاه:',
        //     border: true,
        //     input: true,
        //     value: name, // a state
        //     changeFunction: changeName, // function to change state
        // },
        // modat zaman azhir 1
        {
            title: 'مدت زمان آژیر',
            items: [
                { label: 'سایلنت', id: '00' },
                { label: '1 دقیقه', id: '01' },
                { label: '3 دقیقه', id: '03' },
                { label: '5 دقیقه', id: '05' },
                { label: '10 دقیقه', id: '10' },
                { label: '15 دقیقه', id: '15' },
                { label: '20 دقیقه', id: '20' }
            ],
            value: alarmDuration, // a state
            changeFunction: changeAlarmDuration, // function to change state
        },
        // 2
        {
            title: 'زمان تاخیر پخش آژیر',
            items: [{ label: 'بدون تاخیر', id: '00' },
            { label: '10 ثانیه', id: '10' },
            { label: '20 ثانیه', id: '20' },
            { label: '30 ثانیه', id: '30' }],
            value: hornDelay,
            changeFunction: changeHornDelay,
        },
        // 3
        {
            title: 'نحوه پخش تک‌آژیر',
            items: [
                { label: 'سیرن', id: 'S' },
                { label: 'بلندگوی داخلی', id: 'I' },
                { label: 'بلندگوی خارجی', id: 'E' }],
            value: chirpMode,
            changeFunction: changeChirpMode,
        },
        // 4
        {
            title: 'حالت عملکرد رله',
            items: [{ label: 'روشن / خاموش', id: 'S' },
            { label: 'تایمر‌دار', id: 'T' },
            { label: 'پالسی', id: 'P' },
            { label: 'هم‌زمانی با آژیر', id: 'A' },
            ],
            value: relayMode,
            changeFunction: changeRelayMode,
        },
        // in monde 5
        {
            title: 'زمان عملکرد رله در حالت تایمر',
            items: [],
            value: releTime,
            changeFunction: changeReleTime,
            // clock
            clock: true
        },
        // 6
        {
            title: 'زمان تاخیر رله در حالت پالس',
            items: [
                { label: '500 میلی ثانیه', id: '05' },
                { label: '1 ثانیه', id: '0A' },
                { label: '3 ثانیه', id: '1E' },
                { label: '5 ثانیه', id: '32' },
                { label: '10 ثانیه', id: '64' }
            ],
            value: relayPulseWidth,
            changeFunction: changeRelayPulseWidth,
        },
        // 7
        {
            title: 'زمان تاخیر رله در حالت همزمانی',
            items: [
                { label: '۱۰ ثانیه', id: '0A' },
                { label: '۲۰ ثانیه', id: '14' },
                { label: '۳۰ ثانیه', id: '1E' },
                { label: '۱ دقیقه', id: '3C' },
                { label: '3 دقیقه', id: 'B4' },
            ],
            border: true,
            value: synchronRelayStartDelay,
            changeFunction: changeSynchronRelayStartDelay,
        },
        // 8
        {
            title: 'عملکرد کلید چهارم ریموت',
            items: [
                { label: 'آژیر آزاد', id: '100' },
                { label: 'کنترل رله', id: '101' },
                { label: 'دینگ‌دانگ', id: '110' },
                { label: 'درخواست کمک', id: '111' }
            ],
            border: true,
            value: remoteDKey,
            changeFunction: changeRemoteDKey,
            // --?? check she vase chie
            dkey: true
        },
        // 9
        {
            title: 'تاخیر ورود در زون‌های تاخیری',
            items: [
                { label: '۱۰ ثانیه', id: '0A' },
                { label: '۲۰ ثانیه', id: '14' },
                { label: '۳۰ ثانیه', id: '1E' },
                { label: '۱ دقیقه', id: '3C' },
                { label: '۳ دقیقه', id: 'B4' },
            ],
            value: entryTime,
            changeFunction: changeEntryTime,
        },
        // 10
        {
            title: 'تاخیر خروج در زون‌های تاخیری',
            items: [
                { label: '۱۰ ثانیه', id: '0A' },
                { label: '۲۰ ثانیه', id: '14' },
                { label: '۳۰ ثانیه', id: '1E' },
                { label: '۱ دقیقه', id: '3C' },
                { label: '۳ دقیقه', id: 'B4' },
            ],
            border: true,
            value: exitTime,
            changeFunction: changeExitTime
        },
        // 11
        {
            title: 'رومینگ',
            items: [
                { label: 'فعال', id: '11' },
                { label: 'غیر‌فعال', id: '10' }
            ],
            border: true,
            value: roaming,
            changeFunction: changeRoaming,
        },
        // 12
        {
            title: 'ساعت تابستانی',
            items: [
                { label: 'فعال', id: '11' },
                { label: 'غیر‌فعال', id: '10' }
            ],
            border: true,
            value: summerTimeZone,
            changeFunction: changeSummerTimeZone,
        }
    ]

    const SettingItemShifts = [
        {
            title: ' شیفت صبح',
            selected_first_item: { hour: shift1.startH, minute: shift1.startM },
            selected_end_item: { hour: shift1.endH, minute: shift1.endM },
            changeSelected_item: changeShift1
        },
        {
            title: ' شیفت عصر ',
            selected_first_item: { hour: shift2.startH, minute: shift2.startM },
            selected_end_item: { hour: shift2.endH, minute: shift2.endM },
            changeSelected_item: changeShift1
        },
        {
            title: ' شیفت شب',
            selected_first_item: { hour: shift3.startH, minute: shift3.startM },
            selected_end_item: { hour: shift3.endH, minute: shift3.endM },
            changeSelected_item: changeShift1
        }
    ]

    // ----------------------functions 
    const hex = d => Number(d).toString(16).padStart(3, '0')

    // check she raveshesh oke :D
    const Shift = async (hour, minute) => {
        let shift = (await (parseInt(hour) * 60) + parseInt(minute));

        if (shift === '000')
            return '&&&';
        else
            return hex(shift);
    }


    // ---------------------- to sync the values
    const HamgamSazi = async () => {
        let time2 = timestamp();

        const message = 'DSET' + ';' + select_device.device_securitycode + ';' +
            time2 + ';' + select_device.device_phonenumber.split('').reverse().join('') + ';';

        console.log('message', message)
        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message,
            return_func: updateData
        })
    }

    const SendMessage = async () => {
        // await requestSmsPermission();
        let time2 = timestamp();
        // await SetLoadingVisible(true);
        let theName = name;
        //--------------------------------------------------------------check kardan tedad char name
        if (name.length < 14)
            theName += ';';

        let alarm_duration = alarmDuration ? SettingItems[1].items[alarmDuration].id : '&&';
        let horn_delay = hornDelay ? SettingItems[2].items[hornDelay].id : '&&';
        let chirp_mode = chirpMode ? SettingItems[3].items[chirpMode].id : '&';
        let relay_pulse_width = relayPulseWidth ? SettingItems[6].items[relayPulseWidth].id : '&&';
        let relay_mode = relayMode ? SettingItems[4].items[relayMode].id : '&';
        let synchron_relayStartDelay = synchronRelayStartDelay ? SettingItems[7].items[synchronRelayStartDelay].id : '&&';


        let message = 'P' + 'S' + select_device.device_securitycode + time2 + theName.padEnd(14, '0') +
            await Shift(shift1.startH, shift1.startM) + await Shift(shift1.endH, shift1.endM) +
            await Shift(shift2.startH, shift2.startM) + await Shift(shift2.endH, shift2.endM) +
            await Shift(shift3.startH, shift3.startM) + await Shift(shift3.endH, shift3.endM) +
            alarm_duration
            +
            horn_delay
            +
            chirp_mode
            + releTime.hour +
            releTime.minute +
            releTime.seccond +
            relay_pulse_width
            +
            relay_mode
            +
            synchron_relayStartDelay;


        let msg = roaming === '00' ? roaming : SettingItems[11].items[roaming].id
            + remoteDKey === '000' ? remoteDKey : SettingItems[9].items[remoteDKey].id
                + summerTimeZone === '00' ? summerTimeZone : SettingItems[12].items[summerTimeZone].id

        // in bayad ezfe she
        // if (fourthKeyDelayFunction)
        //     msg += '1';
        // else
        msg += '0';

        let entry_time = entryTime ? SettingItems[9].items[entryTime].id : '&&';
        let exit_time = exitTime ? SettingItems[10].items[exitTime].id : '&&';

        if (msg === '00000000')
            message += '&&' +
                entry_time
                + exit_time
        else
            message += await parseInt(msg, 2).toString(16).padStart(2, '0') +
                entry_time
                + exit_time

        // ------------------------------------------------



        console.log('message', message)
        // await changeSelectedSimModal({
        //     ...SelectedSimModal,
        //     show: true,
        //     message,
        //     return_func: updateData
        // })

        // changeExitModal(false);
        // changeChangeData(false);
        // await SendSms(message.toUpperCase(), await checkPhoneNum(selectedDevice.phonenumber));
        // await GetSms(time, time2.toUpperCase());
    };

    const updateData = async (message) => {
        console.log('message', message)
        //----------------------------------------------set contact name
        let name = message.slice(16, 30);
        for (let i = 0; i < name.length; i++) {
            if (name[i] === ';') {
                name = name.slice(0, i);
                break;
            }
        }
        await changeName(name);
        // if (name != selectedDevice.name)
        //     await ChangeDeviceName(name);

        //------------------------------------------------set shift 1
        let shifbytes = message.slice(30, 33);
        let shift = parseInt(shifbytes, 16);

        // await changeshift1StartH(await parseInt(shift / 60).toString().padStart(2, '0'));
        // shiftItems[0].start[0] = await parseInt(shift / 60).toString().padStart(2, '0');
        // await changeshift1StartM(await (shift % 60).toString().padStart(2, '0'));
        // shiftItems[0].start[1] = await (shift % 60).toString().padStart(2, '0');



        let shifbytes2_local = await message.slice(33, 36);
        let shift2_local = parseInt(shifbytes2_local, 16);


        // await changeshift1EndH(await parseInt(shift / 60).toString().padStart(2, '0'));
        // shiftItems[0].end[0] = await parseInt(shift / 60).toString().padStart(2, '0');
        // await changeshift1EndM((await shift % 60));
        // shiftItems[0].end[1] = await (shift % 60).toString().padStart(2, '0');


        await changeShift1({
            ...shift1,
            startH: await parseInt(shift / 60).toString().padStart(2, '0'),
            startM: await (shift % 60).toString().padStart(2, '0'),
            endH: await parseInt(shift2_local / 60).toString().padStart(2, '0'),
            endM: await shift2_local % 60
        })

        //------------------------------------------------set shift 

        shifbytes = await message.slice(36, 39);
        shift = parseInt(shifbytes, 16);


        // await changeshift2StartH(await parseInt(shift / 60).toString().padStart(2, '0'));
        // shiftItems[1].start[0] = await parseInt(shift / 60).toString().padStart(2, '0');
        // await changeshift2StartM((await shift % 60));
        // shiftItems[1].start[1] = await (shift % 60).toString().padStart(2, '0');

        shifbytes2_local = await message.slice(39, 42);
        shift2_local = parseInt(shifbytes2_local, 16);


        // await changeshift2EndH(await parseInt(shift / 60).toString().padStart(2, '0'));
        // shiftItems[1].end[0] = await parseInt(shift / 60).toString().padStart(2, '0');
        // await changeshift2EndM((await shift % 60));
        // shiftItems[1].end[1] = await (shift % 60).toString().padStart(2, '0');
        console.log('shift2 test', await parseInt(shift / 60).toString().padStart(2, '0'))
        console.log('shift2 test', await (shift % 60).toString().padStart(2, '0'))
        await changeShift2({
            ...shift2,
            startH: await parseInt(shift / 60).toString().padStart(2, '0'),
            startM: await (shift % 60).toString().padStart(2, '0'),
            endH: await parseInt(shift2_local / 60).toString().padStart(2, '0'),
            endM: await shift2_local % 60
        })

        //------------------------------------------------set shift 3
        shifbytes = await message.slice(42, 45);
        shift = parseInt(shifbytes, 16);


        // await changeshift3StartH(await parseInt(shift / 60).toString().padStart(2, '0'));
        // shiftItems[2].start[0] = await parseInt(shift / 60).toString().padStart(2, '0');
        // await changeshift3StartM((await shift % 60));
        // shiftItems[2].start[1] = await (shift % 60).toString().padStart(2, '0');


        shifbytes2_local = await message.slice(45, 48);
        shift2_local = parseInt(shifbytes2_local, 16);



        // await changeshift3EndH(await parseInt(shift / 60).toString().padStart(2, '0'));
        // shiftItems[2].end[0] = await parseInt(shift / 60).toString().padStart(2, '0');
        // await changeshift3EndM((await shift % 60));
        // shiftItems[2].end[1] = await (shift % 60).toString().padStart(2, '0');

        await changeShift3({
            ...shift3,
            startH: await parseInt(shift / 60).toString().padStart(2, '0'),
            startM: await (shift % 60).toString().padStart(2, '0'),
            endH: await parseInt(shift2_local / 60).toString().padStart(2, '0'),
            endM: await shift2_local % 60
        })


        //------------------------------------------------set alarm duration
        let alarmD = await message.slice(48, 50);
        await changeAlarmDuration(await SettingItems[0].items.findIndex(item => item.id === alarmD));
        // settingItems[0].selectedIndex = await settingItems[0].optionId.findIndex(item => item === alarmD);

        //------------------------------------------------set horn delay
        let hornD = await message.slice(50, 52);
        await changeHornDelay(await SettingItems[1].items.findIndex(item => item.id === hornD));
        // settingItems[1].selectedIndex = await settingItems[1].optionId.findIndex(item => item === hornD);


        //------------------------------------------------set chirp mode
        let chirpM = await message.slice(52, 53);
        await changeChirpMode(await SettingItems[2].items.findIndex(item => item.id === chirpM));
        // settingItems[2].selectedIndex = await settingItems[2].optionId.findIndex(item => item === chirpM);


        //------------------------------------------------set relay timer 
        await changeReleTime({
            hour: await message.slice(53, 55),
            minute: await message.slice(55, 57),
            seccond: await message.slice(57, 59)
        });


        //-------------------------------------------------set relay pulse width
        let pulse = await message.slice(59, 61);
        await changeRelayPulseWidth(await SettingItems[5].items.findIndex(item => item.id === pulse));
        // settingItems[5].selectedIndex = await settingItems[5].optionId.findIndex(item => item === pulse);

        console.log('message', message)

        //------------------------------------------------set relay mode
        let relayM = await message.slice(61, 62);
        await changeRelayMode(await SettingItems[3].items.findIndex(item => item.id === relayM));
        // console.log('relayM', await settingItems[3].optionId.findIndex(item => item === relayM))
        // settingItems[3].selectedIndex = await settingItems[3].optionId.findIndex(item => item === relayM);

        //------------------------------------------------set relay mode
        let synceRelayD = await message.slice(62, 64);
        await changeSynchronRelayStartDelay(await SettingItems[6].items.findIndex(item => item.id === synceRelayD));
        // await changesynchronRelayStartDelay(synceRelayD);
        // settingItems[6].selectedIndex = await settingItems[6].optionId.findIndex(item => item === synceRelayD);

        //------------------------------------------------set roaming & remote D key & summer zone time
        let roamingDKeySummer = await (parseInt(message.slice(64, 66), 16).toString(2)).padStart(8, '0');

        let r = await roamingDKeySummer.slice(0, 2);
        await changeRoaming(await SettingItems[10].items.findIndex(item => item.id === r));
        // settingItems[10].selectedIndex = await settingItems[10].optionId.findIndex(item => item === r);

        let d = await roamingDKeySummer.slice(2, 5);
        await changeRemoteDKey(await SettingItems[7].items.findIndex(item => item.id === d));
        // settingItems[7].selectedIndex = await settingItems[7].optionId.findIndex(item => item === d);

        let s = await roamingDKeySummer.slice(5, 7);
        await changeSummerTimeZone(await SettingItems[11].items.findIndex(item => item.id === s));
        // settingItems[11].selectedIndex = await settingItems[11].optionId.findIndex(item => item === s);

        // if (roamingDKeySummer.slice(7, 8) === "1")
        //     await changeFourthKeyDelayFunction(true);
        // else
        //     await changeFourthKeyDelayFunction(false);

        //------------------------------------------------set entry time
        let entryT = await message.slice(66, 68);
        // await changeentryTime(entryT);
        await changeEntryTime(await SettingItems[8].items.findIndex(item => item.id === entryT));
        // settingItems[8].selectedIndex = await settingItems[8].optionId.findIndex(item => item === entryT);


        //------------------------------------------------set exit time
        let exitT = await message.slice(68, 70);
        // await changeexitTime(exitT);
        await changeExitTime(await SettingItems[9].items.findIndex(item => item.id === exitT));
        // settingItems[9].selectedIndex = await settingItems[9].optionId.findIndex(item => item === exitT);


        // const device = JSON.parse(await AsyncStorage.getItem('device'));
        // device[selectedDevice.id].lastMessage = message;
        // await AsyncStorage.setItem('device', JSON.stringify(device));
        // await dispath(changeSelectedDevice(device[selectedDevice.id]));
    }






    return (
        <View style={styles.container}>
            <EditHeader
                syncFunc={HamgamSazi}
                title='تنظیمات دستگاه' />

            <ScrollView style={styles.content}>

                <Text>{shift2.startH}</Text>
                {SettingItems.map((item, index) =>
                    !item.clock ?
                        <SettingRow
                            key={String('setting' + index)}
                            {...{ item }}
                            changeModalData={changeModalData}
                            value={(item.value || item.value === 0) ? item.items[item.value].label : ''}
                            {...{ modalVisible }}
                            {...{ changeModalVisibility }}
                            selected_item={item.value}
                            changeSelected_item={item.changeFunction}
                        />
                        : <SettingRow
                            key={String('setting' + index)}
                            {...{ item }}
                            changeModalData={changeModalData}
                            value={''}
                            modalVisible={modalTimeVisible}
                            changeModalVisibility={changeModalTimeVisibility}
                            selected_item={item.value}
                            changeSelected_item={item.changeFunction}
                        />
                )}

                {SettingItemShifts.map((item, index) =>
                    <SettingShiftRow
                        key={String('settingShift' + index)}
                        {...{ item }}
                        modalVisible={modalTimeShiftVisible}
                        changeModalVisibility={changeModalTimeShiftVisible}
                    />
                )}
                <View style={{ height: 100 }}></View>
                {/* <FlatList
                    showsVerticalScrollIndicator={false}
                    data={SettingItems}
                    ListHeaderComponent={() => <View style={{ height: 10 }}></View>}
                    // ListFooterComponent={() => <View style={{ height: 100 }}></View>}
                    keyExtractor={(item, index) => String('setting' + index)}
                    renderItem={({ item, index }) =>
                        !item.clock ?
                            <SettingRow
                                {...{ item }}
                                changeModalData={changeModalData}
                                value={item.value}
                                {...{ modalVisible }}
                                {...{ changeModalVisibility }}
                                selected_item={item.value}
                                changeSelected_item={item.changeFunction}
                            />
                            : <SettingRow
                                {...{ item }}
                                changeModalData={changeModalData}
                                value={''}
                                modalVisible={modalTimeVisible}
                                changeModalVisibility={changeModalTimeVisibility}
                                selected_item={item.value}
                                changeSelected_item={item.changeFunction}
                            />
                    }
                />


                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={SettingItemShifts}
                    // ListHeaderComponent={() => <View style={{ height: 10 }}></View>}
                    ListFooterComponent={() => <View style={{ height: 100 }}></View>}
                    keyExtractor={(item, index) => String('settingShift' + index)}
                    renderItem={({ item, index }) =>
                        <SettingShiftRow
                            {...{ item }}
                            modalVisible={modalTimeShiftVisible}
                            changeModalVisibility={changeModalTimeShiftVisible}
                        />
                    }
                /> */}



            </ScrollView>



            <BottomBtn
                onPress={SendMessage}
            >
                ارسال تنظیمات
            </BottomBtn>


            <Modal
                // send title and show state to modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                data={modalData}
            />

            <TimePicker
                // send title and show state to modal
                modalVisible={modalTimeVisible}
                setModalVisible={changeModalTimeVisibility}
                data={modalData}
            />

            <ShiftPicker
                modalVisible={modalTimeShiftVisible}
                setModalVisible={changeModalTimeShiftVisible}
            />

            <SelectSimModal
                SelectedSimModal={SelectedSimModal}
                changeModalShow={changeSelectedSimModal}
                return_func={SelectedSimModal.return_func}
            />



        </View>
    )
}

export default SettingPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        flex: 1,
        paddingHorizontal: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6,
        minHeight: 55,
        marginBottom: 5
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});



//  --------- row for setting
const SettingRow = ({ item, changeModalVisibility, modalVisible,
    changeModalData, selected_item, changeSelected_item, value }) => {


    const RowClick = async () => {

        if (!item.input && !item.clock)
            await changeModalData(item.items);
        else
            await changeModalData([]);

        await changeModalVisibility({
            ...modalVisible
            ,
            title: item.title,
            selected_item: selected_item,
            changeSelected_item: changeSelected_item,
            show: true,
            coverScreen: false,
            seccond: item.shift ? true : false
        })

        // await changeModalVisibility({
        //     ...modalVisible,
        //     show: true,
        //     title: item.title
        // });


    }

    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={{
                ...styles.row,
                borderBottomColor: '#313131',
                borderBottomWidth: item.border ? 1 : 0
            }}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            {/* for some modal values that has name we just want to show answer in row */}
            {item.input &&
                <Text>{item.value}</Text>
            }

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{item.title}</Text>

                {/* for some modal values that has name we just want to show answer in row */}
                {(!item.input && !item.clock) &&
                    <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{value}</Text>
                }

            </View>

        </TouchableOpacity>
    )
}


//  --------- row for setting
const SettingShiftRow = ({ item, changeModalVisibility, modalVisible }) => {


    const RowClick = async () => {
        await changeModalVisibility({
            ...modalVisible
            ,
            show: true,
            title: item.title,
            selected_first_item: { hour: item.selected_first_item.hour, minute: item.selected_first_item.minute },
            selected_end_item: { hour: item.selected_end_item.hour, minute: item.selected_end_item.minute },
            changeSelected_item: item.changeSelected_item
        })
    }

    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={{ ...styles.row }}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{item.title}</Text>

                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}></Text>

            </View>

        </TouchableOpacity>
    )
}
