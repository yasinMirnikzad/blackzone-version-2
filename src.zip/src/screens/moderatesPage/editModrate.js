import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import * as Yup from 'yup';
import { useSelector } from 'react-redux';

import {
    EditHeader, Text, Modal,
    MultiSelectModalComponent,
    BottomBtn, SelectSimModal,
    TypeOfReportModalComponent
} from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';

// ------- utilities
import { timestamp } from '../../utilities';


// const ZonTypes
const zonesTypes = [
    { id: '0010', label: 'زون آلارم' },
    { id: '0003', label: 'نیمه‌فعال' },
    { id: '0004', label: 'تاخیر در ورود' },
    { id: '0008', label: 'تاخیر در خروج' },
    { id: '000C', label: 'تاخیر در ورود و خروج' },
    { id: '0020', label: '24 ساعته' },
    { id: '0040', label: 'تشخیص دستکاری' },
    { id: '0080', label: 'آتش سوزی' },
    { id: '0100', label: 'پدال-وضعیت اضطراری' },
    { id: '0200', label: 'پدال-وضعیت تهاجم' }
    // { id: '&&&&', label: '' },
]


const ModeratesAccess = [
    { id: '0X8000', label: 'فعال‌سازی دستگاه' },
    { id: '0X4000', label: 'خروج دستگاه از حالت فعال' },
    { id: '0X3000', label: 'نیمه‌فعال‌سازی دزگیر' },
    { id: '0X0800', label: 'خروج از حالت نیمه‌‌فعال' },
    { id: '0X0400', label: 'قطع آژیر' },
    { id: '0X0200', label: 'کنترل رله' },
    { id: '0X0100', label: 'کنترل دینگ‌دانگ' },
    { id: '0X0040', label: 'ویرایش تنظیمات دستگاه' },
    { id: '0X0020', label: 'ویرایش مخاطبین' },
    { id: '0X0010', label: 'ویرایش ریموت‌ها' },
    { id: '0X0008', label: 'ویرایش‌ زون‌ها' },
    { id: '0X0004', label: 'کنترل از طریق تماس', },
    { id: '0X0002', label: 'تنظیمات سریع' },
    { id: '0X0001', label: 'تغییر کد امنیتی' }
]

const ModeratesReportsItems = [
    { id: '0X0001', label: 'سرقت' },
    { id: '0X0002', label: 'دستکاری' },
    { id: '0X0004', label: 'آتش سوزی' },
    { id: '0X0008', label: 'رصد ۲۴ ساعته' },
    { id: '0X0010', label: 'وضعیت اضطراری' },
    { id: '0X0040', label: 'قطع آژیر' },
    { id: '0X0080', label: 'تغییرات تغذیه دستگاه' },
    { id: '0X0100', label: 'شارژ سیم کارت' },
    { id: '0X0200', label: 'مشکل فیوز سنسورها' },
    { id: '0X0400', label: 'قطع سیم بلندگوی خارجی' },
    { id: '0X1000', label: 'تغییر وضعیت دستگاه' },
    { id: '0X2000', label: 'درخواست کمک' },
    { id: '0X4000', label: 'زون هوشمند' },
    { id: '0X8000', label: 'اضافه شدن ریموت' },
]







const ZonesPage = (props) => {
    const { id } = props.route.params;
    const select_device = useSelector((store) => store.selected_device.device);

    const [modalReportVisible, changeModalReportVisible] = useState(false);
    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [modalMultiVisible, changeModalMultiVisible] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [SelectedSimModal, changeSelectedSimModal] = useState({
        show: false,
        message: '',
        return_func: null
    })
    const [modalData, changeModalData] = useState([]);
    const [name, changename] = useState('');
    const [phonenumber, changePhonenumber] = useState('');
    const [usersPermissions, changeUserPermissions] = useState([]);
    const [usersReports, changeUsersReports] = useState([]);

    // type of user report
    const [receiveReportbyCall, changeReceiveReportbyCall] = useState(false);
    const [receiveReportbySms, changeReceiveReportbySms] = useState(false);
    const [receiveSathiSms, changeReceiveSathiSms] = useState(0);
    const [receiveReportDetail, changeReceiveReportDetail] = useState(false);



    const DoneUpdateUser = (message) => {
        console.log('done', message)
    }


    const SendMessage = async () => {
        // await requestSmsPermission();
        let time2 = timestamp();
        // await SetLoadingVisible(true);
        let theName = name;
        //--------------------------------------------------------------check kardan tedad char name
        if (name.length < 14)
            theName += ';';

        let permissions = await SaveSelectedItems(usersPermissions, ModeratesAccess)
        let moderateType = await SaveSelectedItems(usersReports, ModeratesReportsItems)

        let message = 'P' + 'C' + select_device.device_securitycode + time2 + theName.padEnd(14, '0') +
            'M' + id.toString(16) + '&' + phonenumber + permissions + Reports() + moderateType;



        console.log('message', message)
        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message,
            return_func: DoneUpdateUser
        })

        // changeExitModal(false);
        // changeChangeData(false);
        // await SendSms(message.toUpperCase(), await checkPhoneNum(selectedDevice.phonenumber));
        // await GetSms(time, time2.toUpperCase());
    };


   
    


    // ---------------------- reports type
    const SaveSelectedItems = async (items, array) => {
        let msg = 0;
        for (let i = 0; i < items.length; i++) {
            msg += parseInt(array[items[i]].id, 16);
        }

        return await msg.toString(16).padStart(4, '0');
    }

    // ---------------------- to analyse the response and set values
    const GetUserInfo = async (message) => {
        // PC00000063FB57E8مدیر شماره ۳;0M2D9333974911F800B50019
        console.log('message', message);

        //----------------------------------------------set contact name
        let name = message.slice(16, 30);
        let Moderatename = name.substring(0, name.indexOf(";"));
        //----------------------------------------------set contact phonenumber
        let phonenumber = message.slice(33, 43);

        //-----------------------------------------------set contact permitions
        let permitions = await parseInt(message.slice(43, 47), 16);
        let newPermitionsCheckList = [];
        let permition;
        
        
        for (let i = 0; i < ModeratesAccess.length; i++) {
            permition = await parseInt(ModeratesAccess[i].id, 16);
            if ((permitions & permition) == permition) {
                newPermitionsCheckList.push(i);
            }
        }
        //-----------------------------------------------set contact submit report
        const report = await parseInt(message.slice(47, 49), 16);
        console.log('report', report)
        let item = await parseInt('0X11', 16);
        if ((report & item) == item)
            await changeReceiveReportbyCall(true);


        item = await parseInt('0X24', 16);

        if ((report & item) == item) {
            await changeReceiveReportbySms(true);
            await changeReceiveSathiSms(0);
        } else {
            item = await parseInt('0X28', 16);

            if ((report & item) == item) {
                await changeReceiveReportbySms(true);
                await changeReceiveSathiSms(1);
            } else {
                await changeReceiveReportbySms(false);
                await changeReceiveSathiSms();
            };
        }

        item = await parseInt('0X80', 16);
        if ((report & item) == item)
            await changeReceiveReportDetail(true);


        //-----------------------------------------------set contact type of reports
        let typeOfReports = await parseInt(message.slice(49, 53), 16);
        let newTypeOfReportsCheckList = [];
        let typeOfReport;
        for (let i = 0; i < ModeratesReportsItems.length; i++) {
            typeOfReport = await parseInt(ModeratesReportsItems[i].id, 16);
            if ((typeOfReports & typeOfReport) == typeOfReport) {
                newTypeOfReportsCheckList.push(i);
            }
        }


        await changename(Moderatename);
        await changePhonenumber(phonenumber);
        await changeUserPermissions(newPermitionsCheckList);
        await changeUsersReports(newTypeOfReportsCheckList);


    }


    // ---------------------- to sync the values
    const HamgamSazi = async () => {
        let time2 = timestamp();

        const message = 'MST' + parseInt(id) + ';' + select_device.device_securitycode + ';' +
            time2 + ';' + select_device.device_phonenumber.split('').reverse().join('') + ';';

        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message,
            return_func: GetUserInfo
        })
    }


    //-------------------------------------------mohasebe adad marboot be nahve ersal gozaresh
    function Reports() {
        let res = 0;
        if (receiveReportbyCall)
            res += parseInt('0X11', 16);

        if (receiveReportbySms) {
            res += parseInt('0X20', 16);
            if (receiveSathiSms)
                res += parseInt('0X04', 16);
            else
                res += parseInt('0X08', 16);
        }

        if (receiveReportDetail)
            res += parseInt('0X80', 16);

        if (res === 0)
            return '00';
        else
            return res.toString(16).padStart(2, '0')
    }






    return (
        <View style={styles.container}>
            <EditHeader
                title='ویرایش مدیر'
                syncFunc={HamgamSazi}
            />

            <View style={styles.content}>

                <TouchableOpacity
                    activeOpacity={.5}

                    onPress={() => {
                        changeModalData([]);
                        changeModalVisibility({
                            ...modalVisible
                            ,
                            title: 'نام مدیر',
                            selected_item: name,
                            changeSelected_item: changename,
                            show: true,
                            coverScreen: false
                        })
                    }}
                    style={styles.row}
                >
                    <Icon style={{
                        fontSize: 18, color: 'white',
                        marginRight: 10
                    }} name='chevron-left' />

                    <Text>{name}</Text>

                    <View style={{
                        flexDirection: 'column',
                        flex: 1
                    }}>
                        <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{'نام مدیر'}</Text>

                    </View>

                </TouchableOpacity>



                <TouchableOpacity
                    activeOpacity={.5}
                    onPress={() => {
                        changeModalData([]);
                        changeModalVisibility({
                            ...modalVisible
                            ,
                            title: 'شماره تلفن',
                            selected_item: phonenumber,
                            changeSelected_item: changePhonenumber,
                            show: true,
                            coverScreen: false
                        })
                    }}
                    style={{ ...styles.row, marginTop: 10 }}
                >
                    <Icon style={{
                        fontSize: 18, color: 'white',
                        marginRight: 10
                    }} name='chevron-left' />

                    <Text>{phonenumber}</Text>

                    <View style={{
                        flexDirection: 'column',
                        flex: 1
                    }}>
                        <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{'شماره تلفن'}</Text>

                    </View>

                </TouchableOpacity>


                <SettingRow
                    title='نحوه ارسال گزارش'
                    value={''}
                    modalVisible={modalReportVisible}
                    changeModalVisibility={changeModalReportVisible}
                    reporttype={true}
                />

                <SettingRow
                    title='دسترسی‌ها'
                    value={''}
                    modalVisible={modalMultiVisible}
                    changeModalVisibility={changeModalMultiVisible}
                    items={ModeratesAccess}
                    selected_item={usersPermissions}
                    changeSelected_item={changeUserPermissions}
                    changeModalData={changeModalData}
                />

                <SettingRow
                    title='نوع گزارش ارسالی'
                    value={''}
                    modalVisible={modalMultiVisible}
                    changeModalVisibility={changeModalMultiVisible}
                    items={ModeratesReportsItems}
                    selected_item={usersReports}
                    changeSelected_item={changeUsersReports}
                    changeModalData={changeModalData}
                />




            </View>



            <BottomBtn onPress={SendMessage}>
                ارسال تنظیمات
            </BottomBtn>


            <Modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                coverScreen={modalVisible.coverScreen}
                data={modalData}
                validator={zoneNameValidationSchema}
            />

            <MultiSelectModalComponent
                modalVisible={modalMultiVisible}
                setModalVisible={changeModalMultiVisible}
                coverScreen={modalVisible.coverScreen}
                data={modalData}
                validator={zoneNameValidationSchema}
            />

            <SelectSimModal
                SelectedSimModal={SelectedSimModal}
                changeModalShow={changeSelectedSimModal}
                return_func={SelectedSimModal.return_func}
            />

            <TypeOfReportModalComponent
                modalVisible={modalReportVisible}
                setModalVisible={changeModalReportVisible}
                coverScreen={false}
                // states
                {...{ receiveReportbyCall }}
                {...{ receiveReportbySms }}
                {...{ receiveSathiSms }}
                {...{ receiveReportDetail }}
                // funcs
                {...{ changeReceiveReportbyCall }}
                {...{ changeReceiveReportbySms }}
                {...{ changeReceiveSathiSms }}
                {...{ changeReceiveReportDetail }}


            />



        </View>
    )
}

export default ZonesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});



//  --------- row for setting
const SettingRow = (props) => {

    const RowClick = async () => {
        if (props.reporttype) {
            await props.changeModalVisibility(true);
        }
        else {
            await props.changeModalData(props.items)
            await props.changeModalVisibility({
                ...props.modalVisible
                ,
                title: props.title,
                selected_item: props.selected_item,
                changeSelected_item: props.changeSelected_item,
                show: true,
                coverScreen: props.coverScreen
            })
        }
    }
    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={styles.row}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{props.title}</Text>
                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{props.value}</Text>
            </View>

        </TouchableOpacity>
    )
}



const zoneNameValidationSchema = Yup.object().shape({
    name: Yup
        .string()
        .max(14, ({ max }) => `نام زون باید حداکثر ${max} کاراکتر باشد`)
        .required('فیلد نام دستگاه الزامی است'),
})



