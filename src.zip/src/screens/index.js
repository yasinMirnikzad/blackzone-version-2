

import DeviceInfoPage from './registerDevicePages/deviceInfo';
import DeviceNumberPage from './registerDevicePages/deviceNumber';
import SubmitDevicePage from './registerDevicePages/submitDevice';


import Home from './homePage/homePage';
import SplashPage from './splashPage/splashPage';
import FirstPage from './firstPage/firstPage';

import ModeratesPage from './moderatesPage/moderatesPage';
import EditModratePage from './moderatesPage/editModrate';


import ContactsPage from './contactsPage/contactsPage';
import EditContactPage from './contactsPage/editContact';


import AddUserPage from './addUserPage/addUser';


import ZonesPage from './zonesPage/zonesPage';
import EditZonePage from './zonesPage/editZone';

import RemotesPage from './remotesPage/remotesPage';
import EditRemotePage from './remotesPage/editRemote';

import SettingPage from './settingPage/settingPage';

import DevicesPage from './devicesPage/devicesPage';
import EditDevicePage from './devicesPage/editDevice';


// fast setup
import FastSetupPageOne from './fastSetupPage/fastSetupPageOne';
import FastSetupPageTwo from './fastSetupPage/fastSetupPageTwo';
import FastSetupPageThree from './fastSetupPage/fastSetupPageThree';





export {
    SplashPage,
    DeviceInfoPage,
    DeviceNumberPage,
    SubmitDevicePage,

    Home,
    FirstPage,

    ModeratesPage,
    EditModratePage,

    ContactsPage,
    EditContactPage,

    RemotesPage,
    EditRemotePage,

    ZonesPage,
    EditZonePage,

    SettingPage,

    DevicesPage,
    EditDevicePage,

    FastSetupPageOne,
    FastSetupPageTwo,
    FastSetupPageThree,
    // inja bayd add user etefq biofte
    // check koni ke id ro chetory mifreste va uniqe ya na
    AddUserPage
}