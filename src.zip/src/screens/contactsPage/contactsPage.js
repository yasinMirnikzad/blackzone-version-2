import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { useSelector, useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';

import { Header, Text, FunctionalModal, SelectSimModal } from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';

// ------- utilities
import { timestamp } from '../../utilities';








const Contacts = (props) => {
    const navigation = useNavigation();
    const dispatch = useDispatch();

    const select_device = useSelector((store) => store.selected_device.device);

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        item: {},
        selected_index: -1
    });
    const [SelectedSimModal, changeSelectedSimModal] = useState({
        show: false,
        message: ''
    })
    // ------ state for datas
    const [users, changeUsers] = useState();

    // ------ functions for items
    const ChangeActivity = async (value) => {
        // -------------------------------------------
        let time = timestamp();

        const message = 'P' + 'C' + select_device.device_securitycode + time + '&&&&&&&&&&&&&&' +
            'C' + modalVisible.selected_index.toString(16) + value + '&&&&&&&&&&&&&&&&&&&&';

        // -------------------------------------------
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })

        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message: message.toUpperCase()
        })


    }


    const GoToEdit = (index) => {
        // ------ go to edit moderate page
        // navigation.navigate('')
        changeModalVisibility({
            ...modalVisible,
            show: false,
            item: {},
            selected_index: -1
        })
        navigation.navigate('EditContactPage', { id: index })
    }

    // ------ data for modal
    const modalItems = [
        { label: 'فعال', value: 'A', function: ChangeActivity },
        { label: 'غیرفعال', value: 'D', function: ChangeActivity },
        { label: 'ویرایش', function: GoToEdit, func: true },
        { label: 'حذف', value: 'U', function: ChangeActivity, func: true }
    ]


    // -------------- useEffect
    useEffect(() => {
        GetData(select_device.lastMessage)
    }, [])

    const GetData = async (message) => {
        let contactsstatus = message.slice(30, 46);
       
        let Users = [];
        for (let i = 0; i < 15; i++) {
            if (contactsstatus[i] !== 'U') {
                let user = {
                    id: i, title: `مخاطب شماره${i + 1}`, status: contactsstatus[i]
                }
                Users.push(user);
            }
        }
        await changeUsers(Users);

        const device = JSON.parse(await AsyncStorage.getItem('devices'));
        device[select_device.id].lastMessage = message;
        await AsyncStorage.setItem('devices', JSON.stringify(device));
        await dispatch(setDevice(device[select_device.id]));

        // SetLoadingVisible(false);
    }









    return (
        <View style={styles.container}>
            <Header title='مخاطبین' />

            <View style={styles.content}>


                <FlatList
                    data={users}
                    key={(item, index) => String('row' + index)}
                    renderItem={({ item, index }) =>
                        <TouchableOpacity
                            style={styles.row}
                            onPress={() => changeModalVisibility({
                                ...modalVisible,
                                show: true,
                                item: item,
                                selected_index: index
                            })}
                        >
                            <Icon style={{ fontSize: 18, color: 'white', marginRight: 10 }} name='chevron-left' />

                            <Text>{item.status === 'A' ?
                                'فعال' :
                                'غیرفعال'
                            }</Text>

                            <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17, flex: 1 }}>{item.title}</Text>
                            <Text fontWeight='Medium' style={{ fontSize: 17 }}>{'.' + (index + 1)} </Text>
                        </TouchableOpacity>
                    }
                />
                <TouchableOpacity style={styles.addModrate}>
                    <Text style={styles.addModrateBtn}>اضافه کردن شماره جدید</Text>
                    <Icon style={styles.addModrateBtn} name='plus' />
                </TouchableOpacity>
            </View>



            <FunctionalModal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                data={modalItems}
            />



            <SelectSimModal
                SelectedSimModal={SelectedSimModal}
                changeModalShow={changeSelectedSimModal}
                return_func={GetData}
            />


        </View>
    )
}

export default Contacts;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        height: 50,
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 8
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-end'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});








