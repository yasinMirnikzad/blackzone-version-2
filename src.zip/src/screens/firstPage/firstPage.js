import React from 'react';

import { useNavigation } from '@react-navigation/native';
import {
    StatusBar,
    StyleSheet,
    View,
    TouchableOpacity,
    Image
} from 'react-native';

// ----------- component
import { Text } from '../../components';

// ----------- color
import { Background, Primary } from '../../config/colors.json';







const App = () => {
    const navigation = useNavigation();


    return (
        <View style={styles.container}>
            <StatusBar
                backgroundColor={'#3D3D3D'}
            />

            <View style={styles.formContainer}>

                {/* <Text fontWeight='Bold' style={styles.title}>دستگاه با موفقیت ثبت شد</Text> */}
{/* 
                <Image
                    style={{
                        height: 200,
                        width: '100%',
                        resizeMode: 'center',
                    }}
                    source={require('../../images/splash/logo.png')}
                /> */}

                <View style={styles.formBtnContainer}>

                    <TouchableOpacity
                        onPress={() => navigation.navigate('HomeDrawer')}
                        activeOpacity={.4}
                        style={{ ...styles.formBtn, ...styles.formGoToApp }}>
                        <Text fontWeight='Bold'
                            style={{ color: Primary, fontSize: 16 }}>نسخه نمایشی</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => navigation.navigate('DeviceInfoPage')}
                        activeOpacity={.4}
                        style={{ ...styles.formBtn, ...styles.formGoToSetting }}>
                        <Text fontWeight='Bold'
                            style={{ color: Background, fontSize: 16 }}>+ اضافه کردن دستگاه</Text>
                    </TouchableOpacity>

                </View>
            </View>


        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    formContainer: {
        marginTop: '30%',
        marginHorizontal: 24,
        flex: 2
    },
    title: {
        fontSize: 16,
        textAlign: 'center'
    },
    input: {
        marginTop: 6
    },
    formBtnContainer: {
        flex: 1,
        flexDirection: 'column',
        width: '100%',
        position: 'absolute',
        bottom: 20
    },
    formBtn: {
        height: 58,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center'
    },
    formGoToApp: {
        flex: 1,
        borderColor: Primary,
        borderWidth: 2
    },
    formGoToSetting: {
        backgroundColor: Primary,
        color: Primary,
        flex: 1,
        borderColor: Primary,
        borderWidth: 2,
        marginTop: 14
    }
});

export default App;




