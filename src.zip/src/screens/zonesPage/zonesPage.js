import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

import { useSelector, useDispatch } from 'react-redux';
import { timestamp } from '../../utilities';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';

import { Header, Text, FunctionalModal, SelectSimModal } from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';



const ZoneTypeOptionsTitle = [
    "زون آلارم",
    "نیمه‌فعال",
    "تاخیر در ورود",
    "تاخیر در خروج",
    "تاخیر در ورود و خروج",
    "24 ساعته",
    "تشخیص دستکاری",
    "آتش سوزی",
    "پدال-وضعیت اضطراری",
    "پدال-وضعیت تهاجم",
    "غیرفعال",
]


const ZonesPage = (props) => {
    const navigation = useNavigation();
    const dispatch = useDispatch();

    const select_device = useSelector((store) => store.selected_device.device);

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        item: {},
        selected_index: -1
    });
    const [SelectedSimModal, changeSelectedSimModal] = useState({
        show: false,
        message: ''
    })
    // ------ state for datas -> onayi k DDDD hastano 0 bzar baiqe 1
    const [zones, changeZones] = useState([]);


    // ------ functions for items
    // const ChangeActivity = async (value) => {

    //     //    inja bayad status_type ham taqir kone ba tavajoh b responi k miad
    //     // havaset bashe :D
    //     console.log('value', value)
    //     let Zones = zones;
    //     Zones[modalVisible.selected_index].status = value;

    //     // await requestSmsPermission();
    //     // let time2 = timestamp();


    //     // const message = 'P' + 'Z' + selectedDevice.securitycode + time2 + '&&&&&&&&&&&&&&' + props.id.toString(16) +
    //     //     status + '&&&&&&';

    //     // await SendSms(message.toUpperCase(), await checkPhoneNum(selectedDevice.phonenumber));
    //     // await GetSms(time, status, time2.toUpperCase());




    //     Zones[modalVisible.selected_index].status_type = 'SomeThing';
    //     await changeZones(Zones)
    //     await changeModalVisibility({
    //         show: false,
    //         item: {},
    //         selected_index: -1
    //     })
    // }

    const GoToEdit = async (index) => {
        // ------ go to edit moderate page
        navigation.navigate('EditZonesPage', { id: index })
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })
    }

    // -------------- sendMessage
    const ChangeActivity = async (value) => {
        // await requestSmsPermission();
        let time2 = timestamp();


        const message = 'P' + 'Z' + select_device.device_securitycode + time2 + '&&&&&&&&&&&&&&' +
            modalVisible.selected_index.toString(16) +
            value + '&&&&&&';

        // inja ykm kond mishe chon dota set state dare :)
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })

        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message: message.toUpperCase()
        })


    }


    // ------ data for modal
    const modalItems = [
        { label: 'فعال', value: 'A', function: ChangeActivity },
        { label: 'غیرفعال', value: 'D', function: ChangeActivity },
        { label: 'ویرایش', function: GoToEdit, func: true }
    ]

    // -------------- useEffect
    useEffect(() => {
        GetData(select_device.lastMessage)
    }, [])

    const GetData = async (message) => {

        let zonesType = message.slice(46, 78);
        let firstChar = 0;

        const zones = [
            { title: 'زون شماره 1', status: 0, status_type: 'DDDD' },
            { title: 'زون شماره 2', status: 0, status_type: 'DDDD' },
            { title: 'زون شماره 3', status: 0, status_type: 'DDDD' },
            { title: 'زون شماره 4', status: 0, status_type: 'DDDD' },
            { title: 'زون بی سیم 1', status: 0, status_type: 'DDDD' },
            { title: 'زون بی سیم 2', status: 0, status_type: 'DDDD' },
            { title: 'زون بی سیم 3', status: 0, status_type: 'DDDD' },
            { title: 'زون بی سیم 4', status: 0, status_type: 'DDDD' }
        ]

        for (let i = 0; i < 8; i++) {
            let zone = zonesType.slice(firstChar, firstChar + 4);
            //-----------------------------------------------------zone type ba format hegza E :(
            // let zoneType = zone.slice(0, 4);

            switch (zone) {
                case '0010':
                    zones[i].status = 'A';
                    zones[i].status_type = 0;
                    break;
                case '0003':
                    zones[i].status = 'A';
                    zones[i].status_type = 1;
                    break;
                case '0004':
                    zones[i].status = 'A';
                    zones[i].status_type = 2;
                    break;
                case '0008':
                    zones[i].status = 'A';
                    zones[i].status_type = 3;
                    break;
                case '000C':
                    zones[i].status = 'A';
                    zones[i].status_type = 4;
                    break;
                case '0020':
                    zones[i].status = 'A';
                    zones[i].status_type = 5;
                    break;
                case '0040':
                    zones[i].status = 'A';
                    zones[i].status_type = 6;
                    break;
                case '0080':
                    zones[i].status = 'A';
                    zones[i].status_type = 7;
                    break;
                case '0100':
                    zones[i].status = 'A';
                    zones[i].status_type = 8;
                    break;
                case '0200':
                    zones[i].status = 'A';
                    zones[i].status_type = 9;
                    break;
                default:
                    zones[i].status = 'D';
                    zones[i].status_type = 10;
                    break;
            }
            firstChar += 4;
        }

        await changeZones(zones);
        const device = JSON.parse(await AsyncStorage.getItem('devices'));
        device[select_device.id].lastMessage = message;
        await AsyncStorage.setItem('devices', JSON.stringify(device));
        await dispatch(setDevice(device[select_device.id]));

        // SetLoadingVisible(false);
    }






    return (
        <View style={styles.container}>
            <Header title={'زون‌ها'} />

            <View style={styles.content}>

                <FlatList

                    showsVerticalScrollIndicator={false}
                    // style={{ flex: 1 }}
                    data={zones}
                    keyExtractor={(item, index) => String('row' + index)}
                    renderItem={({ item, index }) =>
                        <TouchableOpacity
                            onPress={() => changeModalVisibility({
                                ...modalVisible,
                                show: true,
                                item: item,
                                selected_index: index
                            })}
                            style={styles.row}
                        >
                            <Icon style={{
                                fontSize: 18, color: 'white',
                                marginRight: 10
                            }} name='chevron-left' />

                            <Text>{item.status === 'A' ?
                                'فعال' :
                                'غیرفعال'
                            }</Text>

                            <View style={{
                                flexDirection: 'column',
                                flex: 1
                            }}>
                                <Text fontWeight='Medium'
                                    style={{ marginRight: 4, fontSize: 17 }}>{item.title}</Text>
                                <Text fontWeight='Light'
                                    style={{ marginRight: 4, fontSize: 14, color: '#797979' }}
                                >{ZoneTypeOptionsTitle[item.status_type]}</Text>
                            </View>

                        </TouchableOpacity>
                    }
                />


            </View>


            <FunctionalModal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                data={modalItems}
            />


            <SelectSimModal
                SelectedSimModal={SelectedSimModal}
                changeModalShow={changeSelectedSimModal}
                return_func={GetData}
            />

        </View>
    )
}

export default ZonesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});

