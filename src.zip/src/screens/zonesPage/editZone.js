import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { Formik } from 'formik';
import * as Yup from 'yup';

import { useSelector, useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';

import {
    EditHeader, Text, Modal, BottomBtn,
    Input, SelectSimModal
} from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';


// ------- utilities
import { timestamp } from '../../utilities';

// const ZonTypes
const zonesTypes = [
    { id: '0010', label: 'زون آلارم' },
    { id: '0003', label: 'نیمه‌فعال' },
    { id: '0004', label: 'تاخیر در ورود' },
    { id: '0008', label: 'تاخیر در خروج' },
    { id: '000C', label: 'تاخیر در ورود و خروج' },
    { id: '0020', label: '24 ساعته' },
    { id: '0040', label: 'تشخیص دستکاری' },
    { id: '0080', label: 'آتش سوزی' },
    { id: '0100', label: 'پدال-وضعیت اضطراری' },
    { id: '0200', label: 'پدال-وضعیت تهاجم' }
    // { id: '&&&&', label: '' },
]

const zonesPrefrences = [
    { id: 'C', label: 'در حالت عادی بسته NC' },
    { id: 'O', label: 'در حالت عادی باز NO' }
]

const zonesDingDong = [
    { id: 'D', label: 'فعال' },
    { id: '0', label: 'غیرفعال' }
]


const ZonesPage = (props) => {
    const { id } = props.route.params;
    const select_device = useSelector((store) => store.selected_device.device);

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [SelectedSimModal, changeSelectedSimModal] = useState({
        show: false,
        message: '',
        return_func: null
    })
    const [modalData, changeModalData] = useState([]);
    const [name, changename] = useState('');
    const [zoneType, changeZoneType] = useState(null);
    const [zoneMode, changeZoneMode] = useState(null);
    const [zoneDingdong, changeZoneDingdong] = useState(null);

    // -------------------- start redux dispatch
    const dispatch = useDispatch();


    // -------------------- end redux dispatch


    const DoneUpdateUserZone = async (message) => {
        // inja bayd ye chizi bzaram vase update esmeshonam :D

        const device = JSON.parse(await AsyncStorage.getItem('devices'));
        device[select_device.id].lastMessage = message;
        await AsyncStorage.setItem('devices', JSON.stringify(device));
        await dispatch(setDevice(device[select_device.id]));
    }


    const SendMessage = async () => {
        // await requestSmsPermission();
        let time2 = timestamp();
        // await SetLoadingVisible(true);
        let theName = name;
        //--------------------------------------------------------------check kardan tedad char name
        if (name.length < 14)
            theName += ';';


        let message = 'P' + 'Z' + select_device.device_securitycode + time2 + theName.padEnd(14, '0') +
            id.toString(16) +
            '&';

        // if (zoneType === '&&&&')
        // message += '&&&&' + zonesPrefrences[zoneMode].id + zonesDingDong[zoneDingdong].id;
        // else
        console.log('zoneMode', zoneMode)
        console.log('zoneDingdong', zoneDingdong)
        message += zonesTypes[zoneType].id + zonesPrefrences[zoneMode].id + zonesDingDong[zoneDingdong].id;




        console.log('message', message)
        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message,
            return_func: DoneUpdateUserZone
        })

        // changeExitModal(false);
        // changeChangeData(false);
        // await SendSms(message.toUpperCase(), await checkPhoneNum(selectedDevice.phonenumber));
        // await GetSms(time, time2.toUpperCase());
    };
   
    const GetZoneInfo = async (message) => {
        console.log('message', message);

        //----------------------------------------------set contact name
        let name = message.slice(16, 30);
        let ZoneName = name.substring(0, name.indexOf(";"));
        changename(ZoneName);

        //-----------------------------------------------set zone type
        let type = message.slice(32, 36);
        console.log('type', type)
        let index = await zonesTypes.findIndex(item => item.id === type);
        console.log('index', index)

        if (index !== -1) {
            await changeZoneType(index);
        }

        //------------------------------------------------set zone mode
        let mode = message.slice(36, 37);
        if (mode === 'C')
            await changeZoneMode(0);
        else if (mode === 'O')
            await changeZoneMode(1);


        //------------------------------------------------set zone ding dang
        let dingdang = message.slice(37, 38);
        if (dingdang === 'D')
            await changeZoneDingdong(0);
        else if (dingdang === '0')
            await changeZoneDingdong(1);



    }

    // ---------------------- to sync the values
    const HamgamSazi = async () => {
        let time2 = timestamp();

        const message = 'ZST' + parseInt(id) + ';' + select_device.device_securitycode + ';' +
            time2 + ';' + select_device.device_phonenumber.split('').reverse().join('') + ';';


        console.log('message', message)
        await changeSelectedSimModal({
            ...SelectedSimModal,
            show: true,
            message,
            return_func: GetZoneInfo
        })
    }





    return (
        <View style={styles.container}>
            <EditHeader
                syncFunc={HamgamSazi}
                title='ویرایش زون'
            />

            <View style={styles.content}>

                <TouchableOpacity
                    activeOpacity={.5}

                    onPress={() => {
                        changeModalData([]);
                        changeModalVisibility({
                            ...modalVisible
                            ,
                            title: 'نام زون',
                            selected_item: name,
                            changeSelected_item: changename,
                            show: true,
                            coverScreen: false
                        })
                    }}
                    style={styles.row}
                >
                    <Icon style={{
                        fontSize: 18, color: 'white',
                        marginRight: 10
                    }} name='chevron-left' />

                    <Text>{name}</Text>

                    <View style={{
                        flexDirection: 'column',
                        flex: 1
                    }}>
                        <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{'نام زون'}</Text>

                    </View>

                </TouchableOpacity>


                <SettingRow
                    title='نوع زون'
                    value={zoneType !== null ? zonesTypes[zoneType].label : ''}
                    {...{ modalVisible }}
                    {...{ changeModalVisibility }}
                    items={zonesTypes}
                    selected_item={zoneType}
                    changeSelected_item={changeZoneType}
                    changeModalData={changeModalData}
                    coverScreen
                />

                <SettingRow
                    title='نوع عملکرد زون‌ها'
                    value={zoneMode !== null ? zonesPrefrences[zoneMode].label : ''}
                    {...{ modalVisible }}
                    {...{ changeModalVisibility }}
                    items={zonesPrefrences}
                    selected_item={zoneMode}
                    changeSelected_item={changeZoneMode}
                    changeModalData={changeModalData}
                />

                <SettingRow
                    title='دینگ دانگ'
                    value={zoneDingdong !== null ? zonesDingDong[zoneDingdong].label : ''}
                    {...{ modalVisible }}
                    {...{ changeModalVisibility }}
                    items={zonesDingDong}
                    selected_item={zoneDingdong}
                    changeSelected_item={changeZoneDingdong}
                    changeModalData={changeModalData}
                />




            </View>



            <BottomBtn onPress={SendMessage}>
                ارسال تنظیمات
            </BottomBtn>


            <Modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                title='نام زون'
                coverScreen={modalVisible.coverScreen}
                data={modalData}
                validator={zoneNameValidationSchema}
            />
            <SelectSimModal
                SelectedSimModal={SelectedSimModal}
                changeModalShow={changeSelectedSimModal}
                return_func={SelectedSimModal.return_func}
            />

        </View>
    )
}

export default ZonesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});



//  --------- row for setting
const SettingRow = (props) => {

    const RowClick = async () => {

        await props.changeModalData(props.items)
        await props.changeModalVisibility({
            ...props.modalVisible
            ,
            title: props.title,
            selected_item: props.selected_item,
            changeSelected_item: props.changeSelected_item,
            show: true,
            coverScreen: props.coverScreen
        })
    }
    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={styles.row}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{props.title}</Text>
                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{props.value}</Text>
            </View>

        </TouchableOpacity>
    )
}



const zoneNameValidationSchema = Yup.object().shape({
    name: Yup
        .string()
        .max(14, ({ max }) => `نام زون باید حداکثر ${max} کاراکتر باشد`)
        .required('فیلد نام دستگاه الزامی است'),
})


const ChangeNameContent = (props) => {
    return (
        <Formik
            initialValues={{
                name: ''
            }}

            validationSchema={zoneNameValidationSchema}

            onSubmit={values => {
                props.changeZoneName(values.name);
                props.setModalVisible(false);
            }}
        >

            {({
                handleChange,
                handleBlur,
                handleSubmit,
                values,
                touched,
                errors, }) => (
                <View>
                    <Input
                        value={'زون شماره۱'}
                        placeholder='نام ریموت'
                    />

                    <TouchableOpacity>
                        <Text>ثبت</Text>
                    </TouchableOpacity>
                </View>
            )}
        </Formik>
    )
}

