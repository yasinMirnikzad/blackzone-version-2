import React, { useState } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Feather';

import { Text, ZonesModal } from '../../components';



import { Background, gray, Primary } from '../../config/colors.json';



// ----- data
const zonesPrefrences = [
    { id: 'C', label: 'در حالت عادی بسته NC' },
    { id: 'O', label: 'در حالت عادی باز NO' }
]

const zonesTypes = [
    { id: '0010', label: 'زون آلارم' },
    { id: '0003', label: 'نیمه‌فعال' },
    { id: '0004', label: 'تاخیر در ورود' },
    { id: '0008', label: 'تاخیر در خروج' },
    { id: '000C', label: 'تاخیر در ورود و خروج' },
    { id: '0020', label: '24 ساعته' },
    { id: '0040', label: 'تشخیص دستکاری' },
    { id: '0080', label: 'آتش سوزی' },
    { id: '0100', label: 'پدال-وضعیت اضطراری' },
    { id: '0200', label: 'پدال-وضعیت تهاجم' }
    // { id: '&&&&', label: '' },
]

const zoneDingDong = [
    { id: 'D', label: 'فعال' },
    { id: 'O', label: 'غیرفعال' }
]


const FastSetupPageTwo = (props) => {
    const navigation = useNavigation();
    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false,
        index: -1,
        type: 0
    });
    const [modalData, changeModalData] = useState([]);
    const [Zones, setZones] = useState([
        {
            id: 0, title: 'زون شماره 1',
            //-----O=deactive   D=active
            dingDang: '&',
            //----C=NC  O=NO    
            mode: '&',
            type: '&&&&'
        },
        {
            id: 1, title: 'زون شماره 2',
            dingDang: '&',
            mode: '&',
            type: '&&&&'
        },
        {
            id: 2, title: 'زون شماره 3',
            dingDang: '&',
            mode: '&',
            type: '&&&&'
        },
        {
            id: 3, title: 'زون شماره 4',
            dingDang: '&',
            mode: '&',
            type: '&&&&'
        },
        {
            id: 4, title: 'زون بی سیم',
            dingDang: '&',
            type: '&&&&'
        }
    ]);

    
    // ----> type ===0 ? zonetype  , ===1 zonemode , === 2 zonedingdong
    const changeItemStatus = (id, index, type) => {
        let ZonesArray = Zones;

        if (type === 0)
            ZonesArray[index].type = id;
        else if (type === 1)
            ZonesArray[index].mode = id;
        else
            ZonesArray[index].dingDang = id;

        setZones(ZonesArray);
    }


    const GoToNextPage = () => {
         navigation.navigate('FastSetupThree', {
            Zones,
            ...props.route.params
        })
    }




    return (
        <View style={styles.container}>

            <View style={styles.content}>

                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={Zones}
                    ListFooterComponent={() => <View style={{ height: 100 }}></View>}
                    keyExtractor={(item, index) => String('setting' + index)}
                    renderItem={({ item, index }) => {
                        return (
                            <View style={{
                                borderBottomWidth: index != 4 ? 1 : 0,
                                borderBottomColor: '#323232',
                                paddingVertical: 10,

                            }}>
                                <Text fontWeight='Bold' style={{ color: Primary, fontSize: 16 }}>{item.title}</Text>
                                <SettingRow
                                    index={index}
                                    title='نوع زون'
                                    value={Zones[index].type === '&&&&' ? '' : Zones[index].type}
                                    {...{ modalVisible }}
                                    {...{ changeModalVisibility }}
                                    items={zonesTypes}
                                    selected_item={Zones[index].type}
                                    changeSelected_item={changeItemStatus}
                                    changeModalData={changeModalData}
                                    type={0}
                                //    -----------------
                                // changeModalVisibility={changeModalVisibility}
                                // modalVisible={modalVisible}
                                // changeModalData={changeModalData}
                                // key={String('zonetype' + index)}
                                // // send item custom
                                // item={{ title: 'نوع زون', value: item.type, items: zonesTypes }}
                                />

                                {index != 4 &&
                                    <SettingRow
                                        index={index}
                                        title='نوع عملکرد زون‌ها'
                                        value={Zones[index].mode === '&' ? '' : Zones[index].mode}
                                        {...{ modalVisible }}
                                        {...{ changeModalVisibility }}
                                        items={zonesPrefrences}
                                        selected_item={Zones[index].mode}
                                        changeSelected_item={changeItemStatus}
                                        changeModalData={changeModalData}
                                        type={1}
                                    // ---------------------
                                    // changeModalVisibility={changeModalVisibility}
                                    // modalVisible={modalVisible}
                                    // changeModalData={changeModalData}
                                    // key={String('zonemode' + index)}
                                    // // send item custom
                                    // item={{ title: 'نوع عملکرد زون‌ها', value: item.mode, items: zonesPrefrences }}
                                    />
                                }

                                <SettingRow
                                    index={index}
                                    title='دینگ دانگ'
                                    value={Zones[index].dingDang === '&' ? '' : Zones[index].dingDang}
                                    {...{ modalVisible }}
                                    {...{ changeModalVisibility }}
                                    items={zoneDingDong}
                                    selected_item={Zones[index].dingDang}
                                    changeSelected_item={changeItemStatus}
                                    changeModalData={changeModalData}
                                    type={2}
                                // -------------------------
                                // changeModalVisibility={changeModalVisibility}
                                // modalVisible={modalVisible}
                                // changeModalData={changeModalData}
                                // key={String('zonetype' + index)}
                                // // send item custom
                                // key={String('zonedingdong' + index)}
                                // item={{ title: 'دینگ دانگ', value: item.dingDang, items: zoneDingDong }}
                                />
                            </View>
                        )
                    }
                    }
                />



                <View style={styles.formBtnContainer}>
                    <TouchableOpacity
                        onPress={GoToNextPage}
                        activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnNext }}>
                        <Text style={{ color: Background, fontSize: 15 }}>بعدی</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => navigation.goBack()}
                        activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnPrev }}>
                        <Text style={{ fontSize: 15, color: Primary }} >برگشت</Text>
                    </TouchableOpacity>
                </View>



            </View>


            <ZonesModal
                // send title and show state to modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                // coverScreen
                data={modalData}
            >
            </ZonesModal>

        </View>
    )
}

export default FastSetupPageTwo;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    },
    formBtnContainer: {
        flex: 1,
        flexDirection: 'row',
        width: '100%',
        position: 'absolute',
        bottom: 20,
        alignSelf: 'center'
    },
    formBtn: {
        height: 52,
        borderRadius: 10,
        borderColor: Primary,
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    formBtnNext: {
        backgroundColor: Primary,
        marginRight: 5,
        flex: 1.5
    },
    formBtnPrev: {
        backgroundColor: Background,
        color: Primary,
        marginLeft: 5,
        flex: 1
    }


});





//  --------- row for setting
const SettingRow = ({ items, changeModalVisibility, modalVisible,
    changeModalData, title, value, selected_item,
    changeSelected_item, index, type }) => {


    const RowClick = async () => {

        await changeModalData(items);

        await changeModalVisibility({
            ...modalVisible,
            title: title,
            selected_item: selected_item,
            changeSelected_item: changeSelected_item,
            show: true,
            coverScreen: false,
            index,
            type
        });


    }

    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={{
                ...styles.row
            }}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />


            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{title}</Text>

                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{value}</Text>

            </View>

        </TouchableOpacity>
    )
}


