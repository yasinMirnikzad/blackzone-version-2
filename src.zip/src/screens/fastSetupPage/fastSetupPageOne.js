import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, StyleSheet, FlatList, BackHandler, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

import { Text, Modal, Input } from '../../components';

import { Background, gray, Primary, Seccondary } from '../../config/colors.json';







const ZonesPage = (props) => {
    const navigation = useNavigation();

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [modalData, changeModalData] = useState([]);
    //------- states
    const [alarmDuration, changeAlarmDuration] = useState('&&');
    const [chirpMode, changeChirpMode] = useState('&');
    const [relayMode, changeRelayMode] = useState('&');
    const [remoteDKey, changeRemoteDKey] = useState('000');
    const [entryTime, changeEntryTime] = useState('&&');
    const [exitTime, changeExitTime] = useState('&&');
    const [roaming, changeRoaming] = useState('00');


    const SettingItems = [
        // modat zaman azhir
        {
            title: 'مدت زمان آژیر',
            items: [
                { label: 'سایلنت', id: '00' },
                { label: '1 دقیقه', id: '01' },
                { label: '3 دقیقه', id: '03' },
                { label: '5 دقیقه', id: '05' },
                { label: '10 دقیقه', id: '10' },
                { label: '15 دقیقه', id: '15' },
                { label: '20 دقیقه', id: '20' }
            ],
            value: alarmDuration, // a state
            changeFunction: changeAlarmDuration // function to change state
        },
        {
            title: 'نحوه پخش تک‌آژیر',
            items: [
                { label: 'سیرن', id: 'S' },
                { label: 'بلندگوی داخلی', id: 'I' },
                { label: 'بلندگوی خارجی', id: 'E' }],
            border: true,
            value: chirpMode,
            changeFunction: changeChirpMode
        },
        {
            title: 'حالت عملکرد رله',
            items: [{ label: 'روشن / خاموش', id: 'S' },
            { label: 'تایمر‌دار', id: 'T' },
            { label: 'پالسی', id: 'P' },
            { label: 'هم‌زمانی با آژیر', id: 'A' },
            ],
            value: relayMode,
            changeFunction: changeRelayMode,
        },
        // in monde
        {
            title: 'زمان عملکرد رله در حالت تایمر',
            items: [],
            value: '',
            changeFunction: '',
            border: true,
            // clock
            clock: true
        },
        {
            title: 'عملکرد کلید چهارم ریموت',
            items: [
                { label: 'آژیر آزاد', id: '100' },
                { label: 'کنترل رله', id: '101' },
                { label: 'دینگ‌دانگ', id: '110' },
                { label: 'درخواست کمک', id: '111' }
            ],
            border: true,
            value: remoteDKey,
            changeFunction: changeRemoteDKey,
            // --?? check she vase chie
            dkey: true
        },
        {
            title: 'رومینگ',
            items: [
                { label: 'فعال', id: '11' },
                { label: 'غیر‌فعال', id: '10' }
            ],
            border: true,
            value: roaming,
            changeFunction: changeRoaming,
        },
        {
            title: 'تاخیر ورود در زون‌های تاخیری',
            items: [
                { label: '۱۰ ثانیه', id: '0A' },
                { label: '۲۰ ثانیه', id: '14' },
                { label: '۳۰ ثانیه', id: '1E' },
                { label: '۱ دقیقه', id: '3C' },
                { label: '۳ دقیقه', id: 'B4' },
            ],
            value: entryTime,
            changeFunction: changeEntryTime,
        },
        {
            title: 'تاخیر خروج در زون‌های تاخیری',
            items: [
                { label: '۱۰ ثانیه', id: '0A' },
                { label: '۲۰ ثانیه', id: '14' },
                { label: '۳۰ ثانیه', id: '1E' },
                { label: '۱ دقیقه', id: '3C' },
                { label: '۳ دقیقه', id: 'B4' },
            ],
            value: exitTime,
            changeFunction: changeExitTime
        }
    ]




    const GoToNextPage = () => {
        navigation.navigate('FastSetupTwo',
            {
                alarmDuration,
                chirpMode,
                relayMode,
                remoteDKey,
                entryTime,
                exitTime,
                roaming
            })
    }



    return (
        <View style={styles.container}>

            <View style={styles.content}>
                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={SettingItems}
                    ListHeaderComponent={() =>
                        <View style={{ marginVertical: 10 }}>
                            <Text fontWeight='Bold' style={{ fontSize: 17, color: Primary }}>تنظیمات عملکردی</Text>
                        </View>}
                    ListFooterComponent={() => <View style={{ height: 100 }}></View>}
                    keyExtractor={(item, index) => String('setting' + index)}
                    renderItem={({ item, index }) =>
                        <SettingRow
                            {...{ item }}
                            changeModalData={changeModalData}
                            value={item.value}
                            {...{ modalVisible }}
                            {...{ changeModalVisibility }}
                            selected_item={item.value}
                            changeSelected_item={item.changeFunction}
                        />
                    }
                />

                <View style={styles.formBtnContainer}>
                    <TouchableOpacity
                        onPress={GoToNextPage}
                        activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnNext }}>
                        <Text style={{ color: Background, fontSize: 15 }}>بعدی</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => navigation.goBack()}
                        activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnPrev }}>
                        <Text style={{ fontSize: 15, color: Primary }} >برگشت</Text>
                    </TouchableOpacity>
                </View>

            </View>






            <Modal
                // send title and show state to modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                // coverScreen
                data={modalData}
            >

            </Modal>

        </View>
    )
}

export default ZonesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        flex: 1,
        padding: 16
    },
    pageTitle: {
        color: Primary,
        fontSize: 18,
        marginTop: 10
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    },
    formBtnContainer: {
        flex: 1,
        flexDirection: 'row',
        width: '100%',
        position: 'absolute',
        bottom: 20,
        alignSelf: 'center'
    },
    formBtn: {
        height: 52,
        borderRadius: 10,
        borderColor: Primary,
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    formBtnNext: {
        backgroundColor: Primary,
        marginRight: 5,
        flex: 1.5
    },
    formBtnPrev: {
        backgroundColor: Background,
        color: Primary,
        marginLeft: 5,
        flex: 1
    }

});



//  --------- row for setting
const SettingRow = ({ item, changeModalVisibility, modalVisible,
    changeModalData, selected_item, changeSelected_item }) => {


    const RowClick = async () => {

        if (!item.input && !item.clock)
            await changeModalData(item.items);
        else
            await changeModalData([]);

        await changeModalVisibility({
            ...modalVisible
            ,
            title: item.title,
            selected_item: selected_item,
            changeSelected_item: changeSelected_item,
            show: true,
            coverScreen: false
        })

    }

    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={{
                ...styles.row,
                borderBottomColor: '#313131',
                borderBottomWidth: item.border ? 1 : 0
            }}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            {/* for some modal values that has name we just want to show answer in row */}
            {item.input &&
                <Text>{item.value}</Text>
            }

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{item.title}</Text>

                {/* for some modal values that has name we just want to show answer in row */}
                {!item.input &&
                    <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{item.value}</Text>
                }

            </View>

        </TouchableOpacity>
    )
}



const ChangeNameContent = (props) => {
    return (
        <View>
            <Input
                value={'زون شماره۱'}
                placeholder='نام ریموت'
            />
        </View>
    )
}


