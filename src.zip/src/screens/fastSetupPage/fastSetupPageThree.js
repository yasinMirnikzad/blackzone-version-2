import React, { useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';

import { Text, Input, AddUserModal } from '../../components';

import { Background, Primary, Seccondary } from '../../config/colors.json';
import { background } from 'native-base/lib/typescript/theme/styled-system';



// ----- fake data
const Data = [
    { name: 'زون شماره ۱', status: 'A' },
    { name: 'زون شماره ۲', status: 'D' }
]

const UserType =
    [
        { label: 'مدیر دستگاه', id: 'M' },
        { label: 'مخاطب هشدار', id: 'C' },
    ]


const ZonesPage = (props) => {
    const navigation = useNavigation();
    const [refreshFlatlist, setRefreshFlatList] = useState(false);
    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: 'اطلاعات فرد مورد نظر را وارد کنید'
    });
    const [users, changeUsers] = useState([])


    // role mean C or M
    const addUser = async (theuser) => {
        const Users = users;

        let newuser = { ...theuser, id: Users.length + 1 }

        await Users.push(newuser);
        await changeUsers(Users);

        // at end close the user
        await changeModalVisibility({
            ...modalVisible,
            show: false,
            selected_index: -1
        })

    }

    const DeleteUser = async (index) => {
        let Users = users;
        await Users.splice(index, 1);
        await changeUsers(Users)
        setRefreshFlatList(!refreshFlatlist)
    }


    // --------------------------- send sms :)
    const MakeSendString = () => {

        console.log('props', props.route.params)


        // inja dg bayd send she :D
    }



    return (
        <View style={styles.container}>
            <View style={styles.content}>

                <Text
                    fontWeight='Bold'
                    style={styles.pageTitle}>شماره و نوع دسترسی را وارد کنید</Text>
                <FlatList
                    data={users}
                    extraData={refreshFlatlist}
                    // extraData(refreshFlatlist)
                    keyExtractor={(item, index) => String('row' + index)}

                    renderItem={({ item, index }) =>
                        <View
                            // onPress={() => navigation.navigate('EditZonesPage')}
                            style={styles.row}
                        >

                            <TouchableOpacity
                                onPress={() => DeleteUser(index)}
                                style={{
                                    flexDirection: 'row',
                                    height: '100%',
                                    alignItems: 'center'
                                }}>
                                <Icon name='x' style={{ color: 'white', fontSize: 20 }} />
                                <Text fontWeight='Light' style={{ marginLeft: 10, fontSize: 15 }}>حذف</Text>
                            </TouchableOpacity>

                            <View style={{
                                flexDirection: 'column',
                                flex: 1
                            }}>
                                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{item.role === 'M' ? 'مدیردستگاه' : 'مخاطب هشدار'}</Text>
                                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{item.phonenumber}</Text>
                            </View>

                        </View>
                    }
                />


                <TouchableOpacity
                    onPress={() => changeModalVisibility({ ...modalVisible, show: true })}
                    activeOpacity={.4}
                    style={styles.addBtn}>
                    <Icon style={{ color: Primary, fontSize: 22 }} name='plus-circle' />
                    <Text style={styles.addBtnText}>اضافه کردن افراد</Text>
                </TouchableOpacity>



            </View>

            <View style={styles.formBtnContainer}>
                <TouchableOpacity
                    onPress={MakeSendString}
                    activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnNext }}>
                    <Text style={{ color: Background, fontSize: 15 }}>ارسال</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    onPress={() => navigation.goBack()}
                    activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnPrev }}>
                    <Text style={{ fontSize: 15, color: Primary }} >برگشت</Text>
                </TouchableOpacity>
            </View>



            <AddUserModal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                changeUser={addUser}
                usertypes={UserType}
            />




        </View>
    )
}

export default ZonesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1,
        padding: 16
    },
    content: {
        backgroundColor: Background,
        // flex: 1,

    },
    pageTitle: {
        marginVertical: 40,
        fontSize: 17,

    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addBtn: {
        fontSize: 17,
        marginTop: 30,
        borderRadius: 12,
        borderWidth: 2,
        borderColor: Primary,
        width: '60%',
        alignSelf: 'center',
        justifyContent: 'space-around',
        alignItems: 'center',
        flexDirection: 'row',
        paddingVertical: 12
    },
    addBtnText: {
        fontSize: 17,
        color: Primary
    },
    formBtnContainer: {
        flex: 1,
        flexDirection: 'row',
        width: '100%',
        position: 'absolute',
        bottom: 20,
        alignSelf: 'center'
    },
    formBtn: {
        height: 52,
        borderRadius: 10,
        borderColor: Primary,
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    formBtnNext: {
        backgroundColor: Primary,
        marginRight: 5,
        flex: 1.5
    },
    formBtnPrev: {
        backgroundColor: Background,
        color: Primary,
        marginLeft: 5,
        flex: 1
    }

});



