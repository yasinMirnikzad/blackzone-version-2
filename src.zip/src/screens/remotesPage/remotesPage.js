import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { useSelector, useDispatch } from 'react-redux';
import { timestamp } from '../../utilities';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';

import { Header, Text, FunctionalModal, SelectSimModal } from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';




const RemotesPage = (props) => {
    const navigation = useNavigation();

    const dispatch = useDispatch();
    const select_device = useSelector((store) => store.selected_device.device);

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        item: {},
        selected_index: -1
    });
    const [SelectedSimModal, changeSelectedSimModal] = useState({
        show: false,
        message: ''
    })
    const [remotes, changeRemotes] = useState([]);

    // ------ functions for items
    // -------------- sendMessage
    const ChangeActivity = async (value) => {
        // await requestSmsPermission();
        let time2 = timestamp();
        console.log('val', value)
        const message = 'PR' + select_device.device_securitycode + time2
            + '&&&&&&&&&&&&&&' + modalVisible.selected_index.toString(16).padStart(2, '0') +
            value + '&&&&&&&&';

        // inja ykm kond mishe chon dota set state dare :)
        // await changeModalVisibility({
        //     show: false,
        //     item: {},
        //     selected_index: -1
        // })

        // await changeSelectedSimModal({
        //     ...SelectedSimModal,
        //     show: true,
        //     message: message.toUpperCase()
        // })


    }

    const GoToEdit = async (index) => {
        // ------ go to edit moderate page
        navigation.navigate('EditRemotePage', { id: index })
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })
    }

    // ------ data for modal
    const modalItems = [
        { label: 'فعال', value: 'A', function: ChangeActivity },
        { label: 'غیرفعال', value: 'D', function: ChangeActivity },
        { label: 'ویرایش', function: GoToEdit, func: true }
    ]

    // -------------- useEffect
    useEffect(() => {
        GetData(select_device.lastMessage)
    }, [])

    const GetData = async (message) => {

        let remotesType = message.slice(82, 102);
        let remotesArr = [
            { name: 'ریموت شماره 1', status: 'D' },
            { name: 'ریموت شماره 2', status: 'D' },
            { name: 'ریموت شماره 3', status: 'D' },
            { name: 'ریموت شماره 4', status: 'D' },
            { name: 'ریموت شماره 5', status: 'D' },
            { name: 'ریموت شماره 6', status: 'D' },
            { name: 'ریموت شماره 7', status: 'D' },
            { name: 'ریموت شماره 8', status: 'D' },
            { name: 'ریموت شماره 9', status: 'D' },
            { name: 'ریموت شماره 10', status: 'D' },
            { name: 'ریموت شماره 11', status: 'D' },
            { name: 'ریموت شماره 12', status: 'D' },
            { name: 'ریموت شماره 13', status: 'D' },
            { name: 'ریموت شماره 14', status: 'D' },
            { name: 'ریموت شماره 15', status: 'D' },
            { name: 'ریموت شماره 16', status: 'D' },
            { name: 'ریموت شماره 17', status: 'D' },
            { name: 'ریموت شماره 18', status: 'D' },
            { name: 'ریموت شماره 19', status: 'D' },
            { name: 'ریموت شماره 20', status: 'D' }
        ]
        for (let i = 0; i < remotesType.length; i++) {
            switch (remotesType[i]) {
                //--------------------------------------------undefined
                case '0':
                    remotesArr[i].status = 'F';
                    break;
                //---------------------------------------------remote asli
                case 'M':
                    remotesArr[i].status = 'A';
                    break;
                case 'N':
                    remotesArr[i].status = 'F';
                    break;
                //---------------------------------------------remote controli
                case 'S':
                    remotesArr[i].status = 'A';
                    break;
                case 'Z':
                    remotesArr[i].status = 'F';
                    break;
                default:
                    break;
            }
        }

        console.log('remotes ,', remotesArr)
        await changeRemotes(remotesArr);
        const device = JSON.parse(await AsyncStorage.getItem('devices'));
        device[select_device.id].lastMessage = message;
        await AsyncStorage.setItem('devices', JSON.stringify(device));
        await dispatch(setDevice(device[select_device.id]));

        // SetLoadingVisible(false);
    }


    return (
        <View style={styles.container}>
            <Header title='دسترسی‌ها' />

            <View style={styles.content}>

                <FlatList
                    data={remotes}
                    key={(item, index) => String('row' + index)}
                    renderItem={({ item, index }) =>
                        item.status !== 'F' ?
                            <TouchableOpacity
                                onPress={() => {
                                    console.log('item', item)
                                    changeModalVisibility({
                                        ...modalVisible,
                                        show: true,
                                        item: item,
                                        selected_index: index
                                    })
                                }}

                                style={styles.row}
                            >
                                <Icon style={{
                                    fontSize: 18, color: 'white',
                                    marginRight: 10
                                }} name='chevron-left' />

                                <Text>{item.status === 'A' ?
                                    'فعال' :
                                    'غیرفعال'
                                }</Text>

                                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17, flex: 1 }}>{item.name}</Text>

                            </TouchableOpacity>
                            :
                            null
                    }
                />


            </View>

            <FunctionalModal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                data={modalItems}
            />

            <SelectSimModal
                SelectedSimModal={SelectedSimModal}
                changeModalShow={changeSelectedSimModal}
                return_func={GetData}
            />


        </View>
    )
}

export default RemotesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});

