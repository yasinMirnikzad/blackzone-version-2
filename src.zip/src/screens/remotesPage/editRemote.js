import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { Formik } from 'formik';
import * as Yup from 'yup';

import { EditHeader, Text, Modal, BottomBtn, Input, MultiSelectModalComponent } from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';

// ------- utilities
import { timestamp } from '../../utilities';



// ------------------ datas
const days_a_weeks = [
    { id: '0X80', label: 'شنبه' },
    { id: '0X40', label: 'یک‌شنبه' },
    { id: '0X20', label: 'دوشنبه' },
    { id: '0X10', label: 'سه‌شنبه' },
    { id: '0X08', label: 'چهارشنبه' },
    { id: '0X04', label: 'پنج‌شنبه' },
    { id: '0X02', label: 'جمعه' },
]

const remote_shifts = [
    { id: '0X10', label: 'عملکرد ۲۴ ساعته' },
    { id: '0X80', label: 'شیفت صبح' },
    { id: '0X40', label: 'شیفت عصر' },
    { id: '0X20', label: 'شیفت شب' }
]

const remote_Capabilities = [
    { label: 'فعال‌سازی دستگاه', id: '0X8000' },
    { label: 'خروج دستگاه از حالت فعال', id: '0X4000' },
    { label: 'نیمه‌فعال‌سازی دستگاه', id: '0X3000' },
    { label: 'خروج از حالت نیمه‌فعال', id: '0X0800' },
    { label: 'قطع آژیر', id: '0X0400' },
    { label: 'کنترل رله', id: '0X0200' },
    { label: 'کنترل دینگ‌دانگ', id: '0X0100' },
    { label: 'ارسال درخواست کمک', id: '0X0080' },
    { label: 'آژیر آزاد', id: '0X0040' }
]



const remotes_mode = [
    { label: 'ریموت اصلی', id: 'M' },
    { label: 'ریموت درخواست کمک', id: 'S' }
]











const EditRemotePage = (props) => {
    const { id } = props.route.params;

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [modalMultiVisible, changeModalMultiVisible] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [modalData, changeModalData] = useState([]);
    const [name, changename] = useState('');

    const [remoteMode, changeRemoteMode] = useState('&');
    const [permitions, changePermitions] = useState([]); // &&&&
    const [allowedShifts, changeAllowedShifts] = useState([]); // &&
    const [allowedDays, changeAllowedDays] = useState([]); // &&



    const checkname = (name) => {

    }

    const SendSms = async () => {
        let nameVal = '&&&&&&&&&&&&&&';
        let time = timestamp();

        if (name) {
            nameVal = name;
            if (nameVal.length < 14)
                nameVal += ';';
            nameVal = nameVal.padEnd(14, '0')
        }


        let perm = 0;
        await permitions.map((item) =>
            perm = perm + parseInt(remote_Capabilities[item].id, 16)
        )
        let permission_value = await perm.toString(16).padStart(4, '0');

        let shift = 0;
        await allowedShifts.map((item) =>
            shift = shift + parseInt(remote_shifts[item].id, 16)
        )

        let allowedShifts_value = await shift.toString(16).padStart(2, '0')


        let days = 0;
        await allowedDays.map((item) =>
            days = days + parseInt(days_a_weeks[item].id, 16)
        )

        let allowedDays_value = await shift.toString(16).padStart(2, '0')


        // selected device security
        // let message = 'PR' + 'selectedDevice.securitycode' + time + nameVal + id.toString(16) +
        //     '&' + remoteType + permission_value + allowedDays + allowedShifts_value;


        // const message = 'PR' + selectedDevice.securitycode + time2 +
        //     name.padEnd(14, '0') + id.toString(16).padStart(2, '0') +
        //     remote.status + remoteType + permitions + allowedDays_value + allo;


        // console.log('mess', message)

    }










    return (
        <View style={styles.container}>
            <EditHeader title='ویرایش ریموت' />

            <View style={styles.content}>

                <TouchableOpacity
                    activeOpacity={.5}

                    onPress={() => {
                        changeModalData([]);
                        changeModalVisibility({
                            ...modalVisible
                            ,
                            title: 'نام ریموت',
                            selected_item: name,
                            changeSelected_item: changename,
                            show: true,
                            coverScreen: false
                        })
                    }}
                    style={{ ...styles.row, marginBottom: 10 }}
                >
                    <Icon style={{
                        fontSize: 18, color: 'white',
                        marginRight: 10
                    }} name='chevron-left' />

                    <Text>{name}</Text>

                    <View style={{
                        flexDirection: 'column',
                        flex: 1
                    }}>
                        <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{'نام ریموت'}</Text>

                    </View>

                </TouchableOpacity>


                <SettingRow
                    title='نوع ریموت'
                    value={remoteMode !== '&' ? remotes_mode[remoteMode].label : ''}
                    {...{ modalVisible }}
                    {...{ changeModalVisibility }}
                    items={remotes_mode}
                    selected_item={remoteMode}
                    changeSelected_item={changeRemoteMode}
                    changeModalData={changeModalData}
                />

                <SettingRow
                    title='قابلیت‌های ریموت'
                    value={''}
                    modalVisible={modalMultiVisible}
                    changeModalVisibility={changeModalMultiVisible}
                    items={remote_Capabilities}
                    selected_item={permitions}
                    changeSelected_item={changePermitions}
                    changeModalData={changeModalData}
                />

                <SettingRow
                    title='روزهای مجاز فعالیت در هفته'
                    value={''}
                    modalVisible={modalMultiVisible}
                    changeModalVisibility={changeModalMultiVisible}
                    items={days_a_weeks}
                    selected_item={allowedDays}
                    changeSelected_item={changeAllowedDays}
                    changeModalData={changeModalData}
                />

                <SettingRow
                    title='شیفت‌های مجاز به فعالیت'
                    value={''}
                    modalVisible={modalMultiVisible}
                    changeModalVisibility={changeModalMultiVisible}
                    items={remote_shifts}
                    selected_item={allowedShifts}
                    changeSelected_item={changeAllowedShifts}
                    changeModalData={changeModalData}
                />





            </View>



            <BottomBtn onPress={SendSms}>
                ارسال تنظیمات
            </BottomBtn>


            <Modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                title='نام زون'
                coverScreen={modalVisible.coverScreen}
                data={modalData}
                validator={zoneNameValidationSchema}
            />


            <MultiSelectModalComponent
                selectAll={true}

                modalVisible={modalMultiVisible}
                setModalVisible={changeModalMultiVisible}
                coverScreen={modalVisible.coverScreen}
                data={modalData}
                validator={zoneNameValidationSchema}

            />

        </View>
    )
}

export default EditRemotePage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    box: {
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        padding: 16,
        flexDirection: 'row'
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 6
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    addModrateBtn: {
        color: Primary,
        fontSize: 17,
        marginRight: 8,
        marginTop: 15
    }


});



//  --------- row for setting
const SettingRow = (props) => {

    const RowClick = async () => {

        await props.changeModalData(props.items)
        await props.changeModalVisibility({
            ...props.modalVisible
            ,
            title: props.title,
            selected_item: props.selected_item,
            changeSelected_item: props.changeSelected_item,
            show: true,
            coverScreen: props.coverScreen
        })
    }
    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={styles.row}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{props.title}</Text>
                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{props.value}</Text>
            </View>

        </TouchableOpacity>
    )
}



const zoneNameValidationSchema = Yup.object().shape({
    name: Yup
        .string()
        .max(14, ({ max }) => `نام زون باید حداکثر ${max} کاراکتر باشد`)
        .required('فیلد نام دستگاه الزامی است'),
})


const ChangeNameContent = (props) => {
    return (
        <Formik
            initialValues={{
                name: ''
            }}

            validationSchema={zoneNameValidationSchema}

            onSubmit={values => {
                props.changeZoneName(values.name);
                props.setModalVisible(false);
            }}
        >

            {({
                handleChange,
                handleBlur,
                handleSubmit,
                values,
                touched,
                errors, }) => (
                <View>
                    <Input
                        value={'زون شماره۱'}
                        placeholder='نام ریموت'
                    />

                    <TouchableOpacity>
                        <Text>ثبت</Text>
                    </TouchableOpacity>
                </View>
            )}
        </Formik>
    )
}

