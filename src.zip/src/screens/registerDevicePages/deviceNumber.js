import React from 'react';
import {
    StatusBar,
    StyleSheet,
    View,
    TouchableOpacity
} from 'react-native';

import { Formik } from 'formik';
import * as Yup from 'yup';
import { useNavigation } from '@react-navigation/native';

import { useSelector, useDispatch } from 'react-redux';
import { setDevice } from '../../redux/actions/deviceAction';
import AsyncStorage from '@react-native-async-storage/async-storage';


// ----------- component
import { Text, Input } from '../../components';

// ----------- color
import { Background, gray, Primary } from '../../config/colors.json';
const zones = [
    { title: 'زون شماره 1', status: 0, status_type: 'DDDD' },
    { title: 'زون شماره 2', status: 0, status_type: 'DDDD' },
    { title: 'زون شماره 3', status: 0, status_type: 'DDDD' },
    { title: 'زون شماره 4', status: 0, status_type: 'DDDD' },
    { title: 'زون بی سیم 1', status: 0, status_type: 'DDDD' },
    { title: 'زون بی سیم 2', status: 0, status_type: 'DDDD' },
    { title: 'زون بی سیم 3', status: 0, status_type: 'DDDD' },
    { title: 'زون بی سیم 4', status: 0, status_type: 'DDDD' }
];

const remotes = [
    { name: 'ریموت شماره 1', status: 'D' },
    { name: 'ریموت شماره 2', status: 'D' },
    { name: 'ریموت شماره 3', status: 'D' },
    { name: 'ریموت شماره 4', status: 'D' },
    { name: 'ریموت شماره 5', status: 'D' },
    { name: 'ریموت شماره 6', status: 'D' },
    { name: 'ریموت شماره 7', status: 'D' },
    { name: 'ریموت شماره 8', status: 'D' },
    { name: 'ریموت شماره 9', status: 'D' },
    { name: 'ریموت شماره 10', status: 'D' },
    { name: 'ریموت شماره 11', status: 'D' },
    { name: 'ریموت شماره 12', status: 'D' },
    { name: 'ریموت شماره 13', status: 'D' },
    { name: 'ریموت شماره 14', status: 'D' },
    { name: 'ریموت شماره 15', status: 'D' },
    { name: 'ریموت شماره 16', status: 'D' },
    { name: 'ریموت شماره 17', status: 'D' },
    { name: 'ریموت شماره 18', status: 'D' },
    { name: 'ریموت شماره 19', status: 'D' },
    { name: 'ریموت شماره 20', status: 'D' }
];





const devicePhoneNumberValidationSchema = Yup.object().shape({
    device_phonenumber: Yup
        .string()
        .length(11, ({ length }) => `شماره تلفن باید ${length} کاراکتر باشد`)
        .required('فیلد شماره تلفن الزامی است'),

    device_securitycode: Yup
        .string()
        .length(6, ({ length }) => `کد امنیتی باید ${length} کاراکتر باشد`)
        .required('فیلد کد امنیتی الزامی است'),
})




const App = (props) => {
    const navigation = useNavigation();
    const dispatch = useDispatch();

    const { name, selectedSign } = props.route.params;;



    const addDevice = async (values) => {
        // save dar asyncstorage
        // update selected device

        let devices = JSON.parse(await AsyncStorage.getItem('devices'));

        console.log('devices', devices)
        if (devices) {
            const newdevice = {
                id: devices.length, name,
                password: 'password',
                device_phonenumber: values.device_phonenumber,
                device_securitycode: values.device_securitycode,
                selectedSign,
                contacts: [], moderators: [],
                zones: JSON.stringify(zones),
                remotes: JSON.stringify(remotes),
                lastMessage: ''
            };

            await devices.push(newdevice);

            try {
                await AsyncStorage.setItem('devices', JSON.stringify(devices));
                // if id is 1 so selected index is 0
                await AsyncStorage.setItem('selected_device', String((newdevice.id)));
                await dispatch(setDevice(newdevice));
                navigation.navigate('SubmitDevicePage')
            }
            catch (error) {

                console.log('save name error : ', error);
            }

        } else {

            let device = [];
            const newdevice = {
                id: 0,
                name,
                password: 'password',
                device_phonenumber: values.device_phonenumber,
                device_securitycode: values.device_securitycode,
                selectedSign,
                contacts: [],
                moderators: [],
                zones: JSON.stringify(zones),
                remotes: JSON.stringify(remotes),
                lastMessage: ''
            };
            device.push(newdevice);

            try {
                await AsyncStorage.setItem('devices', JSON.stringify(device));
                // if id is 1 so selected index is 0
                await AsyncStorage.setItem('selected_device', '0');
                await dispatch(setDevice(newdevice));
                navigation.navigate('SubmitDevicePage')

            }
            catch (error) {
                console.log('save name error : ', error);
            }
        }

        // navigation.navigate('SubmitDevicePage', {
        //     device_phonenumber: values.device_phonenumber,
        //     device_securitycode: values.device_securitycode,
        //     name,
        //     selectedSign
        // })
    }




    return (
        <View style={styles.container}>
            <StatusBar
                backgroundColor={'#3D3D3D'}
            />
            <Formik
                initialValues={{
                    device_phonenumber: '',
                    device_securitycode: ''
                }}
                enableReinitialize
                validationSchema={devicePhoneNumberValidationSchema}

                onSubmit={async (values) => {
                    await addDevice(values)
                }}
            >

                {({

                    handleChange,
                    handleBlur,
                    handleSubmit,
                    values,
                    touched,
                    errors
                }) => (
                    <View style={styles.formContainer}>

                        <Text fontWeight='Bold' style={styles.title}>شماره سیم داخل دستگاه:</Text>
                        <Input
                            onChangeText={handleChange('device_phonenumber')}
                            value={values.device_phonenumber}
                            style={styles.input}
                            placeholder='مثلا ۰۹۳۳۳۹۷۴۹۱۱'
                        />
                        <Text
                            fontWeight='Light'
                            style={styles.err}>{errors.device_phonenumber && touched.device_phonenumber && errors.device_phonenumber}</Text>


                        <Text fontWeight='Bold' style={{
                            ...styles.title,
                            ...styles.signTitle
                        }}>کدامنیتی دستگاه:</Text>
                        <Text style={styles.description}>کد درج شده روی دستگاه را وارد کنید</Text>
                        <Input
                            onChangeText={handleChange('device_securitycode')}
                            value={values.device_securitycode}
                            style={styles.input} placeholder='مثلا ۱۲۳۴۵۶' />

                        <Text
                            fontWeight='Light'
                            style={styles.err}>{errors.device_securitycode && touched.device_securitycode && errors.device_securitycode}</Text>



                        <View style={styles.formBtnContainer}>
                            <TouchableOpacity
                                onPress={handleSubmit}
                                activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnNext }}>
                                <Text style={{ fontSize: 16 }} >بعدی</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                onPress={() => navigation.goBack()}
                                activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnPrev }}>
                                <Text style={{ fontSize: 16 }} >برگشت</Text>
                            </TouchableOpacity>
                        </View>
                    </View>)}
            </Formik>


        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    formContainer: {
        marginTop: '40%',
        marginHorizontal: 24,
        flex: 2
    },
    title: {
        fontSize: 16
    },
    description: {
        fontSize: 14,
        color: gray
    },
    input: {
        marginTop: 6
    },
    signTitle: {
        marginTop: 50
    },
    formBtnContainer: {
        flex: 1,
        flexDirection: 'row',
        width: '100%',
        position: 'absolute',
        bottom: 20
    },
    formBtn: {
        height: 58,
        borderRadius: 10,
        borderColor: Primary,
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    formBtnNext: {
        backgroundColor: Primary,
        marginRight: 5,
        flex: 2
    },
    formBtnPrev: {
        backgroundColor: 'transparent',
        color: Primary,
        marginLeft: 5,
        flex: 1
    },
    err: {
        color: 'red',
        marginTop: 2,
        fontSize: 13
    }
});

export default App;




