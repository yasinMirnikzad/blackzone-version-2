

import React, { useState } from 'react';

import {
    StatusBar,
    StyleSheet,
    View,
    TouchableOpacity,
    ScrollView
} from 'react-native';
import { Button } from 'native-base';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useNavigation } from '@react-navigation/native';


// ----------- component
import { Text, Input } from '../../components';

// ----------- color
import { Background, gray, Primary } from '../../config/colors.json';



// ----------- data
const signs = [
    { id: 0, sign: '' },
    { id: 1, sign: '' },
    { id: 2, sign: '' },
    { id: 3, sign: '' },
    { id: 4, sign: '' }
]


// ----------- validator
const deviceNameValidationSchema = Yup.object().shape({
    name: Yup
        .string()
        .max(14, ({ max }) => `نام دستگاه باید حداکثر ${max} کاراکتر باشد`)
        .required('فیلد نام دستگاه الزامی است'),
})




const App = (props) => {
    const navigation = useNavigation();
    const [selectedSign, changeSelectedSign] = useState(0);


    return (
        <View style={styles.container}>
            <StatusBar
                backgroundColor={'#3D3D3D'}
            />
            <Formik
                initialValues={{
                    name: ''
                }}
                enableReinitialize
                validationSchema={deviceNameValidationSchema}
                onSubmit={values => {
                    navigation.navigate('DeviceNumberPage', {
                        name: values.name,
                        selectedSign: selectedSign
                    })
                    // changeModalshow()
                }}
            >

                {({

                    handleChange,
                    handleBlur,
                    handleSubmit,
                    values,
                    touched,
                    errors, }) => (

                    <View style={styles.formContainer}>

                        <Text fontWeight='Bold' style={styles.title}>نام دستگاه:</Text>
                        <Text style={styles.description}>یک نام برای دستگاه تعریف کنید</Text>
                        <Input
                            onChangeText={handleChange('name')}
                            value={values.name}
                            style={styles.input}
                            placeholder='مثلا دزدگیر شرکت' />

                        <Text
                            fontWeight='Light'
                            style={styles.err}>{errors.name && touched.name && errors.name}</Text>


                        <Text fontWeight='Bold' style={{
                            ...styles.title,
                            ...styles.signTitle
                        }}>یک نماد انتخاب کنید</Text>

                        <View style={styles.signBoxContainer}>
                            {signs.map((item, index) =>
                                <Button
                                    key={String('sign' + index)}
                                    onPress={() => changeSelectedSign(index)}
                                    style={{
                                        ...styles.signBox,
                                        borderColor: selectedSign === index ? Primary : gray
                                    }}>
                                    <Text>{index}</Text>
                                </Button>
                            )}
                        </View>


                        <View style={styles.formBtnContainer}>
                            <TouchableOpacity
                                onPress={handleSubmit}
                                activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnNext }}>
                                <Text style={{ fontSize: 16 }} >بعدی</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                onPress={() => navigation.goBack()}
                                activeOpacity={.4} style={{ ...styles.formBtn, ...styles.formBtnPrev }}>
                                <Text style={{ fontSize: 16 }} >برگشت</Text>
                            </TouchableOpacity>
                        </View>

                    </View>
                )
                }
            </Formik >
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    formContainer: {
        marginTop: '40%',
        flex: 2,
        height: '100%',
        marginHorizontal: 24,
    },
    title: {
        fontSize: 16
    },
    description: {
        fontSize: 14,
        color: gray
    },
    input: {
        marginTop: 6
    },
    signTitle: {
        marginTop: 50
    },
    signBoxContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 5,
        justifyContent: 'space-between'
    },
    signBox: {
        height: 55,
        width: 55,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        margin: 5,
        backgroundColor: 'transparent'
    },
    formBtnContainer: {
        flex: 1,
        flexDirection: 'row',
        width: '100%',
        position: 'absolute',
        bottom: 20
    },
    formBtn: {
        height: 58,
        borderRadius: 10,
        borderColor: Primary,
        borderWidth: 2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    formBtnNext: {
        backgroundColor: Primary,
        marginRight: 5,
        flex: 2
    },
    formBtnPrev: {
        backgroundColor: Background,
        color: Primary,
        marginLeft: 5,
        flex: 1,
    },
    err: {
        color: 'red',
        marginTop: 2,
        fontSize: 13
    }
});

export default App;




