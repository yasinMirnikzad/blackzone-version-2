import React from 'react';
import { View, Image, StatusBar } from 'react-native';

import { Background } from '../../config/colors.json';


const SplashPage = (props) => {

    return (
        <View style={{
            flex: 1, justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: Background
        }}>
            <StatusBar
                backgroundColor={'#3D3D3D'}
            />
            {/* <Image
                style={{ width: '100%', resizeMode: 'center' }}
                source={require('../../images/splash/splash.gif')}
            /> */}

        </View>
    )
}

export default SplashPage;