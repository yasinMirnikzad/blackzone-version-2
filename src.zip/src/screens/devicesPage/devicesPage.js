import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, StyleSheet, FlatList, TouchableOpacity, BackHandler } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { useSelector, useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setDevice } from '../../redux/actions/deviceAction';
import Toast from 'react-native-toast-message'




import { Header, Text, FunctionalModal } from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';


import {
    Cubeicon, HomeIcon,
    InstagramIcon, PrinterIcon
} from '../../images/deviceIcons';




const DeviceIcons = [
    <Cubeicon />,
    <HomeIcon />,
    <InstagramIcon />,
    <PrinterIcon />
]


const DevicesPage = (props) => {
    const dispatch = useDispatch();
    const navigation = useNavigation();
    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        item: {},
        selected_index: -1
    });
    const [activeIndex, changeActiveDevice] = useState(0);

    // ------ state for datas 
    const [devices, changeDevices] = useState([]);


    // ------ functions for items
    const ChangeActivity = async (value) => {

        //    inja bayad status_type ham taqir kone ba tavajoh b responi k miad
        // havaset bashe :D
        console.log('value', value)
        let Zones = zones;
        Zones[modalVisible.selected_index].status = value;

        // await requestSmsPermission();
        // let time2 = timestamp();


        // const message = 'P' + 'Z' + selectedDevice.securitycode + time2 + '&&&&&&&&&&&&&&' + props.id.toString(16) +
        //     status + '&&&&&&';

        // await SendSms(message.toUpperCase(), await checkPhoneNum(selectedDevice.phonenumber));
        // await GetSms(time, status, time2.toUpperCase());




        Zones[modalVisible.selected_index].status_type = 'SomeThing';
        await changeZones(Zones)
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })
    }

    const GoToEdit = async (index) => {
        // ------ go to edit page
        navigation.navigate('EditDevicePage', { id: index })
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })
    }

    const SelectDevice = async (index) => {
        await changeActiveDevice(index);
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        });
        await AsyncStorage.setItem('selected_device', JSON.stringify(index))
        await dispatch(setDevice(devices[index]));

    }

    // 1-> bayad delete she
    // 2-> agar index active bashe bayd taqir kone b yeki dg
    // 3-> agar akharin bashe khoroj kone
    // 4-> agar taki bashe va active khoroj kone
    const DeleteDivice = async (index) => {
        // if (devices.length === 0)
        //     toast.show('در صورت حذف این دستگاه از اپلیکیشن خارج میشوید!', {
        //         type: "danger ",
        //     });
        let newDevicesList = devices;
        await newDevicesList.splice(index, 1);
        await AsyncStorage.setItem('devices', JSON.stringify(newDevicesList));

        if (index === activeIndex) {
            // akhari bude pas bayd pak she va kharej she
            if (newDevicesList.length === 0) {
                await AsyncStorage.clear();
                // redux ham khali she
                await dispatch(setDevice());
                // exit kone
                BackHandler.exitApp()
            } else {
                await AsyncStorage.setItem('selected_device', JSON.stringify(newDevicesList[0].id));
                await dispatch(setDevice(devices[0]));
            }
        }        // function for if its the end of array
    
        await changeModalVisibility({
            show: false,
            item: {},
            selected_index: -1
        })
    }

    // ------ useEffect
    useEffect(() => {
        GetData()
    }, []);


    const GetData = async () => {
        let values = await AsyncStorage.multiGet(['selected_device', 'devices']);

        let devices = await JSON.parse(values[1][1]);
        let selected_device = await JSON.parse(values[0][1]);
        await changeDevices(devices);
        await changeActiveDevice(selected_device);

    }

    // ------ data for modal
    const modalItems = [
        { label: 'فعال', value: 'A', function: ChangeActivity },
        { label: 'غیرفعال', value: 'D', function: ChangeActivity },
        { label: 'انتخاب دستگاه', function: SelectDevice, func: true },
        { label: 'ویرایش', function: GoToEdit, func: true },
        { label: 'حذف دستگاه', function: DeleteDivice, func: true }
    ]


    return (
        <View style={styles.container}>
            <Header title={'دستگاه ها'} />

            <View style={styles.content}>

                <FlatList
                    data={devices}
                    key={(item, index) => String('row' + index)}
                    renderItem={({ item, index }) =>
                        <TouchableOpacity
                            onPress={() => changeModalVisibility({
                                ...modalVisible,
                                show: true,
                                item: item,
                                selected_index: index
                            })}
                            style={{
                                ...styles.row,
                                borderColor: activeIndex === index ? Primary : gray
                            }}
                        >
                            <Icon style={{
                                fontSize: 22, color: 'white',
                                marginRight: 10
                            }} name='more-vertical' />


                            <View style={{
                                flexDirection: 'row',
                                flex: 1,
                                justifyContent: 'flex-end'
                            }}>
                                <Text fontWeight='Medium' style={{
                                    marginRight: 13
                                    , fontSize: 17
                                }}>{item.name}</Text>

                                {DeviceIcons[item.icon]}

                            </View>

                        </TouchableOpacity>
                    }
                />


                <TouchableOpacity
                    onPress={() => navigation.navigate('DeviceInfoPage')}
                    activeOpacity={.5}
                    style={styles.addDevice}>
                    <Icon style={{ fontSize: 27, color: 'white' }} name={'plus-circle'} />
                    <Text style={{ fontSize: 18 }}>اضافه کردن دستگاه</Text>
                </TouchableOpacity>
            </View>


            <FunctionalModal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                data={modalItems}
            >
                {/* <ChangeNameContent /> */}
                {/* <ChangeRadioContent /> */}
            </FunctionalModal>


        </View>
    )
}

export default DevicesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 14,
        paddingVertical: 6,
        paddingHorizontal: 15,
        borderWidth: 2,
        borderRadius: 10,
        borderColor: gray,
        height: 65
    },
    addDevice: {
        flexDirection: 'row',
        alignItems: 'center',
        height: 65,
        borderWidth: 2,
        marginTop: 20,
        borderStyle: 'dashed',
        borderRadius: 10,
        borderColor: gray,
        justifyContent: 'space-around'
    },



});

