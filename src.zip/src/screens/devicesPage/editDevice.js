import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import { Formik } from 'formik';
import { Button } from 'native-base';

import * as Yup from 'yup';

import { Text, Modal, BottomBtn, Input, Header } from '../../components';

import { Background, gray, Primary } from '../../config/colors.json';

// ------- utilities
import { timestamp } from '../../utilities';


// ----------- data
const signs = [
    { id: 0, sign: '' },
    { id: 1, sign: '' },
    { id: 2, sign: '' },
    { id: 3, sign: '' },
    { id: 4, sign: '' }
]


const ZonesPage = (props) => {
    // const { id } = props.route.params;

    const [modalVisible, changeModalVisibility] = useState({
        show: false,
        title: '',
        selected_item: null,
        changeSelected_item: null,
        coverScreen: false
    });
    const [name, changename] = useState('');
    const [phoneNumber, changePhoneNumner] = useState('');
    const [selectedSign, changeSelectedSign] = useState();

    const checkname = (name) => {

    }


    return (
        <View style={styles.container}>
            <Header title='تنظیمات دستگاه' />

            <View style={styles.content}>

                <TouchableOpacity
                    activeOpacity={.5}

                    onPress={() => {
                        changeModalVisibility({
                            ...modalVisible
                            ,
                            title: 'نام دستگاه در اپلیکیشن',
                            selected_item: name,
                            changeSelected_item: changename,
                            show: true,
                            coverScreen: false
                        })
                    }}
                    style={styles.row}
                >
                    <Icon style={{
                        fontSize: 18, color: 'white',
                        marginRight: 10
                    }} name='chevron-left' />

                    <Text>{name}</Text>

                    <View style={{
                        flexDirection: 'column',
                        flex: 1
                    }}>
                        <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{'نام دستگاه در اپلیکیشن'}</Text>

                    </View>

                </TouchableOpacity>







                <TouchableOpacity
                    activeOpacity={.5}

                    onPress={() => {
                        changeModalVisibility({
                            ...modalVisible
                            ,
                            title: 'شماره سیم‌کارت',
                            selected_item: phoneNumber,
                            changeSelected_item: changePhoneNumner,
                            show: true,
                            coverScreen: false
                        })
                    }}
                    style={{
                        ...styles.row,
                        borderBottomColor: gray, borderBottomWidth: 1,

                    }}
                >
                    <Icon style={{
                        fontSize: 18, color: 'white',
                        marginRight: 10
                    }} name='chevron-left' />

                    <Text>{phoneNumber}</Text>

                    <View style={{
                        flexDirection: 'column',
                        flex: 1
                    }}>
                        <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{'شماره سیم‌کارت'}</Text>

                    </View>

                </TouchableOpacity>




                <Text fontWeight='Bold' style={{
                    ...styles.title,
                    ...styles.signTitle
                }}>یک نماد انتخاب کنید</Text>

                <View style={styles.signBoxContainer}>
                    {signs.map((item, index) =>
                        <Button
                            key={String('sign' + index)}
                            onPress={() => changeSelectedSign(index)}
                            style={{
                                ...styles.signBox,
                                borderColor: selectedSign === index ? Primary : gray
                            }}>
                            <Text>{index}</Text>
                        </Button>
                    )}
                </View>


            </View>



            <BottomBtn
            // onPress={SendSms}
            >
               ثبت
            </BottomBtn>


            <Modal
                modalVisible={modalVisible}
                setModalVisible={changeModalVisibility}
                coverScreen={modalVisible.coverScreen}
                data={[]}
                validator={zoneNameValidationSchema}
            >
                {/* <ChangeNameContent /> */}
                {/* <ChangeRadioContent /> */}
            </Modal>

        </View>
    )
}

export default ZonesPage;


const styles = StyleSheet.create({
    container: {
        backgroundColor: Background,
        flex: 1
    },
    content: {
        backgroundColor: Background,
        // flex: 1,
        padding: 16
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 5,
        paddingVertical: 20,
    },
    addModrate: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    signTitle: {
        marginTop: 50,
        fontSize: 16,
        marginBottom: 15
    },
    signBoxContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: 5,
        justifyContent: 'space-between'
    },
    signBox: {
        height: 55,
        width: 55,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: gray,
        margin: 5,
        backgroundColor: 'transparent'
    },


});



//  --------- row for setting
const SettingRow = (props) => {

    const RowClick = async () => {

        await props.changeModalData(props.items)
        await props.changeModalVisibility({
            ...props.modalVisible
            ,
            title: props.title,
            selected_item: props.selected_item,
            changeSelected_item: props.changeSelected_item,
            show: true,
            coverScreen: props.coverScreen
        })
    }
    return (
        <TouchableOpacity
            activeOpacity={.5}
            onPress={RowClick}
            style={styles.row}
        >
            <Icon style={{
                fontSize: 18, color: 'white',
                marginRight: 10
            }} name='chevron-left' />

            <View style={{
                flexDirection: 'column',
                flex: 1
            }}>
                <Text fontWeight='Medium' style={{ marginRight: 4, fontSize: 17 }}>{props.title}</Text>
                <Text fontWeight='Light' style={{ marginRight: 4, fontSize: 14, color: '#797979' }}>{props.value}</Text>
            </View>

        </TouchableOpacity>
    )
}



const zoneNameValidationSchema = Yup.object().shape({
    name: Yup
        .string()
        .max(14, ({ max }) => `نام زون باید حداکثر ${max} کاراکتر باشد`)
        .required('فیلد نام دستگاه الزامی است'),
})


const ChangeNameContent = (props) => {
    return (
        <Formik
            initialValues={{
                name: ''
            }}

            validationSchema={zoneNameValidationSchema}

            onSubmit={values => {
                props.changeZoneName(values.name);
                props.setModalVisible(false);
            }}
        >

            {({
                handleChange,
                handleBlur,
                handleSubmit,
                values,
                touched,
                errors, }) => (
                <View>
                    <Input
                        value={'زون شماره۱'}
                        placeholder='نام ریموت'
                    />

                    <TouchableOpacity>
                        <Text>ثبت</Text>
                    </TouchableOpacity>
                </View>
            )}
        </Formik>
    )
}

